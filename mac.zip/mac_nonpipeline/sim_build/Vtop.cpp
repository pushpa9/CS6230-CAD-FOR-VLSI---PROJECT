// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop.h"
#include "Vtop__Syms.h"

#include "verilated_dpi.h"

//==========

void Vtop::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vtop::eval\n"); );
    Vtop__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac/verilog/mkMac.v", 44, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vtop::_eval_initial_loop(Vtop__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac/verilog/mkMac.v", 44, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vtop::_combo__TOP__2(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__2\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__CLK = vlTOPp->CLK;
    vlTOPp->mkMac__DOT__RST_N = vlTOPp->RST_N;
    vlTOPp->mkMac__DOT__get_A_x = vlTOPp->get_A_x;
    vlTOPp->mkMac__DOT__EN_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__get_B_y = vlTOPp->get_B_y;
    vlTOPp->mkMac__DOT__EN_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__get_C_z = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__EN_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__s1_or_s2_tcs = vlTOPp->s1_or_s2_tcs;
    vlTOPp->mkMac__DOT__EN_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__EN_out_result = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__WILL_FIRE_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__WILL_FIRE_out_result = vlTOPp->EN_out_result;
}

VL_INLINE_OPT void Vtop::_sequent__TOP__4(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_sequent__TOP__4\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__s_EN) {
            vlTOPp->mkMac__DOT__s = vlTOPp->mkMac__DOT__s_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__s = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__result_EN) {
            vlTOPp->mkMac__DOT__result = vlTOPp->mkMac__DOT__result_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__result = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__c_EN) {
            vlTOPp->mkMac__DOT__c = vlTOPp->mkMac__DOT__c_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__c = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__b_EN) {
            vlTOPp->mkMac__DOT__b = vlTOPp->mkMac__DOT__b_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__b = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__a_EN) {
            vlTOPp->mkMac__DOT__a = vlTOPp->mkMac__DOT__a_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__a = 0U;
    }
    vlTOPp->mkMac__DOT__out_result = vlTOPp->mkMac__DOT__result;
    vlTOPp->mkMac__DOT__mant_y___05Fh68222 = (0x40000000U 
                                              | (0x3fffff80U 
                                                 & (vlTOPp->mkMac__DOT__c 
                                                    << 7U)));
    vlTOPp->mkMac__DOT__exp_y___05Fh68220 = (0xffU 
                                             & (vlTOPp->mkMac__DOT__c 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__b_BITS_7_TO_0___05Fq3 = (0xffU 
                                                 & (IData)(vlTOPp->mkMac__DOT__b));
    vlTOPp->mkMac__DOT__sign_x___05Fh68217 = (1U & 
                                              (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh97684 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh97743 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh97496 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh97308 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh97120 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh97555 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh96932 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh96744 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh97367 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh96556 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__a_BIT_7_XOR_b_BIT_7___05F_d6 
        = (1U & (((IData)(vlTOPp->mkMac__DOT__a) ^ (IData)(vlTOPp->mkMac__DOT__b)) 
                 >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh97179 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh96991 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh96803 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__y___05Fh96557 = (1U & (((IData)(vlTOPp->mkMac__DOT__a) 
                                                & (IData)(vlTOPp->mkMac__DOT__b)) 
                                               >> 7U));
    vlTOPp->mkMac__DOT__IF_a_BIT_0_215_THEN_1_ELSE_0___05F_d1216 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__a)) ? 1U
            : 0U);
    vlTOPp->mkMac__DOT__a_BITS_7_TO_0___05Fq1 = (0xffU 
                                                 & (IData)(vlTOPp->mkMac__DOT__a));
    vlTOPp->out_result = vlTOPp->mkMac__DOT__out_result;
    vlTOPp->mkMac__DOT__ext_b___05Fh1130 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__b_BITS_7_TO_0___05Fq3) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__b_BITS_7_TO_0___05Fq3));
    vlTOPp->mkMac__DOT__a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_BIT___05FETC___05F_d1207 
        = ((IData)(vlTOPp->mkMac__DOT__sign_x___05Fh68217) 
           == (1U & (vlTOPp->mkMac__DOT__c >> 0x1fU)));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0___05Fq6 
        = ((IData)(vlTOPp->mkMac__DOT__a_BIT_7_XOR_b_BIT_7___05F_d6)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh97917 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96556) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96557));
    vlTOPp->mkMac__DOT__y___05Fh96802 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh96557));
    vlTOPp->mkMac__DOT__y___05Fh96804 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh96557));
    vlTOPp->mkMac__DOT__mant_mult___05Fh71904 = (0x80U 
                                                 | ((0xffff0000U 
                                                     & vlTOPp->mkMac__DOT__IF_a_BIT_0_215_THEN_1_ELSE_0___05F_d1216) 
                                                    | ((0x7eU 
                                                        & (IData)(vlTOPp->mkMac__DOT__a)) 
                                                       | (1U 
                                                          & vlTOPp->mkMac__DOT__IF_a_BIT_0_215_THEN_1_ELSE_0___05F_d1216))));
    vlTOPp->mkMac__DOT__ext_a___05Fh1129 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__a_BITS_7_TO_0___05Fq1) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__a_BITS_7_TO_0___05Fq1));
    vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 = (~ vlTOPp->mkMac__DOT__ext_b___05Fh1130);
    vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810 
        = ((1U & vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0___05Fq6)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh99279 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh97917) 
                                               ^ vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0___05Fq6));
    vlTOPp->mkMac__DOT__y___05Fh98106 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97917) 
                                         & vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0___05Fq6);
    vlTOPp->mkMac__DOT__x___05Fh96801 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96803) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh96804));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__b)) ? vlTOPp->mkMac__DOT__mant_mult___05Fh71904
            : 0U);
    vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 = (~ vlTOPp->mkMac__DOT__ext_a___05Fh1129);
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_b_BITS_7_TO_0_BIT_0_0_1_THEN_1_ETC___05F_d12 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh2736 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                               >> 1U) 
                                              & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4));
    vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_EL_ETC___05F_d1813 
        = ((1U & vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh99468 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh99279) 
                                         & vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810);
    vlTOPp->mkMac__DOT__y___05Fh96745 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96801) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh96802));
    vlTOPp->mkMac__DOT__x___05Fh76639 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh76257 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh76448 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh75875 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh76066 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh75493 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 2U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh75684 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_E_ETC___05F_d1224 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh76699 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh76508 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh76317 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh76126 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh75935 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh75744 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 2U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh75494 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 1U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_a_BITS_7_TO_0_8_9_0_BIT_0_1_2___05FETC___05F_d53 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh20041 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2));
    vlTOPp->mkMac__DOT__y___05Fh2927 = ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                         >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh2736));
    vlTOPp->mkMac__DOT__x___05Fh98105 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96744) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96745));
    vlTOPp->mkMac__DOT__y___05Fh96990 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh96745));
    vlTOPp->mkMac__DOT__y___05Fh96992 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh96745));
    vlTOPp->mkMac__DOT__y___05Fh75743 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75494));
    vlTOPp->mkMac__DOT__y___05Fh75745 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75494));
    vlTOPp->mkMac__DOT__y___05Fh20232 = ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20041));
    vlTOPp->mkMac__DOT__INV_SEXT_b_BITS_7_TO_0_BIT_3_8_XOR_INV_SEXT_b___05FETC___05F_d36 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh2927) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh2736) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_b_BITS_7_TO_0_BIT_0_0_1_THEN_1_ETC___05F_d12))));
    vlTOPp->mkMac__DOT__y___05Fh3118 = ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                         >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh2927));
    vlTOPp->mkMac__DOT__x___05Fh99467 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98105) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh98106));
    vlTOPp->mkMac__DOT__y___05Fh98294 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98105) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh98106));
    vlTOPp->mkMac__DOT__x___05Fh96989 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96991) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh96992));
    vlTOPp->mkMac__DOT__x___05Fh75742 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75744) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75745));
    vlTOPp->mkMac__DOT__INV_SEXT_a_BITS_7_TO_0_8_9_0_BIT_3_9_XOR_INV_S_ETC___05F_d77 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20232) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20041) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_a_BITS_7_TO_0_8_9_0_BIT_0_1_2___05FETC___05F_d53))));
    vlTOPp->mkMac__DOT__y___05Fh20423 = ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20232));
    vlTOPp->mkMac__DOT__y___05Fh3309 = ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                         >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3118));
    vlTOPp->mkMac__DOT__a_BIT_9_830_XOR_b_BIT_9_831_871_XOR_a_BIT_8_83_ETC___05F_d1907 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh99467) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh99468)) 
            << 2U) | ((2U & (((IData)(vlTOPp->mkMac__DOT__x___05Fh99279) 
                              ^ vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810) 
                             << 1U)) | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_EL_ETC___05F_d1813)));
    vlTOPp->mkMac__DOT__y___05Fh99656 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh99467) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh99468));
    vlTOPp->mkMac__DOT__y___05Fh96933 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96989) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh96990));
    vlTOPp->mkMac__DOT__y___05Fh75685 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75742) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75743));
    vlTOPp->mkMac__DOT__y___05Fh20614 = ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20423));
    vlTOPp->mkMac__DOT__y___05Fh3500 = ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                         >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3309));
    vlTOPp->mkMac__DOT__x___05Fh98293 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96932) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96933));
    vlTOPp->mkMac__DOT__y___05Fh97178 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96933));
    vlTOPp->mkMac__DOT__y___05Fh97180 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96933));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1311 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75684) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75685)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75493) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75494)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_E_ETC___05F_d1224))));
    vlTOPp->mkMac__DOT__y___05Fh75934 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75685));
    vlTOPp->mkMac__DOT__y___05Fh75936 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75685));
    vlTOPp->mkMac__DOT__y___05Fh20805 = ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20614));
    vlTOPp->mkMac__DOT__y___05Fh3691 = ((vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4 
                                         >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3500));
    vlTOPp->mkMac__DOT__x___05Fh99655 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98293) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh98294));
    vlTOPp->mkMac__DOT__y___05Fh98482 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98293) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh98294));
    vlTOPp->mkMac__DOT__x___05Fh97177 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97179) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97180));
    vlTOPp->mkMac__DOT__x___05Fh75933 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75935) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75936));
    vlTOPp->mkMac__DOT__y___05Fh20996 = ((vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20805));
    vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2220 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_b_BITS_7_TO_0_BIT_0_0_1_THEN_1_ETC___05F_d12) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3691) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3500) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh3309) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_b130___05Fq4) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3118) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_b_BITS_7_TO_0_BIT_3_8_XOR_INV_SEXT_b___05FETC___05F_d36))))));
    vlTOPp->mkMac__DOT__y___05Fh99844 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh99655) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh99656));
    vlTOPp->mkMac__DOT__y___05Fh97121 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97177) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97178));
    vlTOPp->mkMac__DOT__y___05Fh75876 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75933) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75934));
    vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19525 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_a_BITS_7_TO_0_8_9_0_BIT_0_1_2___05FETC___05F_d53) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20996) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20805) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh20614) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_a129___05Fq2) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20423) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_a_BITS_7_TO_0_8_9_0_BIT_3_9_XOR_INV_S_ETC___05F_d77))))));
    vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__b))
            ? vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2220
            : vlTOPp->mkMac__DOT__ext_b___05Fh1130);
    vlTOPp->mkMac__DOT__x___05Fh98481 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97120) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh97121));
    vlTOPp->mkMac__DOT__y___05Fh97366 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97121));
    vlTOPp->mkMac__DOT__y___05Fh97368 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97121));
    vlTOPp->mkMac__DOT__y___05Fh76125 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75876));
    vlTOPp->mkMac__DOT__y___05Fh76127 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75876));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__a))
            ? vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19525
            : vlTOPp->mkMac__DOT__ext_a___05Fh1129);
    vlTOPp->mkMac__DOT__x___05Fh99843 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98481) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh98482));
    vlTOPp->mkMac__DOT__y___05Fh98670 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98481) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh98482));
    vlTOPp->mkMac__DOT__x___05Fh97365 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97367) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97368));
    vlTOPp->mkMac__DOT__x___05Fh76124 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76126) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76127));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_ETC___05F_d82 
        = ((1U & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__a_BIT_11_824_XOR_b_BIT_11_825_867_XOR_a_BIT_10_ETC___05F_d1908 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh99843) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh99844)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh99655) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh99656)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__a_BIT_9_830_XOR_b_BIT_9_831_871_XOR_a_BIT_8_83_ETC___05F_d1907)));
    vlTOPp->mkMac__DOT__y___05Fh100032 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh99843) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh99844));
    vlTOPp->mkMac__DOT__y___05Fh97309 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97365) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97366));
    vlTOPp->mkMac__DOT__y___05Fh76067 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76124) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76125));
    vlTOPp->mkMac__DOT__product___05Fh19012 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_ETC___05F_d82) 
                                               | ((0xfffeU 
                                                   & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80) 
                                                  | (1U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_ETC___05F_d82)));
    vlTOPp->mkMac__DOT__x___05Fh98669 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97308) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh97309));
    vlTOPp->mkMac__DOT__y___05Fh97554 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97309));
    vlTOPp->mkMac__DOT__y___05Fh97556 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97309));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1312 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh76066) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76067)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75875) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75876)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1311)));
    vlTOPp->mkMac__DOT__y___05Fh76316 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76067));
    vlTOPp->mkMac__DOT__y___05Fh76318 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76067));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh19012
            : 0U);
    vlTOPp->mkMac__DOT__x___05Fh100031 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98669) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh98670));
    vlTOPp->mkMac__DOT__y___05Fh98858 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98669) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh98670));
    vlTOPp->mkMac__DOT__x___05Fh97553 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97555) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97556));
    vlTOPp->mkMac__DOT__x___05Fh76315 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76317) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76318));
    vlTOPp->mkMac__DOT__x___05Fh28282 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh28473 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__x___05Fh27900 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh28091 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh27518 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27709 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh28533 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh27136 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27327 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh26754 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26945 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh26372 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26563 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh28342 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh25990 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 2U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh26181 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d90 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh28151 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh27960 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh27769 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27578 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh27387 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27196 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh27005 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26814 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh26623 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26432 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh26241 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 2U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh25991 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh100220 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh100031) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh100032));
    vlTOPp->mkMac__DOT__y___05Fh97497 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97553) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97554));
    vlTOPp->mkMac__DOT__y___05Fh76258 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76315) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76316));
    vlTOPp->mkMac__DOT__y___05Fh26240 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25991));
    vlTOPp->mkMac__DOT__y___05Fh26242 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25991));
    vlTOPp->mkMac__DOT__y___05Fh97742 = (((IData)(vlTOPp->mkMac__DOT__b) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97497));
    vlTOPp->mkMac__DOT__x___05Fh98857 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97496) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh97497));
    vlTOPp->mkMac__DOT__y___05Fh97744 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh97497));
    vlTOPp->mkMac__DOT__y___05Fh76507 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76258));
    vlTOPp->mkMac__DOT__y___05Fh76509 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76258));
    vlTOPp->mkMac__DOT__x___05Fh26239 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26241) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26242));
    vlTOPp->mkMac__DOT__y___05Fh99046 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98857) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh98858));
    vlTOPp->mkMac__DOT__x___05Fh100219 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh98857) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh98858));
    vlTOPp->mkMac__DOT__x___05Fh97741 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97743) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97744));
    vlTOPp->mkMac__DOT__x___05Fh76506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76508) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76509));
    vlTOPp->mkMac__DOT__y___05Fh26182 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26239) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26240));
    vlTOPp->mkMac__DOT__a_BIT_13_818_XOR_b_BIT_13_819_863_XOR_a_BIT_12_ETC___05F_d1909 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh100219) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh100220)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh100031) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh100032)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__a_BIT_11_824_XOR_b_BIT_11_825_867_XOR_a_BIT_10_ETC___05F_d1908)));
    vlTOPp->mkMac__DOT__y___05Fh100408 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh100219) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh100220));
    vlTOPp->mkMac__DOT__y___05Fh97685 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh97741) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh97742));
    vlTOPp->mkMac__DOT__y___05Fh76449 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76506) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76507));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d218 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26181) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26182)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh25990) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh25991)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88) 
                                        ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d90))));
    vlTOPp->mkMac__DOT__y___05Fh26431 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26182));
    vlTOPp->mkMac__DOT__y___05Fh26433 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26182));
    vlTOPp->mkMac__DOT__x___05Fh99045 = (1U & (~ ((IData)(vlTOPp->mkMac__DOT__x___05Fh97684) 
                                                  ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh97685))));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1313 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh76448) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76449)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh76257) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76258)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1312)));
    vlTOPp->mkMac__DOT__y___05Fh76698 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76449));
    vlTOPp->mkMac__DOT__y___05Fh76700 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76449));
    vlTOPp->mkMac__DOT__x___05Fh26430 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26432) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26433));
    vlTOPp->mkMac__DOT__x___05Fh100407 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh99045) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh99046));
    vlTOPp->mkMac__DOT__x___05Fh76697 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76699) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76700));
    vlTOPp->mkMac__DOT__y___05Fh26373 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26430) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26431));
    vlTOPp->mkMac__DOT__y___05Fh76889 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76697) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76698));
    vlTOPp->mkMac__DOT__y___05Fh26622 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26373));
    vlTOPp->mkMac__DOT__y___05Fh26624 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26373));
    vlTOPp->mkMac__DOT__y___05Fh76891 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76889));
    vlTOPp->mkMac__DOT__x___05Fh26621 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26623) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26624));
    vlTOPp->mkMac__DOT__x___05Fh76888 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                                >> 8U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh76891)));
    vlTOPp->mkMac__DOT__y___05Fh26564 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26621) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26622));
    vlTOPp->mkMac__DOT__y___05Fh76831 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76888) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76889));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d219 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26563) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26564)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26372) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26373)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d218)));
    vlTOPp->mkMac__DOT__y___05Fh26813 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26564));
    vlTOPp->mkMac__DOT__y___05Fh26815 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26564));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1314 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh76831) 
                         << 9U))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh76639) 
                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76889)) 
                                      << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1313)));
    vlTOPp->mkMac__DOT__y___05Fh77082 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh76831));
    vlTOPp->mkMac__DOT__x___05Fh26812 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26814) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26815));
    vlTOPp->mkMac__DOT__y___05Fh77273 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh77082));
    vlTOPp->mkMac__DOT__y___05Fh26755 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26812) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26813));
    vlTOPp->mkMac__DOT__y___05Fh77464 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh77273));
    vlTOPp->mkMac__DOT__y___05Fh27004 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26755));
    vlTOPp->mkMac__DOT__y___05Fh27006 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26755));
    vlTOPp->mkMac__DOT__y___05Fh77655 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh77464));
    vlTOPp->mkMac__DOT__x___05Fh27003 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27005) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27006));
    vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1316 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh77655) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh77464) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh77273) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh77082) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1314)))));
    vlTOPp->mkMac__DOT__y___05Fh77846 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh77655));
    vlTOPp->mkMac__DOT__y___05Fh26946 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27003) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27004));
    vlTOPp->mkMac__DOT__y___05Fh77977 = ((vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh77846));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d220 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26945) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26946)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26754) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26755)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d219)));
    vlTOPp->mkMac__DOT__y___05Fh27195 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26946));
    vlTOPp->mkMac__DOT__y___05Fh27197 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26946));
    vlTOPp->mkMac__DOT__mant_mult___05Fh71410 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_E_ETC___05F_d1224) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh77977) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh77846) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1316))));
    vlTOPp->mkMac__DOT__x___05Fh27194 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27196) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27197));
    vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
        = ((2U & (IData)(vlTOPp->mkMac__DOT__b)) ? vlTOPp->mkMac__DOT__mant_mult___05Fh71410
            : vlTOPp->mkMac__DOT__IF_b_BIT_0_214_THEN_IF_a_BIT_0_215_THEN_1_ELSE_ETC___05F_d1222);
    vlTOPp->mkMac__DOT__y___05Fh27137 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27194) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27195));
    vlTOPp->mkMac__DOT__x___05Fh79556 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh79747 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh79174 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh79365 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh78792 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78983 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh78601 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN___05FETC___05F_d1320 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh79807 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh79616 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh79425 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh79234 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh79043 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78852 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh78602 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 2U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__y___05Fh27386 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27137));
    vlTOPp->mkMac__DOT__y___05Fh27388 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27137));
    vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1399 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78601) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78602)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                             ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN___05FETC___05F_d1320))));
    vlTOPp->mkMac__DOT__y___05Fh78851 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78602));
    vlTOPp->mkMac__DOT__y___05Fh78853 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78602));
    vlTOPp->mkMac__DOT__x___05Fh27385 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27387) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27388));
    vlTOPp->mkMac__DOT__x___05Fh78850 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78852) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78853));
    vlTOPp->mkMac__DOT__y___05Fh27328 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27385) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27386));
    vlTOPp->mkMac__DOT__y___05Fh78793 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78850) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78851));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d221 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27327) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27328)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27136) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27137)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d220)));
    vlTOPp->mkMac__DOT__y___05Fh27577 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27328));
    vlTOPp->mkMac__DOT__y___05Fh27579 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27328));
    vlTOPp->mkMac__DOT__y___05Fh79042 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78793));
    vlTOPp->mkMac__DOT__y___05Fh79044 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78793));
    vlTOPp->mkMac__DOT__x___05Fh27576 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27578) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27579));
    vlTOPp->mkMac__DOT__x___05Fh79041 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79043) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79044));
    vlTOPp->mkMac__DOT__y___05Fh27519 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27576) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27577));
    vlTOPp->mkMac__DOT__y___05Fh78984 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79041) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79042));
    vlTOPp->mkMac__DOT__y___05Fh27768 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27519));
    vlTOPp->mkMac__DOT__y___05Fh27770 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27519));
    vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1400 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78983) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78984)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78792) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78793)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1399)));
    vlTOPp->mkMac__DOT__y___05Fh79233 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78984));
    vlTOPp->mkMac__DOT__y___05Fh79235 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78984));
    vlTOPp->mkMac__DOT__x___05Fh27767 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27769) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27770));
    vlTOPp->mkMac__DOT__x___05Fh79232 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79234) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79235));
    vlTOPp->mkMac__DOT__y___05Fh27710 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27767) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27768));
    vlTOPp->mkMac__DOT__y___05Fh79175 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79232) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79233));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d222 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27709) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27710)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27518) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27519)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d221)));
    vlTOPp->mkMac__DOT__y___05Fh27959 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27710));
    vlTOPp->mkMac__DOT__y___05Fh27961 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27710));
    vlTOPp->mkMac__DOT__y___05Fh79424 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79175));
    vlTOPp->mkMac__DOT__y___05Fh79426 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79175));
    vlTOPp->mkMac__DOT__x___05Fh27958 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27960) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27961));
    vlTOPp->mkMac__DOT__x___05Fh79423 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79425) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79426));
    vlTOPp->mkMac__DOT__y___05Fh27901 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27958) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27959));
    vlTOPp->mkMac__DOT__y___05Fh79366 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79423) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79424));
    vlTOPp->mkMac__DOT__y___05Fh28150 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27901));
    vlTOPp->mkMac__DOT__y___05Fh28152 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27901));
    vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1401 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79365) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79366)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79174) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79175)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1400)));
    vlTOPp->mkMac__DOT__y___05Fh79615 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79366));
    vlTOPp->mkMac__DOT__y___05Fh79617 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79366));
    vlTOPp->mkMac__DOT__x___05Fh28149 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28151) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28152));
    vlTOPp->mkMac__DOT__x___05Fh79614 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79616) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79617));
    vlTOPp->mkMac__DOT__y___05Fh28092 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28149) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28150));
    vlTOPp->mkMac__DOT__y___05Fh79557 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79614) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79615));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d223 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28091) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28092)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27900) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27901)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d222)));
    vlTOPp->mkMac__DOT__y___05Fh28341 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28092));
    vlTOPp->mkMac__DOT__y___05Fh28343 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28092));
    vlTOPp->mkMac__DOT__y___05Fh79806 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79557));
    vlTOPp->mkMac__DOT__y___05Fh79808 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79557));
    vlTOPp->mkMac__DOT__x___05Fh28340 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28342) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28343));
    vlTOPp->mkMac__DOT__x___05Fh79805 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79807) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79808));
    vlTOPp->mkMac__DOT__y___05Fh28283 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28340) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28341));
    vlTOPp->mkMac__DOT__y___05Fh79997 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79805) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79806));
    vlTOPp->mkMac__DOT__y___05Fh28532 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28283));
    vlTOPp->mkMac__DOT__y___05Fh28534 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28283));
    vlTOPp->mkMac__DOT__INV_IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_ETC___05F_d1402 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79747) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79997)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79556) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79557)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1401)));
    vlTOPp->mkMac__DOT__y___05Fh79999 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh79997));
    vlTOPp->mkMac__DOT__x___05Fh28531 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28533) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28534));
    vlTOPp->mkMac__DOT__x___05Fh79996 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                                >> 9U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh79999)));
    vlTOPp->mkMac__DOT__y___05Fh28474 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28531) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28532));
    vlTOPp->mkMac__DOT__y___05Fh79939 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79996) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79997));
    vlTOPp->mkMac__DOT__product___05Fh16849 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d90) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28473) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28474)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28282) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28283)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d223))));
    vlTOPp->mkMac__DOT__y___05Fh80190 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79939));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
        = ((2U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh16849
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d88);
    vlTOPp->mkMac__DOT__y___05Fh80381 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh80190));
    vlTOPp->mkMac__DOT__x___05Fh32865 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh33056 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh32483 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32674 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh32101 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh32292 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh33116 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh31719 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31910 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31337 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31528 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh30955 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh31146 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh32925 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh30764 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d227 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh32734 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32543 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh32352 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh32161 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31970 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31779 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh31588 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31397 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh31206 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh31015 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh30765 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                                >> 2U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh80572 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh80381));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d334 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30764) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30765)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225) 
                             ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d227))));
    vlTOPp->mkMac__DOT__y___05Fh31014 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30765));
    vlTOPp->mkMac__DOT__y___05Fh31016 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30765));
    vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1404 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh80572) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh80381) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh80190) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh79939) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_ETC___05F_d1402)))));
    vlTOPp->mkMac__DOT__y___05Fh80763 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh80572));
    vlTOPp->mkMac__DOT__x___05Fh31013 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31015) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31016));
    vlTOPp->mkMac__DOT__y___05Fh80894 = ((vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh80763));
    vlTOPp->mkMac__DOT__y___05Fh30956 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31013) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31014));
    vlTOPp->mkMac__DOT__mant_mult___05Fh70916 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN___05FETC___05F_d1320) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh80894) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh80763) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1404))));
    vlTOPp->mkMac__DOT__y___05Fh31205 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30956));
    vlTOPp->mkMac__DOT__y___05Fh31207 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30956));
    vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
        = ((4U & (IData)(vlTOPp->mkMac__DOT__b)) ? vlTOPp->mkMac__DOT__mant_mult___05Fh70916
            : vlTOPp->mkMac__DOT__IF_b_BIT_1_213_THEN_IF_IF_b_BIT_0_214_THEN_IF___05FETC___05F_d1318);
    vlTOPp->mkMac__DOT__x___05Fh31204 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31206) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31207));
    vlTOPp->mkMac__DOT__x___05Fh82855 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh82473 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh82664 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh82091 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh82282 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh81709 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh81900 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN___05FETC___05F_d1408 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh82915 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh82724 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh82533 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh82342 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh82151 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh81960 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh81710 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 3U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__y___05Fh31147 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31204) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31205));
    vlTOPp->mkMac__DOT__y___05Fh81959 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81710));
    vlTOPp->mkMac__DOT__y___05Fh81961 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81710));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d335 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31146) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31147)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30955) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30956)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d334)));
    vlTOPp->mkMac__DOT__y___05Fh31396 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31147));
    vlTOPp->mkMac__DOT__y___05Fh31398 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31147));
    vlTOPp->mkMac__DOT__x___05Fh81958 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81960) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81961));
    vlTOPp->mkMac__DOT__x___05Fh31395 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31397) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31398));
    vlTOPp->mkMac__DOT__y___05Fh81901 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81958) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81959));
    vlTOPp->mkMac__DOT__y___05Fh31338 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31395) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31396));
    vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1484 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81900) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81901)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81709) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81710)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN___05FETC___05F_d1408)))));
    vlTOPp->mkMac__DOT__y___05Fh82150 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81901));
    vlTOPp->mkMac__DOT__y___05Fh82152 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81901));
    vlTOPp->mkMac__DOT__y___05Fh31587 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31338));
    vlTOPp->mkMac__DOT__y___05Fh31589 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31338));
    vlTOPp->mkMac__DOT__x___05Fh82149 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82151) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82152));
    vlTOPp->mkMac__DOT__x___05Fh31586 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31588) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31589));
    vlTOPp->mkMac__DOT__y___05Fh82092 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82149) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82150));
    vlTOPp->mkMac__DOT__y___05Fh31529 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31586) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31587));
    vlTOPp->mkMac__DOT__y___05Fh82341 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82092));
    vlTOPp->mkMac__DOT__y___05Fh82343 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82092));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d336 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31528) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31529)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31337) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31338)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d335)));
    vlTOPp->mkMac__DOT__y___05Fh31778 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31529));
    vlTOPp->mkMac__DOT__y___05Fh31780 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31529));
    vlTOPp->mkMac__DOT__x___05Fh82340 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82342) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82343));
    vlTOPp->mkMac__DOT__x___05Fh31777 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31779) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31780));
    vlTOPp->mkMac__DOT__y___05Fh82283 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82340) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82341));
    vlTOPp->mkMac__DOT__y___05Fh31720 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31777) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31778));
    vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1485 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82282) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82283)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82091) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82092)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1484)));
    vlTOPp->mkMac__DOT__y___05Fh82532 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82283));
    vlTOPp->mkMac__DOT__y___05Fh82534 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82283));
    vlTOPp->mkMac__DOT__y___05Fh31969 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31720));
    vlTOPp->mkMac__DOT__y___05Fh31971 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31720));
    vlTOPp->mkMac__DOT__x___05Fh82531 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82533) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82534));
    vlTOPp->mkMac__DOT__x___05Fh31968 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31970) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31971));
    vlTOPp->mkMac__DOT__y___05Fh82474 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82531) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82532));
    vlTOPp->mkMac__DOT__y___05Fh31911 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31968) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31969));
    vlTOPp->mkMac__DOT__y___05Fh82723 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82474));
    vlTOPp->mkMac__DOT__y___05Fh82725 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82474));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d337 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31910) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31911)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31719) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31720)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d336)));
    vlTOPp->mkMac__DOT__y___05Fh32160 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31911));
    vlTOPp->mkMac__DOT__y___05Fh32162 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31911));
    vlTOPp->mkMac__DOT__x___05Fh82722 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82724) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82725));
    vlTOPp->mkMac__DOT__x___05Fh32159 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32161) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32162));
    vlTOPp->mkMac__DOT__y___05Fh82665 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82722) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82723));
    vlTOPp->mkMac__DOT__y___05Fh32102 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32159) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32160));
    vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1486 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82664) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82665)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82473) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82474)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1485)));
    vlTOPp->mkMac__DOT__y___05Fh82914 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82665));
    vlTOPp->mkMac__DOT__y___05Fh82916 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh82665));
    vlTOPp->mkMac__DOT__y___05Fh32351 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh32102));
    vlTOPp->mkMac__DOT__y___05Fh32353 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32102));
    vlTOPp->mkMac__DOT__x___05Fh82913 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82915) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82916));
    vlTOPp->mkMac__DOT__x___05Fh32350 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32352) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32353));
    vlTOPp->mkMac__DOT__y___05Fh83105 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82913) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82914));
    vlTOPp->mkMac__DOT__y___05Fh32293 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32350) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32351));
    vlTOPp->mkMac__DOT__y___05Fh83107 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh83105));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d338 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32292) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32293)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32101) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32102)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d337)));
    vlTOPp->mkMac__DOT__y___05Fh32542 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh32293));
    vlTOPp->mkMac__DOT__y___05Fh32544 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32293));
    vlTOPp->mkMac__DOT__x___05Fh83104 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                                >> 0xaU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh83107)));
    vlTOPp->mkMac__DOT__x___05Fh32541 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32543) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32544));
    vlTOPp->mkMac__DOT__y___05Fh83047 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh83104) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh83105));
    vlTOPp->mkMac__DOT__y___05Fh32484 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32541) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32542));
    vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1487 
        = ((0x800U & ((0xfffff800U & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh83047) 
                         << 0xbU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82855) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh83105)) 
                                        << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1486)));
    vlTOPp->mkMac__DOT__y___05Fh83298 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh83047));
    vlTOPp->mkMac__DOT__y___05Fh32733 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32484));
    vlTOPp->mkMac__DOT__y___05Fh32735 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32484));
    vlTOPp->mkMac__DOT__y___05Fh83489 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh83298));
    vlTOPp->mkMac__DOT__x___05Fh32732 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32734) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32735));
    vlTOPp->mkMac__DOT__y___05Fh83680 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh83489));
    vlTOPp->mkMac__DOT__y___05Fh32675 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32732) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32733));
    vlTOPp->mkMac__DOT__y___05Fh83811 = ((vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh83680));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d339 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32674) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32675)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32483) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32484)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d338)));
    vlTOPp->mkMac__DOT__y___05Fh32924 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32675));
    vlTOPp->mkMac__DOT__y___05Fh32926 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32675));
    vlTOPp->mkMac__DOT__mant_mult___05Fh70422 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN___05FETC___05F_d1408) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh83811) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh83680) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh83489) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh83298) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1487))))));
    vlTOPp->mkMac__DOT__x___05Fh32923 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32925) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32926));
    vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
        = ((8U & (IData)(vlTOPp->mkMac__DOT__b)) ? vlTOPp->mkMac__DOT__mant_mult___05Fh70422
            : vlTOPp->mkMac__DOT__IF_b_BIT_2_212_THEN_IF_IF_b_BIT_1_213_THEN_IF___05FETC___05F_d1406);
    vlTOPp->mkMac__DOT__y___05Fh32866 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32923) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32924));
    vlTOPp->mkMac__DOT__x___05Fh85772 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh85963 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh85390 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh85581 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh85008 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh85199 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh84817 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN___05FETC___05F_d1492 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh86023 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh85832 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh85641 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh85450 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh85259 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh85068 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh84818 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 4U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__y___05Fh33115 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32866));
    vlTOPp->mkMac__DOT__y___05Fh33117 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32866));
    vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1565 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84817) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84818)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN___05FETC___05F_d1492))));
    vlTOPp->mkMac__DOT__y___05Fh85067 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84818));
    vlTOPp->mkMac__DOT__y___05Fh85069 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84818));
    vlTOPp->mkMac__DOT__x___05Fh33114 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh33116) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh33117));
    vlTOPp->mkMac__DOT__x___05Fh85066 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85068) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85069));
    vlTOPp->mkMac__DOT__y___05Fh33057 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh33114) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh33115));
    vlTOPp->mkMac__DOT__y___05Fh85009 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85066) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85067));
    vlTOPp->mkMac__DOT__product___05Fh14686 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d227) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh33056) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh33057)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32865) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32866)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d339))));
    vlTOPp->mkMac__DOT__y___05Fh85258 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85009));
    vlTOPp->mkMac__DOT__y___05Fh85260 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85009));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
        = ((4U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh14686
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d225);
    vlTOPp->mkMac__DOT__x___05Fh85257 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85259) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85260));
    vlTOPp->mkMac__DOT__x___05Fh37448 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh37639 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh37066 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh37257 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh36684 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36875 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh37699 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh36302 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36493 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh35920 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh36111 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh35538 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh35729 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d343 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh37508 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh37317 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh37126 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh36935 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36744 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh36553 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36362 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh36171 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh35980 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh35789 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh35539 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                                >> 3U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh85200 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85257) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85258));
    vlTOPp->mkMac__DOT__y___05Fh35788 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35539));
    vlTOPp->mkMac__DOT__y___05Fh35790 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35539));
    vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1566 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85199) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85200)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85008) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85009)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1565)));
    vlTOPp->mkMac__DOT__y___05Fh85449 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85200));
    vlTOPp->mkMac__DOT__y___05Fh85451 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85200));
    vlTOPp->mkMac__DOT__x___05Fh35787 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35789) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35790));
    vlTOPp->mkMac__DOT__x___05Fh85448 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85450) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85451));
    vlTOPp->mkMac__DOT__y___05Fh35730 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35787) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35788));
    vlTOPp->mkMac__DOT__y___05Fh85391 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85448) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85449));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d442 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35729) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35730)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35538) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35539)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341) 
                                        ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d343)))));
    vlTOPp->mkMac__DOT__y___05Fh35979 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35730));
    vlTOPp->mkMac__DOT__y___05Fh35981 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35730));
    vlTOPp->mkMac__DOT__y___05Fh85640 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85391));
    vlTOPp->mkMac__DOT__y___05Fh85642 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85391));
    vlTOPp->mkMac__DOT__x___05Fh35978 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35980) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35981));
    vlTOPp->mkMac__DOT__x___05Fh85639 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85641) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85642));
    vlTOPp->mkMac__DOT__y___05Fh35921 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35978) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35979));
    vlTOPp->mkMac__DOT__y___05Fh85582 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85639) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85640));
    vlTOPp->mkMac__DOT__y___05Fh36170 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35921));
    vlTOPp->mkMac__DOT__y___05Fh36172 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35921));
    vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1567 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85581) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85582)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85390) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85391)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1566)));
    vlTOPp->mkMac__DOT__y___05Fh85831 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85582));
    vlTOPp->mkMac__DOT__y___05Fh85833 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85582));
    vlTOPp->mkMac__DOT__x___05Fh36169 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36171) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36172));
    vlTOPp->mkMac__DOT__x___05Fh85830 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85832) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85833));
    vlTOPp->mkMac__DOT__y___05Fh36112 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36169) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36170));
    vlTOPp->mkMac__DOT__y___05Fh85773 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85830) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85831));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d443 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36111) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36112)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35920) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35921)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d442)));
    vlTOPp->mkMac__DOT__y___05Fh36361 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36112));
    vlTOPp->mkMac__DOT__y___05Fh36363 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36112));
    vlTOPp->mkMac__DOT__y___05Fh86022 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85773));
    vlTOPp->mkMac__DOT__y___05Fh86024 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85773));
    vlTOPp->mkMac__DOT__x___05Fh36360 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36362) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36363));
    vlTOPp->mkMac__DOT__x___05Fh86021 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh86023) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh86024));
    vlTOPp->mkMac__DOT__y___05Fh36303 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36360) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36361));
    vlTOPp->mkMac__DOT__y___05Fh86213 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh86021) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh86022));
    vlTOPp->mkMac__DOT__y___05Fh36552 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36303));
    vlTOPp->mkMac__DOT__y___05Fh36554 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36303));
    vlTOPp->mkMac__DOT__INV_IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_ETC___05F_d1568 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85963) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh86213)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85772) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85773)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1567)));
    vlTOPp->mkMac__DOT__y___05Fh86215 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh86213));
    vlTOPp->mkMac__DOT__x___05Fh36551 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36553) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36554));
    vlTOPp->mkMac__DOT__x___05Fh86212 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                                >> 0xbU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh86215)));
    vlTOPp->mkMac__DOT__y___05Fh36494 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36551) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36552));
    vlTOPp->mkMac__DOT__y___05Fh86155 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh86212) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh86213));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d444 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36493) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36494)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36302) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36303)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d443)));
    vlTOPp->mkMac__DOT__y___05Fh36743 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36494));
    vlTOPp->mkMac__DOT__y___05Fh36745 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36494));
    vlTOPp->mkMac__DOT__y___05Fh86406 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh86155));
    vlTOPp->mkMac__DOT__x___05Fh36742 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36744) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36745));
    vlTOPp->mkMac__DOT__y___05Fh86597 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh86406));
    vlTOPp->mkMac__DOT__y___05Fh36685 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36742) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36743));
    vlTOPp->mkMac__DOT__y___05Fh86728 = ((vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh86597));
    vlTOPp->mkMac__DOT__y___05Fh36934 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36685));
    vlTOPp->mkMac__DOT__y___05Fh36936 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36685));
    vlTOPp->mkMac__DOT__mant_mult___05Fh69928 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN___05FETC___05F_d1492) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh86728) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh86597) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh86406) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh86155) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__INV_IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_ETC___05F_d1568))))));
    vlTOPp->mkMac__DOT__x___05Fh36933 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36935) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36936));
    vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
        = ((0x10U & (IData)(vlTOPp->mkMac__DOT__b))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh69928
            : vlTOPp->mkMac__DOT__IF_b_BIT_3_211_THEN_IF_IF_b_BIT_2_212_THEN_IF___05FETC___05F_d1490);
    vlTOPp->mkMac__DOT__y___05Fh36876 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36933) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36934));
    vlTOPp->mkMac__DOT__x___05Fh89071 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh88689 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh88880 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh88307 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh88498 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh87925 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh88116 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN___05FETC___05F_d1573 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh89131 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh88940 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh88749 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh88558 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh88367 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh88176 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh87926 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 5U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d445 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36875) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36876)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36684) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36685)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d444)));
    vlTOPp->mkMac__DOT__y___05Fh37125 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36876));
    vlTOPp->mkMac__DOT__y___05Fh37127 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36876));
    vlTOPp->mkMac__DOT__y___05Fh88175 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87926));
    vlTOPp->mkMac__DOT__y___05Fh88177 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87926));
    vlTOPp->mkMac__DOT__x___05Fh37124 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37126) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37127));
    vlTOPp->mkMac__DOT__x___05Fh88174 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88176) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88177));
    vlTOPp->mkMac__DOT__y___05Fh37067 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37124) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37125));
    vlTOPp->mkMac__DOT__y___05Fh88117 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88174) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88175));
    vlTOPp->mkMac__DOT__y___05Fh37316 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh37067));
    vlTOPp->mkMac__DOT__y___05Fh37318 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37067));
    vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1643 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh88116) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88117)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh87925) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87926)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN___05FETC___05F_d1573)))));
    vlTOPp->mkMac__DOT__y___05Fh88366 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88117));
    vlTOPp->mkMac__DOT__y___05Fh88368 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88117));
    vlTOPp->mkMac__DOT__x___05Fh37315 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37317) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37318));
    vlTOPp->mkMac__DOT__x___05Fh88365 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88367) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88368));
    vlTOPp->mkMac__DOT__y___05Fh37258 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37315) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37316));
    vlTOPp->mkMac__DOT__y___05Fh88308 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88365) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88366));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d446 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37257) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37258)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37066) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37067)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d445)));
    vlTOPp->mkMac__DOT__y___05Fh37507 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37258));
    vlTOPp->mkMac__DOT__y___05Fh37509 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37258));
    vlTOPp->mkMac__DOT__y___05Fh88557 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88308));
    vlTOPp->mkMac__DOT__y___05Fh88559 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88308));
    vlTOPp->mkMac__DOT__x___05Fh37506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37508) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37509));
    vlTOPp->mkMac__DOT__x___05Fh88556 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88558) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88559));
    vlTOPp->mkMac__DOT__y___05Fh37449 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37506) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37507));
    vlTOPp->mkMac__DOT__y___05Fh88499 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88556) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88557));
    vlTOPp->mkMac__DOT__y___05Fh37698 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37449));
    vlTOPp->mkMac__DOT__y___05Fh37700 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37449));
    vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1644 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh88498) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88499)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh88307) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88308)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1643)));
    vlTOPp->mkMac__DOT__y___05Fh88748 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88499));
    vlTOPp->mkMac__DOT__y___05Fh88750 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88499));
    vlTOPp->mkMac__DOT__x___05Fh37697 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37699) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37700));
    vlTOPp->mkMac__DOT__x___05Fh88747 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88749) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88750));
    vlTOPp->mkMac__DOT__y___05Fh37640 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37697) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37698));
    vlTOPp->mkMac__DOT__y___05Fh88690 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88747) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88748));
    vlTOPp->mkMac__DOT__product___05Fh12523 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d343) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37639) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37640)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37448) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37449)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d446))));
    vlTOPp->mkMac__DOT__y___05Fh88939 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88690));
    vlTOPp->mkMac__DOT__y___05Fh88941 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88690));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
        = ((8U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh12523
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d341);
    vlTOPp->mkMac__DOT__x___05Fh88938 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88940) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88941));
    vlTOPp->mkMac__DOT__x___05Fh42031 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh42222 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh41649 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41840 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41267 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41458 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh42282 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh40885 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh41076 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh40503 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40694 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40312 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d450 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh42091 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41900 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41709 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh41518 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41327 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh41136 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh40945 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40754 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40563 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh40313 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                                >> 4U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh88881 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88938) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88939));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d541 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40312) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40313)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448) 
                                ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d450))));
    vlTOPp->mkMac__DOT__y___05Fh40562 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40313));
    vlTOPp->mkMac__DOT__y___05Fh40564 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40313));
    vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1645 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh88880) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88881)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh88689) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88690)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1644)));
    vlTOPp->mkMac__DOT__y___05Fh89130 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88881));
    vlTOPp->mkMac__DOT__y___05Fh89132 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88881));
    vlTOPp->mkMac__DOT__x___05Fh40561 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40563) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40564));
    vlTOPp->mkMac__DOT__x___05Fh89129 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89131) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89132));
    vlTOPp->mkMac__DOT__y___05Fh40504 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40561) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40562));
    vlTOPp->mkMac__DOT__y___05Fh89321 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89129) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89130));
    vlTOPp->mkMac__DOT__y___05Fh40753 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40504));
    vlTOPp->mkMac__DOT__y___05Fh40755 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40504));
    vlTOPp->mkMac__DOT__y___05Fh89323 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89321));
    vlTOPp->mkMac__DOT__x___05Fh40752 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40754) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40755));
    vlTOPp->mkMac__DOT__x___05Fh89320 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                                >> 0xcU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh89323)));
    vlTOPp->mkMac__DOT__y___05Fh40695 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40752) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40753));
    vlTOPp->mkMac__DOT__y___05Fh89263 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89320) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89321));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d542 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40694) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40695)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40503) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40504)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d541)));
    vlTOPp->mkMac__DOT__y___05Fh40944 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40695));
    vlTOPp->mkMac__DOT__y___05Fh40946 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40695));
    vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1646 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh89263) 
                          << 0xdU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh89071) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89321)) 
                                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1645)));
    vlTOPp->mkMac__DOT__y___05Fh89514 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89263));
    vlTOPp->mkMac__DOT__x___05Fh40943 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40945) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40946));
    vlTOPp->mkMac__DOT__y___05Fh89645 = ((vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89514));
    vlTOPp->mkMac__DOT__y___05Fh40886 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40943) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40944));
    vlTOPp->mkMac__DOT__mant_mult___05Fh69434 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN___05FETC___05F_d1573) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh89645) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh89514) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1646))));
    vlTOPp->mkMac__DOT__y___05Fh41135 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40886));
    vlTOPp->mkMac__DOT__y___05Fh41137 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40886));
    vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
        = ((0x20U & (IData)(vlTOPp->mkMac__DOT__b))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh69434
            : vlTOPp->mkMac__DOT__IF_b_BIT_4_210_THEN_IF_IF_b_BIT_3_211_THEN_IF___05FETC___05F_d1571);
    vlTOPp->mkMac__DOT__x___05Fh41134 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41136) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41137));
    vlTOPp->mkMac__DOT__x___05Fh91988 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh92179 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh91606 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh91797 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh91224 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh91415 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh91033 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN___05FETC___05F_d1650 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh92239 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh92048 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh91857 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh91666 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh91475 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh91284 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh91034 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 6U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__y___05Fh41077 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41134) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41135));
    vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1717 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91033) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91034)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN___05FETC___05F_d1650))));
    vlTOPp->mkMac__DOT__y___05Fh91283 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91034));
    vlTOPp->mkMac__DOT__y___05Fh91285 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91034));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d543 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41076) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41077)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40885) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40886)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d542)));
    vlTOPp->mkMac__DOT__y___05Fh41326 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41077));
    vlTOPp->mkMac__DOT__y___05Fh41328 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41077));
    vlTOPp->mkMac__DOT__x___05Fh91282 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91284) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91285));
    vlTOPp->mkMac__DOT__x___05Fh41325 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41327) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41328));
    vlTOPp->mkMac__DOT__y___05Fh91225 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91282) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91283));
    vlTOPp->mkMac__DOT__y___05Fh41268 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41325) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41326));
    vlTOPp->mkMac__DOT__y___05Fh91474 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91225));
    vlTOPp->mkMac__DOT__y___05Fh91476 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91225));
    vlTOPp->mkMac__DOT__y___05Fh41517 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41268));
    vlTOPp->mkMac__DOT__y___05Fh41519 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41268));
    vlTOPp->mkMac__DOT__x___05Fh91473 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91475) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91476));
    vlTOPp->mkMac__DOT__x___05Fh41516 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41518) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41519));
    vlTOPp->mkMac__DOT__y___05Fh91416 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91473) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91474));
    vlTOPp->mkMac__DOT__y___05Fh41459 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41516) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41517));
    vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1718 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91415) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91416)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91224) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91225)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1717)));
    vlTOPp->mkMac__DOT__y___05Fh91665 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91416));
    vlTOPp->mkMac__DOT__y___05Fh91667 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91416));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d544 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41458) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41459)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41267) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41268)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d543)));
    vlTOPp->mkMac__DOT__y___05Fh41708 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41459));
    vlTOPp->mkMac__DOT__y___05Fh41710 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41459));
    vlTOPp->mkMac__DOT__x___05Fh91664 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91666) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91667));
    vlTOPp->mkMac__DOT__x___05Fh41707 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41709) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41710));
    vlTOPp->mkMac__DOT__y___05Fh91607 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91664) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91665));
    vlTOPp->mkMac__DOT__y___05Fh41650 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41707) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41708));
    vlTOPp->mkMac__DOT__y___05Fh91856 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91607));
    vlTOPp->mkMac__DOT__y___05Fh91858 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91607));
    vlTOPp->mkMac__DOT__y___05Fh41899 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41650));
    vlTOPp->mkMac__DOT__y___05Fh41901 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41650));
    vlTOPp->mkMac__DOT__x___05Fh91855 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91857) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91858));
    vlTOPp->mkMac__DOT__x___05Fh41898 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41900) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41901));
    vlTOPp->mkMac__DOT__y___05Fh91798 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91855) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh91856));
    vlTOPp->mkMac__DOT__y___05Fh41841 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41898) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41899));
    vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1719 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91797) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91798)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91606) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91607)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1718)));
    vlTOPp->mkMac__DOT__y___05Fh92047 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91798));
    vlTOPp->mkMac__DOT__y___05Fh92049 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91798));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d545 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41840) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41841)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41649) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41650)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d544)));
    vlTOPp->mkMac__DOT__y___05Fh42090 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41841));
    vlTOPp->mkMac__DOT__y___05Fh42092 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41841));
    vlTOPp->mkMac__DOT__x___05Fh92046 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92048) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh92049));
    vlTOPp->mkMac__DOT__x___05Fh42089 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42091) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42092));
    vlTOPp->mkMac__DOT__y___05Fh91989 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92046) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh92047));
    vlTOPp->mkMac__DOT__y___05Fh42032 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42089) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42090));
    vlTOPp->mkMac__DOT__y___05Fh92238 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh91989));
    vlTOPp->mkMac__DOT__y___05Fh92240 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91989));
    vlTOPp->mkMac__DOT__y___05Fh42281 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh42032));
    vlTOPp->mkMac__DOT__y___05Fh42283 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh42032));
    vlTOPp->mkMac__DOT__x___05Fh92237 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92239) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh92240));
    vlTOPp->mkMac__DOT__x___05Fh42280 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42282) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42283));
    vlTOPp->mkMac__DOT__y___05Fh92429 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92237) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh92238));
    vlTOPp->mkMac__DOT__y___05Fh42223 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42280) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42281));
    vlTOPp->mkMac__DOT__INV_IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_ETC___05F_d1720 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92179) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92429)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh91988) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91989)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1719)));
    vlTOPp->mkMac__DOT__y___05Fh92431 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92429));
    vlTOPp->mkMac__DOT__product___05Fh10360 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d450) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh42222) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh42223)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh42031) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh42032)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d545))));
    vlTOPp->mkMac__DOT__x___05Fh92428 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                                >> 0xdU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh92431)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
        = ((0x10U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh10360
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d448);
    vlTOPp->mkMac__DOT__y___05Fh92371 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92428) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh92429));
    vlTOPp->mkMac__DOT__x___05Fh46614 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh46805 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh46232 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46423 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh45850 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh46041 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh46865 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh45468 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45659 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh45086 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh45277 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d549 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh46674 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh46483 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46292 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh46101 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh45910 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh45719 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45528 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh45337 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh45087 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                                >> 5U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh92562 = ((vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92371));
    vlTOPp->mkMac__DOT__y___05Fh45336 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45087));
    vlTOPp->mkMac__DOT__y___05Fh45338 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45087));
    vlTOPp->mkMac__DOT__mant_mult___05Fh68940 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN___05FETC___05F_d1650) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh92562) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh92371) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__INV_IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_ETC___05F_d1720))));
    vlTOPp->mkMac__DOT__x___05Fh45335 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45337) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45338));
    vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
        = ((0x40U & (IData)(vlTOPp->mkMac__DOT__b))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh68940
            : vlTOPp->mkMac__DOT__IF_b_BIT_5_209_THEN_IF_IF_b_BIT_4_210_THEN_IF___05FETC___05F_d1648);
    vlTOPp->mkMac__DOT__y___05Fh45278 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45335) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45336));
    vlTOPp->mkMac__DOT__x___05Fh95287 = (1U & (~ (vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770 
        = ((1U & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh95096 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xdU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh94905 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh94714 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh94523 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh95347 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xdU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__y___05Fh102495 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                 >> 7U) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__x___05Fh94332 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh94141 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh95156 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh94965 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh94774 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh94583 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh94392 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh94142 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 7U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d632 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45277) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45278)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45086) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45087)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547) 
                                           ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d549)))));
    vlTOPp->mkMac__DOT__y___05Fh45527 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45278));
    vlTOPp->mkMac__DOT__y___05Fh45529 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45278));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_TH_ETC___05F_d1776 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1970 
        = (1U & (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                   >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
                  ? (~ (IData)(vlTOPp->mkMac__DOT__y___05Fh102495))
                  : (IData)(vlTOPp->mkMac__DOT__y___05Fh102495)));
    vlTOPp->mkMac__DOT__x___05Fh102494 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94141) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh94142));
    vlTOPp->mkMac__DOT__y___05Fh94391 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94142));
    vlTOPp->mkMac__DOT__y___05Fh94393 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94142));
    vlTOPp->mkMac__DOT__x___05Fh45526 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45528) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45529));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1977 
        = (1U & (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                   >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
                  ? vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_TH_ETC___05F_d1776
                  : vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1949 
        = (1U & (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
                  & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                            | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
                  ? (~ (IData)(vlTOPp->mkMac__DOT__x___05Fh102494))
                  : (IData)(vlTOPp->mkMac__DOT__x___05Fh102494)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1968 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh102494) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh102495))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh102494));
    vlTOPp->mkMac__DOT__y___05Fh102683 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh102494) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh102495));
    vlTOPp->mkMac__DOT__x___05Fh94390 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94392) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94393));
    vlTOPp->mkMac__DOT__y___05Fh45469 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45526) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45527));
    vlTOPp->mkMac__DOT__y___05Fh94333 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94390) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94391));
    vlTOPp->mkMac__DOT__y___05Fh45718 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45469));
    vlTOPp->mkMac__DOT__y___05Fh45720 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45469));
    vlTOPp->mkMac__DOT__x___05Fh102682 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94332) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh94333));
    vlTOPp->mkMac__DOT__y___05Fh94582 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94333));
    vlTOPp->mkMac__DOT__y___05Fh94584 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94333));
    vlTOPp->mkMac__DOT__x___05Fh45717 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45719) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45720));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1947 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh102682) 
               ^ (IData)(vlTOPp->mkMac__DOT__x___05Fh102494))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh102682));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1966 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh102682) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh102683))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh102682));
    vlTOPp->mkMac__DOT__y___05Fh107929 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh102682) 
                                          & (IData)(vlTOPp->mkMac__DOT__x___05Fh102494));
    vlTOPp->mkMac__DOT__y___05Fh102871 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh102682) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh102683));
    vlTOPp->mkMac__DOT__x___05Fh94581 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94583) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94584));
    vlTOPp->mkMac__DOT__y___05Fh45660 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45717) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45718));
    vlTOPp->mkMac__DOT__y___05Fh94524 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94581) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94582));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d633 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45659) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45660)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45468) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45469)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d632)));
    vlTOPp->mkMac__DOT__y___05Fh45909 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45660));
    vlTOPp->mkMac__DOT__y___05Fh45911 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45660));
    vlTOPp->mkMac__DOT__x___05Fh102870 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94523) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh94524));
    vlTOPp->mkMac__DOT__y___05Fh94773 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94524));
    vlTOPp->mkMac__DOT__y___05Fh94775 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh94524));
    vlTOPp->mkMac__DOT__x___05Fh45908 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45910) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45911));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1945 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh102870) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107929))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh102870));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1964 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh102870) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh102871))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh102870));
    vlTOPp->mkMac__DOT__y___05Fh108117 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh102870) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107929));
    vlTOPp->mkMac__DOT__y___05Fh103059 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh102870) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh102871));
    vlTOPp->mkMac__DOT__x___05Fh94772 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94774) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94775));
    vlTOPp->mkMac__DOT__y___05Fh45851 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45908) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45909));
    vlTOPp->mkMac__DOT__y___05Fh94715 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94772) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94773));
    vlTOPp->mkMac__DOT__y___05Fh46100 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45851));
    vlTOPp->mkMac__DOT__y___05Fh46102 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45851));
    vlTOPp->mkMac__DOT__x___05Fh103058 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94714) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh94715));
    vlTOPp->mkMac__DOT__y___05Fh94964 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94715));
    vlTOPp->mkMac__DOT__y___05Fh94966 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh94715));
    vlTOPp->mkMac__DOT__x___05Fh46099 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46101) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46102));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1943 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103058) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108117))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103058));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1962 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103058) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103059))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103058));
    vlTOPp->mkMac__DOT__y___05Fh108305 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103058) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108117));
    vlTOPp->mkMac__DOT__y___05Fh103247 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103058) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh103059));
    vlTOPp->mkMac__DOT__x___05Fh94963 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94965) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94966));
    vlTOPp->mkMac__DOT__y___05Fh46042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46099) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46100));
    vlTOPp->mkMac__DOT__y___05Fh94906 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94963) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh94964));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d634 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46041) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46042)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45850) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45851)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d633)));
    vlTOPp->mkMac__DOT__y___05Fh46291 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46042));
    vlTOPp->mkMac__DOT__y___05Fh46293 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46042));
    vlTOPp->mkMac__DOT__x___05Fh103246 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh94905) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh94906));
    vlTOPp->mkMac__DOT__y___05Fh95155 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh94906));
    vlTOPp->mkMac__DOT__y___05Fh95157 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh94906));
    vlTOPp->mkMac__DOT__x___05Fh46290 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46292) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46293));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1941 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103246) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108305))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103246));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1960 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103246) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103247))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103246));
    vlTOPp->mkMac__DOT__y___05Fh108493 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103246) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108305));
    vlTOPp->mkMac__DOT__y___05Fh103435 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103246) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh103247));
    vlTOPp->mkMac__DOT__x___05Fh95154 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95156) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh95157));
    vlTOPp->mkMac__DOT__y___05Fh46233 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46290) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46291));
    vlTOPp->mkMac__DOT__y___05Fh95097 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95154) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh95155));
    vlTOPp->mkMac__DOT__y___05Fh46482 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46233));
    vlTOPp->mkMac__DOT__y___05Fh46484 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46233));
    vlTOPp->mkMac__DOT__x___05Fh103434 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95096) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95097));
    vlTOPp->mkMac__DOT__y___05Fh95346 = (((IData)(vlTOPp->mkMac__DOT__a) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh95097));
    vlTOPp->mkMac__DOT__y___05Fh95348 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95097));
    vlTOPp->mkMac__DOT__x___05Fh46481 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46483) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46484));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1939 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103434) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108493))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103434));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1958 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103434) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103435))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103434));
    vlTOPp->mkMac__DOT__y___05Fh108681 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103434) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108493));
    vlTOPp->mkMac__DOT__y___05Fh103623 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103434) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh103435));
    vlTOPp->mkMac__DOT__x___05Fh95345 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95347) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh95348));
    vlTOPp->mkMac__DOT__y___05Fh46424 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46481) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46482));
    vlTOPp->mkMac__DOT__y___05Fh95537 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95345) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh95346));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d635 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46423) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46424)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46232) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46233)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d634)));
    vlTOPp->mkMac__DOT__y___05Fh46673 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46424));
    vlTOPp->mkMac__DOT__y___05Fh46675 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46424));
    vlTOPp->mkMac__DOT__x___05Fh103622 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95287) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95537));
    vlTOPp->mkMac__DOT__y___05Fh95539 = ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95537));
    vlTOPp->mkMac__DOT__x___05Fh46672 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46674) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46675));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1937 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103622) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108681))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103622));
    vlTOPp->mkMac__DOT__y___05Fh108869 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103622) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108681));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1956 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh103622) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103623))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh103622));
    vlTOPp->mkMac__DOT__y___05Fh103811 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103622) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh103623));
    vlTOPp->mkMac__DOT__x___05Fh95536 = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                >> 0xeU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh95539)));
    vlTOPp->mkMac__DOT__y___05Fh46615 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46672) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46673));
    vlTOPp->mkMac__DOT__y___05Fh95479 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95536) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh95537));
    vlTOPp->mkMac__DOT__y___05Fh46864 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46615));
    vlTOPp->mkMac__DOT__y___05Fh46866 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46615));
    vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766 
        = (1U & ((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                  >> 0xfU) ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95479)));
    vlTOPp->mkMac__DOT__x___05Fh46863 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46865) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46866));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1935 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_TH_ETC___05F_d1776 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108869)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766)));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1804 
        = (((vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770))))
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_TH_ETC___05F_d1776 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103811)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1770 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766)));
    vlTOPp->mkMac__DOT__y___05Fh46806 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46863) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46864));
    vlTOPp->mkMac__DOT__mant_mult___05Fh95665 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1935 
                                                  << 0xeU) 
                                                 | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1937) 
                                                     << 0xdU) 
                                                    | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1939) 
                                                        << 0xcU) 
                                                       | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1941) 
                                                           << 0xbU) 
                                                          | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1943) 
                                                              << 0xaU) 
                                                             | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1945) 
                                                                 << 9U) 
                                                                | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1947) 
                                                                    << 8U) 
                                                                   | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1949) 
                                                                       << 7U) 
                                                                      | (((IData)(vlTOPp->mkMac__DOT__y___05Fh102495) 
                                                                          << 6U) 
                                                                         | (0x3fU 
                                                                            & (vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                                               >> 1U)))))))))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh100583 
        = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1804 
            << 0xfU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1956) 
                         << 0xeU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1958) 
                                      << 0xdU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1960) 
                                                   << 0xcU) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1962) 
                                                      << 0xbU) 
                                                     | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1964) 
                                                         << 0xaU) 
                                                        | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1966) 
                                                            << 9U) 
                                                           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1968) 
                                                               << 8U) 
                                                              | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1970) 
                                                                  << 7U) 
                                                                 | ((0x7eU 
                                                                     & vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722) 
                                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1977)))))))))));
    vlTOPp->mkMac__DOT__mant_mult___05Fh103995 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1804 
                                                   << 0xeU) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1956) 
                                                      << 0xdU) 
                                                     | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1958) 
                                                         << 0xcU) 
                                                        | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1960) 
                                                            << 0xbU) 
                                                           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1962) 
                                                               << 0xaU) 
                                                              | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1964) 
                                                                  << 9U) 
                                                                 | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1966) 
                                                                     << 8U) 
                                                                    | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1968) 
                                                                        << 7U) 
                                                                       | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1970) 
                                                                           << 6U) 
                                                                          | (0x3fU 
                                                                             & (vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1722 
                                                                                >> 1U)))))))))));
    if ((1U & ((IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766) 
               | vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1804))) {
        vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1898 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_EL_ETC___05F_d1813 
                              >> 7U)) | ((IData)(vlTOPp->mkMac__DOT__x___05Fh100407) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh100408)));
        vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1913 
            = vlTOPp->mkMac__DOT__a_BIT_13_818_XOR_b_BIT_13_819_863_XOR_a_BIT_12_ETC___05F_d1909;
    } else {
        vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1898 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810 
                              >> 7U)) | (IData)(vlTOPp->mkMac__DOT__x___05Fh100407));
        vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1913 
            = (((IData)(vlTOPp->mkMac__DOT__x___05Fh100219) 
                << 6U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh100031) 
                           << 5U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh99843) 
                                      << 4U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh99655) 
                                                 << 3U) 
                                                | (((IData)(vlTOPp->mkMac__DOT__x___05Fh99467) 
                                                    << 2U) 
                                                   | (((IData)(vlTOPp->mkMac__DOT__x___05Fh99279) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlTOPp->mkMac__DOT__IF_INV_IF_a_BIT_7_XOR_b_BIT_7_THEN_1_ELSE_0_80_ETC___05F_d1810)))))));
    }
    vlTOPp->mkMac__DOT__product___05Fh8197 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d549) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46805) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46806)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46614) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46615)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d635))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh100585 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1804)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh103995
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh100583);
    vlTOPp->mkMac__DOT__exp_x___05Fh68219 = ((0x80U 
                                              & (vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1898 
                                                 << 7U)) 
                                             | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1913));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
        = ((0x20U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh8197
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d547);
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05Fq8 
        = ((IData)(vlTOPp->mkMac__DOT__IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN_IF___05FETC___05F_d1766)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh95665
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh100585);
    vlTOPp->mkMac__DOT__x___05Fh109163 = (vlTOPp->mkMac__DOT__exp_y___05Fh68220 
                                          - vlTOPp->mkMac__DOT__exp_x___05Fh68219);
    vlTOPp->mkMac__DOT___0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT___05FETC___05F_d1918 
        = (vlTOPp->mkMac__DOT__exp_x___05Fh68219 <= vlTOPp->mkMac__DOT__exp_y___05Fh68220);
    vlTOPp->mkMac__DOT__x___05Fh109210 = (vlTOPp->mkMac__DOT__exp_x___05Fh68219 
                                          - vlTOPp->mkMac__DOT__exp_y___05Fh68220);
    vlTOPp->mkMac__DOT__x___05Fh51197 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh51388 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh50815 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh51006 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh50433 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50624 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh51448 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh50051 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh50242 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh49860 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d639 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh51257 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh51066 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh50875 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh50684 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50493 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh50302 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh50111 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh49861 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                                >> 6U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__mant_x___05Fh68221 = (0x40000000U 
                                              | (0x3f800000U 
                                                 & (vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05Fq8 
                                                    << 0x10U)));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561 
        = (0xffU & ((1U & ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT___05FETC___05F_d1918)) 
                           | (vlTOPp->mkMac__DOT__exp_y___05Fh68220 
                              <= vlTOPp->mkMac__DOT__exp_x___05Fh68219)))
                     ? ((0x80U & (vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1898 
                                  << 7U)) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT_5_209_THEN___05FETC___05F_d1913))
                     : (vlTOPp->mkMac__DOT__c >> 0x17U)));
    vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh109183 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh109210)
            ? (vlTOPp->mkMac__DOT__mant_y___05Fh68222 
               >> vlTOPp->mkMac__DOT__x___05Fh109210)
            : 0U);
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d714 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49860) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49861)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637) 
                                ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d639))));
    vlTOPp->mkMac__DOT__y___05Fh50110 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49861));
    vlTOPp->mkMac__DOT__y___05Fh50112 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49861));
    vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh109160 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh109163)
            ? (vlTOPp->mkMac__DOT__mant_x___05Fh68221 
               >> vlTOPp->mkMac__DOT__x___05Fh109163)
            : 0U);
    vlTOPp->mkMac__DOT__exp_x___05Fh68224 = vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561;
    vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THE_ETC___05F_d2564 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh130637 = (1U & (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                                 >> 1U) 
                                                & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)));
    vlTOPp->mkMac__DOT__mant_y___05Fh68227 = ((IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT___05FETC___05F_d1918)
                                               ? vlTOPp->mkMac__DOT__mant_y___05Fh68222
                                               : vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh109183);
    vlTOPp->mkMac__DOT__x___05Fh50109 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50111) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50112));
    vlTOPp->mkMac__DOT__mant_x___05Fh68226 = ((1U & 
                                               ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_b_BIT___05FETC___05F_d1918)) 
                                                | (vlTOPp->mkMac__DOT__exp_y___05Fh68220 
                                                   <= vlTOPp->mkMac__DOT__exp_x___05Fh68219)))
                                               ? vlTOPp->mkMac__DOT__mant_x___05Fh68221
                                               : vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh109160);
    vlTOPp->mkMac__DOT__y___05Fh130825 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130637));
    vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 = (~ vlTOPp->mkMac__DOT__mant_y___05Fh68227);
    vlTOPp->mkMac__DOT__y___05Fh50052 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50109) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50110));
    vlTOPp->mkMac__DOT__x___05Fh116041 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh115653 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh115847 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d1996 
        = (vlTOPp->mkMac__DOT__mant_x___05Fh68226 < vlTOPp->mkMac__DOT__mant_y___05Fh68227);
    vlTOPp->mkMac__DOT__x___05Fh115265 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh115459 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh116102 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh114877 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh115071 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh114489 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh114683 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114101 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh114295 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh115908 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh113713 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh113907 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh113325 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh113519 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh112937 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh113131 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh112549 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh112743 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh115714 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh112161 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh112355 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh111773 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh111967 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh111385 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh111579 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh115520 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh110997 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh111191 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh110609 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh110803 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_mant_x8226_BIT_0_XOR_mant_y8227_BIT_0_THEN___05FETC___05Fq10 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                  ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh110221 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh110415 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh115326 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh115132 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh114938 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114744 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh114550 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh114356 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh114162 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh113968 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh113774 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh113580 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh113386 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh113192 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh112998 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh112804 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh112610 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh112416 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh112222 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh112028 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh111834 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh111640 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh111446 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh111252 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh111058 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh110864 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh110670 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh110476 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh68227) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh110222 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                & vlTOPp->mkMac__DOT__mant_y___05Fh68227));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2588 
        = ((8U & ((0xfffffff8U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh130825) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh130637) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THE_ETC___05F_d2564))));
    vlTOPp->mkMac__DOT__y___05Fh131013 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130825));
    vlTOPp->mkMac__DOT__x___05Fh122600 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh122794 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh129546 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh129740 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh122988 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh129934 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh122212 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh122406 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh129158 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh129352 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh121824 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh122018 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh128770 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh128964 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh123049 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh129995 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh121436 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121630 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh128382 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128576 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh121048 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh121242 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh127994 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh128188 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh120660 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120854 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh127606 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127800 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh122855 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh129801 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh120272 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120466 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh127218 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127412 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh119884 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh120078 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh126830 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh127024 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh119496 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119690 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh126442 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126636 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh119108 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119302 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh126054 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh126248 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh122661 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh129607 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh118720 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118914 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh125666 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125860 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118332 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118526 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh125278 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125472 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh117944 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh118138 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh124890 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh125084 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh122467 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh129413 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh117556 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117750 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh124502 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124696 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_INV_INV_mant_y8227_BIT_0_XOR_mant_x8226_BIT_ETC___05Fq11 
        = ((1U & (vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                  ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__IF_INV_mant_x8226_BIT_0_XOR_INV_mant_y8227_BIT_ETC___05Fq12 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                  ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh117168 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh117362 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh124114 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh124308 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh122273 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh129219 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh122079 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh129025 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh121885 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh128831 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh121691 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128637 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121497 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh128443 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh121303 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh128249 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh121109 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh128055 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh120915 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127861 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120721 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh127667 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh120527 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127473 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120333 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh127279 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh120139 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh127085 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh119945 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh126891 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh119751 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126697 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119557 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh126503 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh119363 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh126309 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119169 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh126115 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118975 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125921 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118781 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh125727 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh118587 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125533 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118393 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh125339 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh118199 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh125145 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh118005 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh124951 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh117811 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124757 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117617 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh124563 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh117423 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh124369 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh68226) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh117229 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                                & vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9));
    vlTOPp->mkMac__DOT__x___05Fh124175 = (1U & (vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                                & vlTOPp->mkMac__DOT__mant_x___05Fh68226));
    vlTOPp->mkMac__DOT__y___05Fh50301 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50052));
    vlTOPp->mkMac__DOT__y___05Fh50303 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50052));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109235 
        = (1U & ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d1996)
                  ? (vlTOPp->mkMac__DOT__c >> 0x1fU)
                  : (IData)(vlTOPp->mkMac__DOT__sign_x___05Fh68217)));
    vlTOPp->mkMac__DOT__y___05Fh110475 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110222));
    vlTOPp->mkMac__DOT__y___05Fh110477 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110222));
    vlTOPp->mkMac__DOT__y___05Fh131201 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131013));
    vlTOPp->mkMac__DOT__x___05Fh117227 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh117229) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh68226));
    vlTOPp->mkMac__DOT__x___05Fh124173 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh124175) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9));
    vlTOPp->mkMac__DOT__x___05Fh50300 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50302) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50303));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109078 
        = ((IData)(vlTOPp->mkMac__DOT__a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_BIT___05FETC___05F_d1207)
            ? (IData)(vlTOPp->mkMac__DOT__sign_x___05Fh68217)
            : (IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109235));
    vlTOPp->mkMac__DOT__x___05Fh110474 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110476) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110477));
    vlTOPp->mkMac__DOT__y___05Fh131389 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131201));
    vlTOPp->mkMac__DOT__y___05Fh117169 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh117227) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9));
    vlTOPp->mkMac__DOT__y___05Fh124115 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh124173) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh68226));
    vlTOPp->mkMac__DOT__y___05Fh50243 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50300) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50301));
    vlTOPp->mkMac__DOT__y___05Fh110416 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110474) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110475));
    vlTOPp->mkMac__DOT__y___05Fh131577 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561) 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131389));
    vlTOPp->mkMac__DOT__y___05Fh117422 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117169));
    vlTOPp->mkMac__DOT__y___05Fh117424 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117169));
    vlTOPp->mkMac__DOT__y___05Fh124368 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124115));
    vlTOPp->mkMac__DOT__y___05Fh124370 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124115));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d715 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50242) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50243)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50051) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50052)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d714)));
    vlTOPp->mkMac__DOT__y___05Fh50492 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50243));
    vlTOPp->mkMac__DOT__y___05Fh50494 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50243));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2657 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110415) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110416)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110221) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110222)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_mant_x8226_BIT_0_XOR_mant_y8227_BIT_0_THEN___05FETC___05Fq10)));
    vlTOPp->mkMac__DOT__y___05Fh110669 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110416));
    vlTOPp->mkMac__DOT__y___05Fh110671 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110416));
    vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh130126 
        = ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THE_ETC___05F_d2564) 
           | ((0x80U & ((0xffffff80U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh131577) 
                           << 7U))) | ((0x40U & ((0xffffffc0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh131389) 
                                                  << 6U))) 
                                       | ((0x20U & 
                                           ((0xffffffe0U 
                                             & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                                            ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh131201) 
                                               << 5U))) 
                                          | ((0x10U 
                                              & ((0xfffffff0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2561)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh131013) 
                                                  << 4U))) 
                                             | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2588))))));
    vlTOPp->mkMac__DOT__x___05Fh117421 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117423) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117424));
    vlTOPp->mkMac__DOT__x___05Fh124367 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124369) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124370));
    vlTOPp->mkMac__DOT__x___05Fh50491 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50493) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50494));
    vlTOPp->mkMac__DOT__x___05Fh110668 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110670) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110671));
    vlTOPp->mkMac__DOT__y___05Fh117363 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117421) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117422));
    vlTOPp->mkMac__DOT__y___05Fh124309 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124367) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124368));
    vlTOPp->mkMac__DOT__y___05Fh50434 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50491) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50492));
    vlTOPp->mkMac__DOT__y___05Fh110610 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110668) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110669));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2815 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117362) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117363)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117168) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117169)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_mant_x8226_BIT_0_XOR_INV_mant_y8227_BIT_ETC___05Fq12)));
    vlTOPp->mkMac__DOT__y___05Fh117616 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117363));
    vlTOPp->mkMac__DOT__y___05Fh117618 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117363));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2736 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124308) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124309)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124114) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124115)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_mant_y8227_BIT_0_XOR_mant_x8226_BIT_ETC___05Fq11)));
    vlTOPp->mkMac__DOT__y___05Fh124562 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124309));
    vlTOPp->mkMac__DOT__y___05Fh124564 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124309));
    vlTOPp->mkMac__DOT__y___05Fh50683 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50434));
    vlTOPp->mkMac__DOT__y___05Fh50685 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50434));
    vlTOPp->mkMac__DOT__y___05Fh110863 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110610));
    vlTOPp->mkMac__DOT__y___05Fh110865 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110610));
    vlTOPp->mkMac__DOT__x___05Fh117615 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117617) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117618));
    vlTOPp->mkMac__DOT__x___05Fh124561 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124563) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124564));
    vlTOPp->mkMac__DOT__x___05Fh50682 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50684) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50685));
    vlTOPp->mkMac__DOT__x___05Fh110862 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110864) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110865));
    vlTOPp->mkMac__DOT__y___05Fh117557 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117615) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117616));
    vlTOPp->mkMac__DOT__y___05Fh124503 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124561) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124562));
    vlTOPp->mkMac__DOT__y___05Fh50625 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50682) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50683));
    vlTOPp->mkMac__DOT__y___05Fh110804 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110862) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110863));
    vlTOPp->mkMac__DOT__y___05Fh117810 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117557));
    vlTOPp->mkMac__DOT__y___05Fh117812 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117557));
    vlTOPp->mkMac__DOT__y___05Fh124756 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124503));
    vlTOPp->mkMac__DOT__y___05Fh124758 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124503));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d716 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50624) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50625)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50433) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50434)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d715)));
    vlTOPp->mkMac__DOT__y___05Fh50874 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50625));
    vlTOPp->mkMac__DOT__y___05Fh50876 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50625));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2658 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110803) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110804)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110609) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110610)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2657)));
    vlTOPp->mkMac__DOT__y___05Fh111057 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110804));
    vlTOPp->mkMac__DOT__y___05Fh111059 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110804));
    vlTOPp->mkMac__DOT__x___05Fh117809 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117811) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117812));
    vlTOPp->mkMac__DOT__x___05Fh124755 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124757) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124758));
    vlTOPp->mkMac__DOT__x___05Fh50873 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50875) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50876));
    vlTOPp->mkMac__DOT__x___05Fh111056 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111058) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111059));
    vlTOPp->mkMac__DOT__y___05Fh117751 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117809) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117810));
    vlTOPp->mkMac__DOT__y___05Fh124697 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124755) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124756));
    vlTOPp->mkMac__DOT__y___05Fh50816 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50873) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50874));
    vlTOPp->mkMac__DOT__y___05Fh110998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111056) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111057));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2816 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117750) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117751)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117556) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117557)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2815)));
    vlTOPp->mkMac__DOT__y___05Fh118004 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117751));
    vlTOPp->mkMac__DOT__y___05Fh118006 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117751));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2737 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124696) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124697)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124502) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124503)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2736)));
    vlTOPp->mkMac__DOT__y___05Fh124950 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124697));
    vlTOPp->mkMac__DOT__y___05Fh124952 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124697));
    vlTOPp->mkMac__DOT__y___05Fh51065 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50816));
    vlTOPp->mkMac__DOT__y___05Fh51067 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50816));
    vlTOPp->mkMac__DOT__y___05Fh111251 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110998));
    vlTOPp->mkMac__DOT__y___05Fh111253 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110998));
    vlTOPp->mkMac__DOT__x___05Fh118003 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118005) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118006));
    vlTOPp->mkMac__DOT__x___05Fh124949 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124951) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124952));
    vlTOPp->mkMac__DOT__x___05Fh51064 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51066) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51067));
    vlTOPp->mkMac__DOT__x___05Fh111250 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111252) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111253));
    vlTOPp->mkMac__DOT__y___05Fh117945 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118003) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118004));
    vlTOPp->mkMac__DOT__y___05Fh124891 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124949) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124950));
    vlTOPp->mkMac__DOT__y___05Fh51007 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51064) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51065));
    vlTOPp->mkMac__DOT__y___05Fh111192 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111250) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111251));
    vlTOPp->mkMac__DOT__y___05Fh118198 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117945));
    vlTOPp->mkMac__DOT__y___05Fh118200 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117945));
    vlTOPp->mkMac__DOT__y___05Fh125144 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124891));
    vlTOPp->mkMac__DOT__y___05Fh125146 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124891));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d717 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh51006) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh51007)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50815) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50816)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d716)));
    vlTOPp->mkMac__DOT__y___05Fh51256 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh51007));
    vlTOPp->mkMac__DOT__y___05Fh51258 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh51007));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2659 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111191) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111192)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110997) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110998)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2658)));
    vlTOPp->mkMac__DOT__y___05Fh111445 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111192));
    vlTOPp->mkMac__DOT__y___05Fh111447 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111192));
    vlTOPp->mkMac__DOT__x___05Fh118197 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118199) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118200));
    vlTOPp->mkMac__DOT__x___05Fh125143 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125145) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125146));
    vlTOPp->mkMac__DOT__x___05Fh51255 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51257) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51258));
    vlTOPp->mkMac__DOT__x___05Fh111444 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111446) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111447));
    vlTOPp->mkMac__DOT__y___05Fh118139 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118197) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118198));
    vlTOPp->mkMac__DOT__y___05Fh125085 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125143) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125144));
    vlTOPp->mkMac__DOT__y___05Fh51198 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51255) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51256));
    vlTOPp->mkMac__DOT__y___05Fh111386 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111444) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111445));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2817 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118138) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118139)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117944) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117945)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2816)));
    vlTOPp->mkMac__DOT__y___05Fh118392 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118139));
    vlTOPp->mkMac__DOT__y___05Fh118394 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118139));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2738 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125084) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125085)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124890) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124891)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2737)));
    vlTOPp->mkMac__DOT__y___05Fh125338 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125085));
    vlTOPp->mkMac__DOT__y___05Fh125340 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125085));
    vlTOPp->mkMac__DOT__y___05Fh51447 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh51198));
    vlTOPp->mkMac__DOT__y___05Fh51449 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh51198));
    vlTOPp->mkMac__DOT__y___05Fh111639 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111386));
    vlTOPp->mkMac__DOT__y___05Fh111641 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111386));
    vlTOPp->mkMac__DOT__x___05Fh118391 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118393) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118394));
    vlTOPp->mkMac__DOT__x___05Fh125337 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125339) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125340));
    vlTOPp->mkMac__DOT__x___05Fh51446 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51448) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51449));
    vlTOPp->mkMac__DOT__x___05Fh111638 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111640) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111641));
    vlTOPp->mkMac__DOT__y___05Fh118333 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118391) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118392));
    vlTOPp->mkMac__DOT__y___05Fh125279 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125337) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125338));
    vlTOPp->mkMac__DOT__y___05Fh51389 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51446) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51447));
    vlTOPp->mkMac__DOT__y___05Fh111580 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111638) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111639));
    vlTOPp->mkMac__DOT__y___05Fh118586 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118333));
    vlTOPp->mkMac__DOT__y___05Fh118588 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118333));
    vlTOPp->mkMac__DOT__y___05Fh125532 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125279));
    vlTOPp->mkMac__DOT__y___05Fh125534 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125279));
    vlTOPp->mkMac__DOT__product___05Fh6034 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d639) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh51388) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh51389)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh51197) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh51198)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d717))));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2660 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111579) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111580)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111385) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111386)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2659)));
    vlTOPp->mkMac__DOT__y___05Fh111833 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111580));
    vlTOPp->mkMac__DOT__y___05Fh111835 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111580));
    vlTOPp->mkMac__DOT__x___05Fh118585 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118587) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118588));
    vlTOPp->mkMac__DOT__x___05Fh125531 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125533) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125534));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh6034
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d637);
    vlTOPp->mkMac__DOT__x___05Fh111832 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111834) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111835));
    vlTOPp->mkMac__DOT__y___05Fh118527 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118585) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118586));
    vlTOPp->mkMac__DOT__y___05Fh125473 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125531) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125532));
    vlTOPp->mkMac__DOT__x___05Fh55780 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh55971 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh55398 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55589 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55016 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh55207 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh56031 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh54634 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh54825 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d721 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh55840 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55649 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55458 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh55267 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh55076 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh54885 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh54635 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                                >> 7U) 
                                               & vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80));
    vlTOPp->mkMac__DOT__y___05Fh111774 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111832) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111833));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2818 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118526) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118527)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118332) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118333)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2817)));
    vlTOPp->mkMac__DOT__y___05Fh118780 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118527));
    vlTOPp->mkMac__DOT__y___05Fh118782 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118527));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2739 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125472) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125473)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125278) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125279)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2738)));
    vlTOPp->mkMac__DOT__y___05Fh125726 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125473));
    vlTOPp->mkMac__DOT__y___05Fh125728 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125473));
    vlTOPp->mkMac__DOT__y___05Fh54884 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54635));
    vlTOPp->mkMac__DOT__y___05Fh54886 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54635));
    vlTOPp->mkMac__DOT__y___05Fh112027 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111774));
    vlTOPp->mkMac__DOT__y___05Fh112029 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111774));
    vlTOPp->mkMac__DOT__x___05Fh118779 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118781) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118782));
    vlTOPp->mkMac__DOT__x___05Fh125725 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125727) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125728));
    vlTOPp->mkMac__DOT__x___05Fh54883 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54885) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54886));
    vlTOPp->mkMac__DOT__x___05Fh112026 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112028) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112029));
    vlTOPp->mkMac__DOT__y___05Fh118721 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118779) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118780));
    vlTOPp->mkMac__DOT__y___05Fh125667 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125725) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125726));
    vlTOPp->mkMac__DOT__y___05Fh54826 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54883) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54884));
    vlTOPp->mkMac__DOT__y___05Fh111968 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112026) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112027));
    vlTOPp->mkMac__DOT__y___05Fh118974 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118721));
    vlTOPp->mkMac__DOT__y___05Fh118976 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118721));
    vlTOPp->mkMac__DOT__y___05Fh125920 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125667));
    vlTOPp->mkMac__DOT__y___05Fh125922 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125667));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d788 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54825) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54826)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54634) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54635)) 
                       << 8U) | ((0x80U & ((0xffffff80U 
                                            & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719) 
                                           ^ (vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                              << 7U))) 
                                 | ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d721)))));
    vlTOPp->mkMac__DOT__y___05Fh55075 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54826));
    vlTOPp->mkMac__DOT__y___05Fh55077 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54826));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2661 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111967) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111968)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111773) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111774)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2660)));
    vlTOPp->mkMac__DOT__y___05Fh112221 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111968));
    vlTOPp->mkMac__DOT__y___05Fh112223 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111968));
    vlTOPp->mkMac__DOT__x___05Fh118973 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118975) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118976));
    vlTOPp->mkMac__DOT__x___05Fh125919 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125921) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125922));
    vlTOPp->mkMac__DOT__x___05Fh55074 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55076) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55077));
    vlTOPp->mkMac__DOT__x___05Fh112220 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112222) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112223));
    vlTOPp->mkMac__DOT__y___05Fh118915 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118973) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118974));
    vlTOPp->mkMac__DOT__y___05Fh125861 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125919) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125920));
    vlTOPp->mkMac__DOT__y___05Fh55017 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55074) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55075));
    vlTOPp->mkMac__DOT__y___05Fh112162 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112220) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112221));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2819 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118914) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118915)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118720) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118721)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2818)));
    vlTOPp->mkMac__DOT__y___05Fh119168 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118915));
    vlTOPp->mkMac__DOT__y___05Fh119170 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118915));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2740 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125860) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125861)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125666) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125667)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2739)));
    vlTOPp->mkMac__DOT__y___05Fh126114 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125861));
    vlTOPp->mkMac__DOT__y___05Fh126116 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125861));
    vlTOPp->mkMac__DOT__y___05Fh55266 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55017));
    vlTOPp->mkMac__DOT__y___05Fh55268 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55017));
    vlTOPp->mkMac__DOT__y___05Fh112415 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112162));
    vlTOPp->mkMac__DOT__y___05Fh112417 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112162));
    vlTOPp->mkMac__DOT__x___05Fh119167 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119169) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119170));
    vlTOPp->mkMac__DOT__x___05Fh126113 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126115) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126116));
    vlTOPp->mkMac__DOT__x___05Fh55265 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55267) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55268));
    vlTOPp->mkMac__DOT__x___05Fh112414 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112416) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112417));
    vlTOPp->mkMac__DOT__y___05Fh119109 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119167) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119168));
    vlTOPp->mkMac__DOT__y___05Fh126055 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126113) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126114));
    vlTOPp->mkMac__DOT__y___05Fh55208 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55265) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55266));
    vlTOPp->mkMac__DOT__y___05Fh112356 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112414) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112415));
    vlTOPp->mkMac__DOT__y___05Fh119362 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119109));
    vlTOPp->mkMac__DOT__y___05Fh119364 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119109));
    vlTOPp->mkMac__DOT__y___05Fh126308 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126055));
    vlTOPp->mkMac__DOT__y___05Fh126310 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126055));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d789 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55207) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55208)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55016) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55017)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d788)));
    vlTOPp->mkMac__DOT__y___05Fh55457 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55208));
    vlTOPp->mkMac__DOT__y___05Fh55459 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55208));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2662 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112355) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112356)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112161) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112162)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2661)));
    vlTOPp->mkMac__DOT__y___05Fh112609 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112356));
    vlTOPp->mkMac__DOT__y___05Fh112611 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112356));
    vlTOPp->mkMac__DOT__x___05Fh119361 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119363) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119364));
    vlTOPp->mkMac__DOT__x___05Fh126307 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126309) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126310));
    vlTOPp->mkMac__DOT__x___05Fh55456 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55458) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55459));
    vlTOPp->mkMac__DOT__x___05Fh112608 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112610) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112611));
    vlTOPp->mkMac__DOT__y___05Fh119303 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119361) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119362));
    vlTOPp->mkMac__DOT__y___05Fh126249 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126307) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126308));
    vlTOPp->mkMac__DOT__y___05Fh55399 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55456) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55457));
    vlTOPp->mkMac__DOT__y___05Fh112550 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112608) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112609));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2820 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119302) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119303)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119108) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119109)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2819)));
    vlTOPp->mkMac__DOT__y___05Fh119556 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119303));
    vlTOPp->mkMac__DOT__y___05Fh119558 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119303));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2741 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126248) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126249)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126054) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126055)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2740)));
    vlTOPp->mkMac__DOT__y___05Fh126502 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126249));
    vlTOPp->mkMac__DOT__y___05Fh126504 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126249));
    vlTOPp->mkMac__DOT__y___05Fh55648 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55399));
    vlTOPp->mkMac__DOT__y___05Fh55650 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55399));
    vlTOPp->mkMac__DOT__y___05Fh112803 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112550));
    vlTOPp->mkMac__DOT__y___05Fh112805 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112550));
    vlTOPp->mkMac__DOT__x___05Fh119555 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119557) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119558));
    vlTOPp->mkMac__DOT__x___05Fh126501 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126503) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126504));
    vlTOPp->mkMac__DOT__x___05Fh55647 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55649) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55650));
    vlTOPp->mkMac__DOT__x___05Fh112802 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112804) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112805));
    vlTOPp->mkMac__DOT__y___05Fh119497 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119555) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119556));
    vlTOPp->mkMac__DOT__y___05Fh126443 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126501) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126502));
    vlTOPp->mkMac__DOT__y___05Fh55590 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55647) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55648));
    vlTOPp->mkMac__DOT__y___05Fh112744 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112802) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112803));
    vlTOPp->mkMac__DOT__y___05Fh119750 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119497));
    vlTOPp->mkMac__DOT__y___05Fh119752 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119497));
    vlTOPp->mkMac__DOT__y___05Fh126696 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126443));
    vlTOPp->mkMac__DOT__y___05Fh126698 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126443));
    vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d790 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55589) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55590)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55398) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55399)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d789)));
    vlTOPp->mkMac__DOT__y___05Fh55839 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55590));
    vlTOPp->mkMac__DOT__y___05Fh55841 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55590));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2663 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112743) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112744)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112549) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112550)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2662)));
    vlTOPp->mkMac__DOT__y___05Fh112997 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112744));
    vlTOPp->mkMac__DOT__y___05Fh112999 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112744));
    vlTOPp->mkMac__DOT__x___05Fh119749 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119751) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119752));
    vlTOPp->mkMac__DOT__x___05Fh126695 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126697) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126698));
    vlTOPp->mkMac__DOT__x___05Fh55838 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55840) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55841));
    vlTOPp->mkMac__DOT__x___05Fh112996 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112998) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112999));
    vlTOPp->mkMac__DOT__y___05Fh119691 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119749) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119750));
    vlTOPp->mkMac__DOT__y___05Fh126637 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126695) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126696));
    vlTOPp->mkMac__DOT__y___05Fh55781 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55838) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55839));
    vlTOPp->mkMac__DOT__y___05Fh112938 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112996) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112997));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2821 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119690) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119691)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119496) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119497)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2820)));
    vlTOPp->mkMac__DOT__y___05Fh119944 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119691));
    vlTOPp->mkMac__DOT__y___05Fh119946 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119691));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2742 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126636) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126637)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126442) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126443)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2741)));
    vlTOPp->mkMac__DOT__y___05Fh126890 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126637));
    vlTOPp->mkMac__DOT__y___05Fh126892 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126637));
    vlTOPp->mkMac__DOT__y___05Fh56030 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_THEN_IF_INV_INV_SEXT_a_BITS_7_TO_0___05FETC___05F_d80 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55781));
    vlTOPp->mkMac__DOT__y___05Fh56032 = ((vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55781));
    vlTOPp->mkMac__DOT__y___05Fh113191 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112938));
    vlTOPp->mkMac__DOT__y___05Fh113193 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112938));
    vlTOPp->mkMac__DOT__x___05Fh119943 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119945) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119946));
    vlTOPp->mkMac__DOT__x___05Fh126889 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126891) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126892));
    vlTOPp->mkMac__DOT__x___05Fh56029 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh56031) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh56032));
    vlTOPp->mkMac__DOT__x___05Fh113190 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113192) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113193));
    vlTOPp->mkMac__DOT__y___05Fh119885 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119943) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119944));
    vlTOPp->mkMac__DOT__y___05Fh126831 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126889) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126890));
    vlTOPp->mkMac__DOT__y___05Fh55972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh56029) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh56030));
    vlTOPp->mkMac__DOT__y___05Fh113132 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113190) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113191));
    vlTOPp->mkMac__DOT__y___05Fh120138 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119885));
    vlTOPp->mkMac__DOT__y___05Fh120140 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119885));
    vlTOPp->mkMac__DOT__y___05Fh127084 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126831));
    vlTOPp->mkMac__DOT__y___05Fh127086 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126831));
    vlTOPp->mkMac__DOT__product___05Fh3871 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_ETC___05F_d721) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55971) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55972)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55780) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55781)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d790))));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2664 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113131) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113132)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112937) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112938)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2663)));
    vlTOPp->mkMac__DOT__y___05Fh113385 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113132));
    vlTOPp->mkMac__DOT__y___05Fh113387 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113132));
    vlTOPp->mkMac__DOT__x___05Fh120137 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120139) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120140));
    vlTOPp->mkMac__DOT__x___05Fh127083 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127085) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127086));
    vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1131 
        = ((0x80U & vlTOPp->mkMac__DOT__IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_0___05FETC___05F_d39)
            ? vlTOPp->mkMac__DOT__product___05Fh3871
            : vlTOPp->mkMac__DOT__IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS_7_TO_ETC___05F_d719);
    vlTOPp->mkMac__DOT__x___05Fh113384 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113386) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113387));
    vlTOPp->mkMac__DOT__y___05Fh120079 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120137) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120138));
    vlTOPp->mkMac__DOT__y___05Fh127025 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127083) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127084));
    vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
        = (~ vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1131);
    vlTOPp->mkMac__DOT__y___05Fh113326 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113384) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113385));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2822 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120078) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120079)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119884) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119885)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2821)));
    vlTOPp->mkMac__DOT__y___05Fh120332 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120079));
    vlTOPp->mkMac__DOT__y___05Fh120334 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120079));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2743 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127024) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127025)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126830) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126831)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2742)));
    vlTOPp->mkMac__DOT__y___05Fh127278 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127025));
    vlTOPp->mkMac__DOT__y___05Fh127280 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127025));
    vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1131_BIT_0_THEN_1_ELSE_0___05Fq7 
        = ((1U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh56400 = (1U & ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5));
    vlTOPp->mkMac__DOT__y___05Fh113579 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113326));
    vlTOPp->mkMac__DOT__y___05Fh113581 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113326));
    vlTOPp->mkMac__DOT__x___05Fh120331 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120333) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120334));
    vlTOPp->mkMac__DOT__x___05Fh127277 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127279) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127280));
    vlTOPp->mkMac__DOT__y___05Fh56591 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56400));
    vlTOPp->mkMac__DOT__x___05Fh113578 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113580) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113581));
    vlTOPp->mkMac__DOT__y___05Fh120273 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120331) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120332));
    vlTOPp->mkMac__DOT__y___05Fh127219 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127277) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127278));
    vlTOPp->mkMac__DOT__y___05Fh56782 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56591));
    vlTOPp->mkMac__DOT__y___05Fh113520 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113578) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113579));
    vlTOPp->mkMac__DOT__y___05Fh120526 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120273));
    vlTOPp->mkMac__DOT__y___05Fh120528 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120273));
    vlTOPp->mkMac__DOT__y___05Fh127472 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127219));
    vlTOPp->mkMac__DOT__y___05Fh127474 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127219));
    vlTOPp->mkMac__DOT__y___05Fh56973 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56782));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2665 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113519) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113520)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113325) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113326)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2664));
    vlTOPp->mkMac__DOT__y___05Fh113773 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113520));
    vlTOPp->mkMac__DOT__y___05Fh113775 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113520));
    vlTOPp->mkMac__DOT__x___05Fh120525 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120527) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120528));
    vlTOPp->mkMac__DOT__x___05Fh127471 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127473) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127474));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d892 
        = ((0x20U & ((0xffffffe0U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                     ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56973) 
                        << 5U))) | ((0x10U & ((0xfffffff0U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56782) 
                                                 << 4U))) 
                                    | ((8U & ((0xfffffff8U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56591) 
                                                 << 3U))) 
                                       | ((4U & ((0xfffffffcU 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh56400) 
                                                  << 2U))) 
                                          | ((2U & 
                                              ((0xfffffffeU 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                               ^ (vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                                  << 1U))) 
                                             | (1U 
                                                & vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1131_BIT_0_THEN_1_ELSE_0___05Fq7))))));
    vlTOPp->mkMac__DOT__y___05Fh57164 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56973));
    vlTOPp->mkMac__DOT__x___05Fh113772 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113774) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113775));
    vlTOPp->mkMac__DOT__y___05Fh120467 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120525) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120526));
    vlTOPp->mkMac__DOT__y___05Fh127413 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127471) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127472));
    vlTOPp->mkMac__DOT__y___05Fh57355 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57164));
    vlTOPp->mkMac__DOT__y___05Fh113714 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113772) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113773));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2823 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120466) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120467)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120272) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120273)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2822));
    vlTOPp->mkMac__DOT__y___05Fh120720 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120467));
    vlTOPp->mkMac__DOT__y___05Fh120722 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120467));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2744 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127412) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127413)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127218) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127219)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2743));
    vlTOPp->mkMac__DOT__y___05Fh127666 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127413));
    vlTOPp->mkMac__DOT__y___05Fh127668 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127413));
    vlTOPp->mkMac__DOT__y___05Fh57546 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57355));
    vlTOPp->mkMac__DOT__y___05Fh113967 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113714));
    vlTOPp->mkMac__DOT__y___05Fh113969 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113714));
    vlTOPp->mkMac__DOT__x___05Fh120719 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120721) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120722));
    vlTOPp->mkMac__DOT__x___05Fh127665 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127667) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127668));
    vlTOPp->mkMac__DOT__y___05Fh57737 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57546));
    vlTOPp->mkMac__DOT__x___05Fh113966 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113968) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113969));
    vlTOPp->mkMac__DOT__y___05Fh120661 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120719) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120720));
    vlTOPp->mkMac__DOT__y___05Fh127607 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127665) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127666));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d894 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57737) 
                         << 9U))) | ((0x100U & ((0xffffff00U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57546) 
                                                   << 8U))) 
                                     | ((0x80U & ((0xffffff80U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57355) 
                                                   << 7U))) 
                                        | ((0x40U & 
                                            ((0xffffffc0U 
                                              & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57164) 
                                                << 6U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d892)))));
    vlTOPp->mkMac__DOT__y___05Fh57928 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57737));
    vlTOPp->mkMac__DOT__y___05Fh113908 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113966) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113967));
    vlTOPp->mkMac__DOT__y___05Fh120914 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120661));
    vlTOPp->mkMac__DOT__y___05Fh120916 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120661));
    vlTOPp->mkMac__DOT__y___05Fh127860 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127607));
    vlTOPp->mkMac__DOT__y___05Fh127862 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127607));
    vlTOPp->mkMac__DOT__y___05Fh58119 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57928));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2666 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113907) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113908)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113713) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113714)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2665));
    vlTOPp->mkMac__DOT__y___05Fh114161 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113908));
    vlTOPp->mkMac__DOT__y___05Fh114163 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113908));
    vlTOPp->mkMac__DOT__x___05Fh120913 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120915) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120916));
    vlTOPp->mkMac__DOT__x___05Fh127859 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127861) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127862));
    vlTOPp->mkMac__DOT__y___05Fh58310 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58119));
    vlTOPp->mkMac__DOT__x___05Fh114160 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114162) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114163));
    vlTOPp->mkMac__DOT__y___05Fh120855 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120913) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120914));
    vlTOPp->mkMac__DOT__y___05Fh127801 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127859) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127860));
    vlTOPp->mkMac__DOT__y___05Fh58501 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58310));
    vlTOPp->mkMac__DOT__y___05Fh114102 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114160) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114161));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2824 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120854) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120855)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120660) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120661)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2823));
    vlTOPp->mkMac__DOT__y___05Fh121108 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120855));
    vlTOPp->mkMac__DOT__y___05Fh121110 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120855));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2745 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127800) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127801)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127606) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127607)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2744));
    vlTOPp->mkMac__DOT__y___05Fh128054 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127801));
    vlTOPp->mkMac__DOT__y___05Fh128056 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127801));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d896 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58501) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58310) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58119) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57928) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d894)))));
    vlTOPp->mkMac__DOT__y___05Fh58692 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58501));
    vlTOPp->mkMac__DOT__y___05Fh114355 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114102));
    vlTOPp->mkMac__DOT__y___05Fh114357 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114102));
    vlTOPp->mkMac__DOT__x___05Fh121107 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121109) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121110));
    vlTOPp->mkMac__DOT__x___05Fh128053 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128055) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128056));
    vlTOPp->mkMac__DOT__y___05Fh58883 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58692));
    vlTOPp->mkMac__DOT__x___05Fh114354 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114356) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114357));
    vlTOPp->mkMac__DOT__y___05Fh121049 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121107) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121108));
    vlTOPp->mkMac__DOT__y___05Fh127995 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128053) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128054));
    vlTOPp->mkMac__DOT__y___05Fh59074 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0xfU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58883));
    vlTOPp->mkMac__DOT__y___05Fh114296 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114354) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114355));
    vlTOPp->mkMac__DOT__y___05Fh121302 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121049));
    vlTOPp->mkMac__DOT__y___05Fh121304 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121049));
    vlTOPp->mkMac__DOT__y___05Fh128248 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127995));
    vlTOPp->mkMac__DOT__y___05Fh128250 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127995));
    vlTOPp->mkMac__DOT__y___05Fh59265 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x10U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59074));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2667 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114295) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114296)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114101) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114102)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2666));
    vlTOPp->mkMac__DOT__y___05Fh114549 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114296));
    vlTOPp->mkMac__DOT__y___05Fh114551 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114296));
    vlTOPp->mkMac__DOT__x___05Fh121301 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121303) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121304));
    vlTOPp->mkMac__DOT__x___05Fh128247 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128249) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128250));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d898 
        = ((0x20000U & ((0xfffe0000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59265) 
                           << 0x11U))) | ((0x10000U 
                                           & ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59074) 
                                                 << 0x10U))) 
                                          | ((0x8000U 
                                              & ((0xffff8000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh58883) 
                                                  << 0xfU))) 
                                             | ((0x4000U 
                                                 & ((0xffffc000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh58692) 
                                                     << 0xeU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d896)))));
    vlTOPp->mkMac__DOT__y___05Fh59456 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x11U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59265));
    vlTOPp->mkMac__DOT__x___05Fh114548 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114550) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114551));
    vlTOPp->mkMac__DOT__y___05Fh121243 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121301) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121302));
    vlTOPp->mkMac__DOT__y___05Fh128189 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128247) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128248));
    vlTOPp->mkMac__DOT__y___05Fh59647 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x12U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59456));
    vlTOPp->mkMac__DOT__y___05Fh114490 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114548) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114549));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2825 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121242) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121243)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121048) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121049)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2824));
    vlTOPp->mkMac__DOT__y___05Fh121496 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121243));
    vlTOPp->mkMac__DOT__y___05Fh121498 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121243));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2746 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128188) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128189)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127994) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127995)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2745));
    vlTOPp->mkMac__DOT__y___05Fh128442 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128189));
    vlTOPp->mkMac__DOT__y___05Fh128444 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128189));
    vlTOPp->mkMac__DOT__y___05Fh59838 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x13U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59647));
    vlTOPp->mkMac__DOT__y___05Fh114743 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114490));
    vlTOPp->mkMac__DOT__y___05Fh114745 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114490));
    vlTOPp->mkMac__DOT__x___05Fh121495 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121497) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121498));
    vlTOPp->mkMac__DOT__x___05Fh128441 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128443) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128444));
    vlTOPp->mkMac__DOT__y___05Fh60029 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x14U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59838));
    vlTOPp->mkMac__DOT__x___05Fh114742 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114744) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114745));
    vlTOPp->mkMac__DOT__y___05Fh121437 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121495) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121496));
    vlTOPp->mkMac__DOT__y___05Fh128383 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128441) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128442));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d900 
        = ((0x200000U & ((0xffe00000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60029) 
                            << 0x15U))) | ((0x100000U 
                                            & ((0xfff00000U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59838) 
                                                  << 0x14U))) 
                                           | ((0x80000U 
                                               & ((0xfff80000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh59647) 
                                                   << 0x13U))) 
                                              | ((0x40000U 
                                                  & ((0xfffc0000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh59456) 
                                                      << 0x12U))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d898))));
    vlTOPp->mkMac__DOT__y___05Fh60220 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x15U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60029));
    vlTOPp->mkMac__DOT__y___05Fh114684 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114742) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114743));
    vlTOPp->mkMac__DOT__y___05Fh121690 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121437));
    vlTOPp->mkMac__DOT__y___05Fh121692 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121437));
    vlTOPp->mkMac__DOT__y___05Fh128636 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128383));
    vlTOPp->mkMac__DOT__y___05Fh128638 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128383));
    vlTOPp->mkMac__DOT__y___05Fh60411 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x16U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60220));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2668 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114683) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114684)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114489) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114490)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2667));
    vlTOPp->mkMac__DOT__y___05Fh114937 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114684));
    vlTOPp->mkMac__DOT__y___05Fh114939 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114684));
    vlTOPp->mkMac__DOT__x___05Fh121689 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121691) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121692));
    vlTOPp->mkMac__DOT__x___05Fh128635 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128637) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128638));
    vlTOPp->mkMac__DOT__y___05Fh60602 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x17U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60411));
    vlTOPp->mkMac__DOT__x___05Fh114936 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114938) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114939));
    vlTOPp->mkMac__DOT__y___05Fh121631 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121689) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121690));
    vlTOPp->mkMac__DOT__y___05Fh128577 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128635) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128636));
    vlTOPp->mkMac__DOT__y___05Fh60793 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x18U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60602));
    vlTOPp->mkMac__DOT__y___05Fh114878 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114936) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114937));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2826 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121630) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121631)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121436) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121437)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2825));
    vlTOPp->mkMac__DOT__y___05Fh121884 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121631));
    vlTOPp->mkMac__DOT__y___05Fh121886 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121631));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2747 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128576) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128577)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128382) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128383)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2746));
    vlTOPp->mkMac__DOT__y___05Fh128830 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128577));
    vlTOPp->mkMac__DOT__y___05Fh128832 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128577));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d902 
        = ((0x2000000U & ((0xfe000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60793) 
                             << 0x19U))) | ((0x1000000U 
                                             & ((0xff000000U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60602) 
                                                   << 0x18U))) 
                                            | ((0x800000U 
                                                & ((0xff800000U 
                                                    & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh60411) 
                                                    << 0x17U))) 
                                               | ((0x400000U 
                                                   & ((0xffc00000U 
                                                       & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh60220) 
                                                       << 0x16U))) 
                                                  | vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d900))));
    vlTOPp->mkMac__DOT__y___05Fh60984 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x19U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60793));
    vlTOPp->mkMac__DOT__y___05Fh115131 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114878));
    vlTOPp->mkMac__DOT__y___05Fh115133 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114878));
    vlTOPp->mkMac__DOT__x___05Fh121883 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121885) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121886));
    vlTOPp->mkMac__DOT__x___05Fh128829 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128831) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128832));
    vlTOPp->mkMac__DOT__y___05Fh61175 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x1aU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60984));
    vlTOPp->mkMac__DOT__x___05Fh115130 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115132) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115133));
    vlTOPp->mkMac__DOT__y___05Fh121825 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121883) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121884));
    vlTOPp->mkMac__DOT__y___05Fh128771 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128829) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128830));
    vlTOPp->mkMac__DOT__y___05Fh61366 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x1bU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61175));
    vlTOPp->mkMac__DOT__y___05Fh115072 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115130) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115131));
    vlTOPp->mkMac__DOT__y___05Fh122078 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121825));
    vlTOPp->mkMac__DOT__y___05Fh122080 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121825));
    vlTOPp->mkMac__DOT__y___05Fh129024 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128771));
    vlTOPp->mkMac__DOT__y___05Fh129026 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128771));
    vlTOPp->mkMac__DOT__y___05Fh61557 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x1cU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61366));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2669 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115071) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115072)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114877) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114878)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2668));
    vlTOPp->mkMac__DOT__y___05Fh115325 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115072));
    vlTOPp->mkMac__DOT__y___05Fh115327 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115072));
    vlTOPp->mkMac__DOT__x___05Fh122077 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122079) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122080));
    vlTOPp->mkMac__DOT__x___05Fh129023 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129025) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129026));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d904 
        = ((0x20000000U & ((0xe0000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh61557) 
                              << 0x1dU))) | ((0x10000000U 
                                              & ((0xf0000000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh61366) 
                                                  << 0x1cU))) 
                                             | ((0x8000000U 
                                                 & ((0xf8000000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh61175) 
                                                     << 0x1bU))) 
                                                | ((0x4000000U 
                                                    & ((0xfc000000U 
                                                        & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh60984) 
                                                        << 0x1aU))) 
                                                   | vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d902))));
    vlTOPp->mkMac__DOT__y___05Fh61748 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x1dU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61557));
    vlTOPp->mkMac__DOT__x___05Fh115324 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115326) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115327));
    vlTOPp->mkMac__DOT__y___05Fh122019 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122077) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122078));
    vlTOPp->mkMac__DOT__y___05Fh128965 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129023) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129024));
    vlTOPp->mkMac__DOT__y___05Fh61939 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5 
                                          >> 0x1eU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61748));
    vlTOPp->mkMac__DOT__y___05Fh115266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115324) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115325));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2827 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122018) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122019)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121824) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121825)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2826));
    vlTOPp->mkMac__DOT__y___05Fh122272 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122019));
    vlTOPp->mkMac__DOT__y___05Fh122274 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122019));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2748 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128964) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128965)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128770) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128771)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2747));
    vlTOPp->mkMac__DOT__y___05Fh129218 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128965));
    vlTOPp->mkMac__DOT__y___05Fh129220 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128965));
    vlTOPp->mkMac__DOT__product___05Fh1219 = ((0x80000000U 
                                               & ((0x80000000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh61939) 
                                                   << 0x1fU))) 
                                              | ((0x40000000U 
                                                  & ((0xc0000000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1131___05Fq5) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh61748) 
                                                      << 0x1eU))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_b_BIT_7_THEN_IF_INV_INV_SEXT_b_BITS___05FETC___05F_d904));
    vlTOPp->mkMac__DOT__y___05Fh115519 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115266));
    vlTOPp->mkMac__DOT__y___05Fh115521 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115266));
    vlTOPp->mkMac__DOT__x___05Fh122271 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122273) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122274));
    vlTOPp->mkMac__DOT__x___05Fh129217 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129219) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129220));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
        = ((IData)(vlTOPp->mkMac__DOT__a_BIT_7_XOR_b_BIT_7___05F_d6)
            ? vlTOPp->mkMac__DOT__product___05Fh1219
            : vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1131);
    vlTOPp->mkMac__DOT__x___05Fh115518 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115520) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115521));
    vlTOPp->mkMac__DOT__y___05Fh122213 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122271) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122272));
    vlTOPp->mkMac__DOT__y___05Fh129159 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129217) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129218));
    vlTOPp->mkMac__DOT__x___05Fh67801 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh67995 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh67413 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh67607 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh68056 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh67025 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh67219 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh66637 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh66831 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh66249 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh66443 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh65861 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh66055 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh67862 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh65473 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh65667 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh65085 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh65279 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh64697 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh64891 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh64309 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh64503 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh67668 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh63921 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh64115 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh63533 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh63727 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh63145 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh63339 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh67474 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh62757 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh62951 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh62369 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh62563 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 3U));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_ETC___05Fq13 
        = ((1U & (vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                  ^ vlTOPp->mkMac__DOT__c)) ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh62175 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                ^ vlTOPp->mkMac__DOT__c) 
                                               >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh67280 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh67086 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh66892 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh66698 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh66504 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh66310 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh66116 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh65922 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh65728 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh65534 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh65340 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh65146 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh64952 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh64758 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh64564 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh64370 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh64176 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh63982 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh63788 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh63594 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh63400 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh63206 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh63012 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh62818 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh62624 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh62430 = (1U & ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                                & vlTOPp->mkMac__DOT__c) 
                                               >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh62176 = (1U & (vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                               & vlTOPp->mkMac__DOT__c));
    vlTOPp->mkMac__DOT__y___05Fh115460 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115518) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115519));
    vlTOPp->mkMac__DOT__y___05Fh122466 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122213));
    vlTOPp->mkMac__DOT__y___05Fh122468 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122213));
    vlTOPp->mkMac__DOT__y___05Fh129412 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129159));
    vlTOPp->mkMac__DOT__y___05Fh129414 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129159));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1188 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh62175) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh62176)) 
            << 1U) | (1U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_ETC___05Fq13));
    vlTOPp->mkMac__DOT__y___05Fh62429 = ((vlTOPp->mkMac__DOT__c 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62176));
    vlTOPp->mkMac__DOT__y___05Fh62431 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62176));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2670 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115459) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115460)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115265) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115266)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2669));
    vlTOPp->mkMac__DOT__y___05Fh115713 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115460));
    vlTOPp->mkMac__DOT__y___05Fh115715 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115460));
    vlTOPp->mkMac__DOT__x___05Fh122465 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122467) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122468));
    vlTOPp->mkMac__DOT__x___05Fh129411 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129413) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129414));
    vlTOPp->mkMac__DOT__x___05Fh62428 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62430) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62431));
    vlTOPp->mkMac__DOT__x___05Fh115712 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115714) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115715));
    vlTOPp->mkMac__DOT__y___05Fh122407 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122465) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122466));
    vlTOPp->mkMac__DOT__y___05Fh129353 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129411) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129412));
    vlTOPp->mkMac__DOT__y___05Fh62370 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62428) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62429));
    vlTOPp->mkMac__DOT__y___05Fh115654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115712) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115713));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2828 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122406) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122407)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122212) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122213)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2827));
    vlTOPp->mkMac__DOT__y___05Fh122660 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122407));
    vlTOPp->mkMac__DOT__y___05Fh122662 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122407));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2749 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129352) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129353)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129158) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129159)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2748));
    vlTOPp->mkMac__DOT__y___05Fh129606 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129353));
    vlTOPp->mkMac__DOT__y___05Fh129608 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129353));
    vlTOPp->mkMac__DOT__y___05Fh62623 = ((vlTOPp->mkMac__DOT__c 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62370));
    vlTOPp->mkMac__DOT__y___05Fh62625 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62370));
    vlTOPp->mkMac__DOT__y___05Fh115907 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115654));
    vlTOPp->mkMac__DOT__y___05Fh115909 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115654));
    vlTOPp->mkMac__DOT__x___05Fh122659 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122661) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122662));
    vlTOPp->mkMac__DOT__x___05Fh129605 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129607) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129608));
    vlTOPp->mkMac__DOT__x___05Fh62622 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62624) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62625));
    vlTOPp->mkMac__DOT__x___05Fh115906 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115908) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115909));
    vlTOPp->mkMac__DOT__y___05Fh122601 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122659) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122660));
    vlTOPp->mkMac__DOT__y___05Fh129547 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129605) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129606));
    vlTOPp->mkMac__DOT__y___05Fh62564 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62622) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62623));
    vlTOPp->mkMac__DOT__y___05Fh115848 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115906) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115907));
    vlTOPp->mkMac__DOT__y___05Fh122854 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122601));
    vlTOPp->mkMac__DOT__y___05Fh122856 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122601));
    vlTOPp->mkMac__DOT__y___05Fh129800 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129547));
    vlTOPp->mkMac__DOT__y___05Fh129802 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129547));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1189 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh62563) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh62564)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh62369) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh62370)) 
                       << 2U) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1188)));
    vlTOPp->mkMac__DOT__y___05Fh62817 = ((vlTOPp->mkMac__DOT__c 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62564));
    vlTOPp->mkMac__DOT__y___05Fh62819 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62564));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2671 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115847) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115848)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115653) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115654)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2670));
    vlTOPp->mkMac__DOT__y___05Fh116101 = ((vlTOPp->mkMac__DOT__mant_y___05Fh68227 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115848));
    vlTOPp->mkMac__DOT__y___05Fh116103 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115848));
    vlTOPp->mkMac__DOT__x___05Fh122853 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122855) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122856));
    vlTOPp->mkMac__DOT__x___05Fh129799 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129801) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129802));
    vlTOPp->mkMac__DOT__x___05Fh62816 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62818) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62819));
    vlTOPp->mkMac__DOT__x___05Fh116100 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116102) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116103));
    vlTOPp->mkMac__DOT__y___05Fh122795 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122853) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122854));
    vlTOPp->mkMac__DOT__y___05Fh129741 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129799) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129800));
    vlTOPp->mkMac__DOT__y___05Fh62758 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh62816) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh62817));
    vlTOPp->mkMac__DOT__y___05Fh116042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116100) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116101));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2829 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122794) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122795)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122600) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122601)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2828));
    vlTOPp->mkMac__DOT__y___05Fh123048 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122795));
    vlTOPp->mkMac__DOT__y___05Fh123050 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122795));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2750 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129740) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129741)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129546) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129547)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2749));
    vlTOPp->mkMac__DOT__y___05Fh129994 = ((vlTOPp->mkMac__DOT__mant_x___05Fh68226 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129741));
    vlTOPp->mkMac__DOT__y___05Fh129996 = ((vlTOPp->mkMac__DOT__INV_mant_y8227___05Fq9 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129741));
    vlTOPp->mkMac__DOT__y___05Fh63011 = ((vlTOPp->mkMac__DOT__c 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62758));
    vlTOPp->mkMac__DOT__y___05Fh63013 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62758));
    vlTOPp->mkMac__DOT__x___05Fh123047 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh123049) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh123050));
    vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2831 
        = ((IData)(vlTOPp->mkMac__DOT__a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_BIT___05FETC___05F_d1207)
            ? vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2671
            : ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d1996)
                ? vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2750
                : vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d2829));
    vlTOPp->mkMac__DOT__x___05Fh129993 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129995) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129996));
    vlTOPp->mkMac__DOT__x___05Fh63010 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63012) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63013));
    vlTOPp->mkMac__DOT__y___05Fh122989 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh123047) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh123048));
    vlTOPp->mkMac__DOT__y___05Fh129935 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129993) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129994));
    vlTOPp->mkMac__DOT__y___05Fh62952 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63010) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63011));
    vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_ETC___05F_d2559 
        = ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_IF_ETC___05F_d1996)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh129934) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129935))
            : ((IData)(vlTOPp->mkMac__DOT__x___05Fh122988) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122989)));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1190 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh62951) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh62952)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh62757) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh62758)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1189)));
    vlTOPp->mkMac__DOT__y___05Fh63205 = ((vlTOPp->mkMac__DOT__c 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62952));
    vlTOPp->mkMac__DOT__y___05Fh63207 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh62952));
    vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2560 
        = ((IData)(vlTOPp->mkMac__DOT__a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_BIT___05FETC___05F_d1207)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh116041) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh116042))
            : (IData)(vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_IF_b_BIT_6_208_THEN_IF_ETC___05F_d2559));
    vlTOPp->mkMac__DOT__x___05Fh63204 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63206) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63207));
    if (vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2560) {
        vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05Fq15 
            = vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh130126;
        vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
            = (((IData)(vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2560) 
                << 0x1eU) | (0x3fffffffU & (vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2831 
                                            >> 1U)));
    } else {
        vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05Fq15 
            = vlTOPp->mkMac__DOT__exp_x___05Fh68224;
        vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
            = vlTOPp->mkMac__DOT__IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_08_B_ETC___05F_d2831;
    }
    vlTOPp->mkMac__DOT__y___05Fh63146 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63204) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63205));
    vlTOPp->mkMac__DOT__IF_IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ___05FETC___05Fq14 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__y___05Fh134248 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                                 >> 8U) 
                                                & (vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                                   >> 7U)));
    vlTOPp->mkMac__DOT__y___05Fh63399 = ((vlTOPp->mkMac__DOT__c 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63146));
    vlTOPp->mkMac__DOT__y___05Fh63401 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63146));
    vlTOPp->mkMac__DOT__y___05Fh134436 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh134248));
    vlTOPp->mkMac__DOT__x___05Fh63398 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63400) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63401));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2912 
        = ((0x400U & ((0xfffffc00U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134436) 
                         << 0xaU))) | ((0x200U & ((0xfffffe00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh134248) 
                                                   << 9U))) 
                                       | ((0x100U & 
                                           ((0xffffff00U 
                                             & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                            ^ (0xffffff00U 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                                  << 1U)))) 
                                          | ((0x80U 
                                              & ((~ 
                                                  (vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                                   >> 7U)) 
                                                 << 7U)) 
                                             | ((0x7eU 
                                                 & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                | (1U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ___05FETC___05Fq14))))));
    vlTOPp->mkMac__DOT__y___05Fh134624 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134436));
    vlTOPp->mkMac__DOT__y___05Fh63340 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63398) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63399));
    vlTOPp->mkMac__DOT__y___05Fh134812 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134624));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1191 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh63339) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh63340)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh63145) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh63146)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1190)));
    vlTOPp->mkMac__DOT__y___05Fh63593 = ((vlTOPp->mkMac__DOT__c 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63340));
    vlTOPp->mkMac__DOT__y___05Fh63595 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63340));
    vlTOPp->mkMac__DOT__y___05Fh135000 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134812));
    vlTOPp->mkMac__DOT__x___05Fh63592 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63594) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63595));
    vlTOPp->mkMac__DOT__y___05Fh135188 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135000));
    vlTOPp->mkMac__DOT__y___05Fh63534 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63592) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63593));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2914 
        = ((0x4000U & ((0xffffc000U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135188) 
                          << 0xeU))) | ((0x2000U & 
                                         ((0xffffe000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135000) 
                                             << 0xdU))) 
                                        | ((0x1000U 
                                            & ((0xfffff000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134812) 
                                                  << 0xcU))) 
                                           | ((0x800U 
                                               & ((0xfffff800U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh134624) 
                                                   << 0xbU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2912)))));
    vlTOPp->mkMac__DOT__y___05Fh135376 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135188));
    vlTOPp->mkMac__DOT__y___05Fh63787 = ((vlTOPp->mkMac__DOT__c 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63534));
    vlTOPp->mkMac__DOT__y___05Fh63789 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63534));
    vlTOPp->mkMac__DOT__y___05Fh135564 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135376));
    vlTOPp->mkMac__DOT__x___05Fh63786 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63788) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63789));
    vlTOPp->mkMac__DOT__y___05Fh135752 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135564));
    vlTOPp->mkMac__DOT__y___05Fh63728 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63786) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63787));
    vlTOPp->mkMac__DOT__y___05Fh135940 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135752));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1192 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh63727) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh63728)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh63533) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh63534)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1191)));
    vlTOPp->mkMac__DOT__y___05Fh63981 = ((vlTOPp->mkMac__DOT__c 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63728));
    vlTOPp->mkMac__DOT__y___05Fh63983 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh63728));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2916 
        = ((0x40000U & ((0xfffc0000U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135940) 
                           << 0x12U))) | ((0x20000U 
                                           & ((0xfffe0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135752) 
                                                 << 0x11U))) 
                                          | ((0x10000U 
                                              & ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh135564) 
                                                  << 0x10U))) 
                                             | ((0x8000U 
                                                 & ((0xffff8000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh135376) 
                                                     << 0xfU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2914)))));
    vlTOPp->mkMac__DOT__y___05Fh136128 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135940));
    vlTOPp->mkMac__DOT__x___05Fh63980 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63982) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63983));
    vlTOPp->mkMac__DOT__y___05Fh136316 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136128));
    vlTOPp->mkMac__DOT__y___05Fh63922 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh63980) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh63981));
    vlTOPp->mkMac__DOT__y___05Fh136504 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136316));
    vlTOPp->mkMac__DOT__y___05Fh64175 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh63922));
    vlTOPp->mkMac__DOT__y___05Fh64177 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh63922));
    vlTOPp->mkMac__DOT__y___05Fh136692 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136504));
    vlTOPp->mkMac__DOT__x___05Fh64174 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64176) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64177));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2918 
        = ((0x400000U & ((0xffc00000U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh136692) 
                            << 0x16U))) | ((0x200000U 
                                            & ((0xffe00000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh136504) 
                                                  << 0x15U))) 
                                           | ((0x100000U 
                                               & ((0xfff00000U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh136316) 
                                                   << 0x14U))) 
                                              | ((0x80000U 
                                                  & ((0xfff80000U 
                                                      & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh136128) 
                                                      << 0x13U))) 
                                                 | vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2916))));
    vlTOPp->mkMac__DOT__y___05Fh136880 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136692));
    vlTOPp->mkMac__DOT__y___05Fh64116 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64174) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64175));
    vlTOPp->mkMac__DOT__y___05Fh137068 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136880));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1193 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh64115) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh64116)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh63921) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh63922)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1192)));
    vlTOPp->mkMac__DOT__y___05Fh64369 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64116));
    vlTOPp->mkMac__DOT__y___05Fh64371 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64116));
    vlTOPp->mkMac__DOT__y___05Fh137256 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137068));
    vlTOPp->mkMac__DOT__x___05Fh64368 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64370) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64371));
    vlTOPp->mkMac__DOT__y___05Fh137444 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137256));
    vlTOPp->mkMac__DOT__y___05Fh64310 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64368) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64369));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2920 
        = ((0x4000000U & ((0xfc000000U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137444) 
                             << 0x1aU))) | ((0x2000000U 
                                             & ((0xfe000000U 
                                                 & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137256) 
                                                   << 0x19U))) 
                                            | ((0x1000000U 
                                                & ((0xff000000U 
                                                    & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh137068) 
                                                    << 0x18U))) 
                                               | ((0x800000U 
                                                   & ((0xff800000U 
                                                       & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh136880) 
                                                       << 0x17U))) 
                                                  | vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2918))));
    vlTOPp->mkMac__DOT__y___05Fh137632 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137444));
    vlTOPp->mkMac__DOT__y___05Fh64563 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64310));
    vlTOPp->mkMac__DOT__y___05Fh64565 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64310));
    vlTOPp->mkMac__DOT__y___05Fh137820 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137632));
    vlTOPp->mkMac__DOT__x___05Fh64562 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64564) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64565));
    vlTOPp->mkMac__DOT__y___05Fh138008 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137820));
    vlTOPp->mkMac__DOT__y___05Fh64504 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64562) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64563));
    vlTOPp->mkMac__DOT__y___05Fh138196 = ((vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh138008));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1194 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh64503) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh64504)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh64309) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh64310)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1193)));
    vlTOPp->mkMac__DOT__y___05Fh64757 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64504));
    vlTOPp->mkMac__DOT__y___05Fh64759 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64504));
    vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2922 
        = ((0x40000000U & ((0xc0000000U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh138196) 
                              << 0x1eU))) | ((0x20000000U 
                                              & ((0xe0000000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh138008) 
                                                  << 0x1dU))) 
                                             | ((0x10000000U 
                                                 & ((0xf0000000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh137820) 
                                                     << 0x1cU))) 
                                                | ((0x8000000U 
                                                    & ((0xf8000000U 
                                                        & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh137632) 
                                                        << 0x1bU))) 
                                                   | vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2920))));
    vlTOPp->mkMac__DOT__x___05Fh64756 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64758) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64759));
    vlTOPp->mkMac__DOT__IF_IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ___05FETC___05Fq16 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834)
            ? vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2922
            : vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05F_d2834);
    vlTOPp->mkMac__DOT__y___05Fh64698 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64756) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64757));
    vlTOPp->mkMac__DOT__x___05Fh68197 = (((IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109078) 
                                          << 0x1fU) 
                                         | ((0x7f800000U 
                                             & (vlTOPp->mkMac__DOT__IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ_c_0_ETC___05Fq15 
                                                << 0x17U)) 
                                            | (0x7fffffU 
                                               & (vlTOPp->mkMac__DOT__IF_IF_IF_a_BIT_15_204_XOR_b_BIT_15_205_206_EQ___05FETC___05Fq16 
                                                  >> 7U))));
    vlTOPp->mkMac__DOT__y___05Fh64951 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64698));
    vlTOPp->mkMac__DOT__y___05Fh64953 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64698));
    vlTOPp->mkMac__DOT__x___05Fh64950 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64952) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64953));
    vlTOPp->mkMac__DOT__y___05Fh64892 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh64950) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh64951));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1195 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh64891) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh64892)) 
            << 0xfU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh64697) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh64698)) 
                         << 0xeU) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1194)));
    vlTOPp->mkMac__DOT__y___05Fh65145 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0xfU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64892));
    vlTOPp->mkMac__DOT__y___05Fh65147 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0xfU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh64892));
    vlTOPp->mkMac__DOT__x___05Fh65144 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65146) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65147));
    vlTOPp->mkMac__DOT__y___05Fh65086 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65144) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65145));
    vlTOPp->mkMac__DOT__y___05Fh65339 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x10U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65086));
    vlTOPp->mkMac__DOT__y___05Fh65341 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x10U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65086));
    vlTOPp->mkMac__DOT__x___05Fh65338 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65340) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65341));
    vlTOPp->mkMac__DOT__y___05Fh65280 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65338) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65339));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1196 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh65279) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh65280)) 
            << 0x11U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh65085) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh65086)) 
                          << 0x10U) | (IData)(vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1195)));
    vlTOPp->mkMac__DOT__y___05Fh65533 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x11U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65280));
    vlTOPp->mkMac__DOT__y___05Fh65535 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x11U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65280));
    vlTOPp->mkMac__DOT__x___05Fh65532 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65534) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65535));
    vlTOPp->mkMac__DOT__y___05Fh65474 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65532) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65533));
    vlTOPp->mkMac__DOT__y___05Fh65727 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x12U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65474));
    vlTOPp->mkMac__DOT__y___05Fh65729 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x12U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65474));
    vlTOPp->mkMac__DOT__x___05Fh65726 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65728) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65729));
    vlTOPp->mkMac__DOT__y___05Fh65668 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65726) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65727));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1197 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh65667) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh65668)) 
            << 0x13U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh65473) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh65474)) 
                          << 0x12U) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1196));
    vlTOPp->mkMac__DOT__y___05Fh65921 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x13U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65668));
    vlTOPp->mkMac__DOT__y___05Fh65923 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x13U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65668));
    vlTOPp->mkMac__DOT__x___05Fh65920 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65922) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65923));
    vlTOPp->mkMac__DOT__y___05Fh65862 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh65920) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh65921));
    vlTOPp->mkMac__DOT__y___05Fh66115 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x14U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65862));
    vlTOPp->mkMac__DOT__y___05Fh66117 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x14U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh65862));
    vlTOPp->mkMac__DOT__x___05Fh66114 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66116) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66117));
    vlTOPp->mkMac__DOT__y___05Fh66056 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66114) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66115));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1198 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh66055) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh66056)) 
            << 0x15U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh65861) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh65862)) 
                          << 0x14U) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1197));
    vlTOPp->mkMac__DOT__y___05Fh66309 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x15U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66056));
    vlTOPp->mkMac__DOT__y___05Fh66311 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x15U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66056));
    vlTOPp->mkMac__DOT__x___05Fh66308 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66310) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66311));
    vlTOPp->mkMac__DOT__y___05Fh66250 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66308) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66309));
    vlTOPp->mkMac__DOT__y___05Fh66503 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x16U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66250));
    vlTOPp->mkMac__DOT__y___05Fh66505 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x16U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66250));
    vlTOPp->mkMac__DOT__x___05Fh66502 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66504) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66505));
    vlTOPp->mkMac__DOT__y___05Fh66444 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66502) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66503));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1199 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh66443) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh66444)) 
            << 0x17U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh66249) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh66250)) 
                          << 0x16U) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1198));
    vlTOPp->mkMac__DOT__y___05Fh66697 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x17U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66444));
    vlTOPp->mkMac__DOT__y___05Fh66699 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x17U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66444));
    vlTOPp->mkMac__DOT__x___05Fh66696 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66698) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66699));
    vlTOPp->mkMac__DOT__y___05Fh66638 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66696) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66697));
    vlTOPp->mkMac__DOT__y___05Fh66891 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x18U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66638));
    vlTOPp->mkMac__DOT__y___05Fh66893 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x18U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66638));
    vlTOPp->mkMac__DOT__x___05Fh66890 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66892) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66893));
    vlTOPp->mkMac__DOT__y___05Fh66832 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh66890) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh66891));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1200 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh66831) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh66832)) 
            << 0x19U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh66637) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh66638)) 
                          << 0x18U) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1199));
    vlTOPp->mkMac__DOT__y___05Fh67085 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x19U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66832));
    vlTOPp->mkMac__DOT__y___05Fh67087 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x19U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh66832));
    vlTOPp->mkMac__DOT__x___05Fh67084 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67086) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67087));
    vlTOPp->mkMac__DOT__y___05Fh67026 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67084) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67085));
    vlTOPp->mkMac__DOT__y___05Fh67279 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x1aU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67026));
    vlTOPp->mkMac__DOT__y___05Fh67281 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x1aU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67026));
    vlTOPp->mkMac__DOT__x___05Fh67278 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67280) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67281));
    vlTOPp->mkMac__DOT__y___05Fh67220 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67278) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67279));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1201 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67219) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67220)) 
            << 0x1bU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67025) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67026)) 
                          << 0x1aU) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1200));
    vlTOPp->mkMac__DOT__y___05Fh67473 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x1bU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67220));
    vlTOPp->mkMac__DOT__y___05Fh67475 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x1bU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67220));
    vlTOPp->mkMac__DOT__x___05Fh67472 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67474) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67475));
    vlTOPp->mkMac__DOT__y___05Fh67414 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67472) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67473));
    vlTOPp->mkMac__DOT__y___05Fh67667 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x1cU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67414));
    vlTOPp->mkMac__DOT__y___05Fh67669 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x1cU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67414));
    vlTOPp->mkMac__DOT__x___05Fh67666 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67668) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67669));
    vlTOPp->mkMac__DOT__y___05Fh67608 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67666) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67667));
    vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1202 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67607) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67608)) 
            << 0x1dU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67413) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67414)) 
                          << 0x1cU) | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1201));
    vlTOPp->mkMac__DOT__y___05Fh67861 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x1dU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67608));
    vlTOPp->mkMac__DOT__y___05Fh67863 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x1dU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67608));
    vlTOPp->mkMac__DOT__x___05Fh67860 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67862) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67863));
    vlTOPp->mkMac__DOT__y___05Fh67802 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh67860) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh67861));
    vlTOPp->mkMac__DOT__y___05Fh68055 = ((vlTOPp->mkMac__DOT__c 
                                          >> 0x1eU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67802));
    vlTOPp->mkMac__DOT__y___05Fh68057 = ((vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d906 
                                          >> 0x1eU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh67802));
    vlTOPp->mkMac__DOT__x___05Fh68054 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68056) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68057));
    vlTOPp->mkMac__DOT__y___05Fh67996 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68054) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68055));
    vlTOPp->mkMac__DOT__x___05Fh304 = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67995) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67996)) 
                                        << 0x1fU) | 
                                       ((((IData)(vlTOPp->mkMac__DOT__x___05Fh67801) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh67802)) 
                                         << 0x1eU) 
                                        | vlTOPp->mkMac__DOT__IF_a_BIT_7_XOR_b_BIT_7_THEN_INV_IF_IF_b_BIT_7___05FETC___05F_d1202));
    vlTOPp->mkMac__DOT__result_D_IN = ((IData)(vlTOPp->mkMac__DOT__s)
                                        ? vlTOPp->mkMac__DOT__x___05Fh304
                                        : vlTOPp->mkMac__DOT__x___05Fh68197);
}

VL_INLINE_OPT void Vtop::_combo__TOP__5(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__5\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__s_EN = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__s_D_IN = vlTOPp->s1_or_s2_tcs;
    vlTOPp->mkMac__DOT__result_EN = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__c_EN = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__c_D_IN = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__b_EN = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__b_D_IN = vlTOPp->get_B_y;
    vlTOPp->mkMac__DOT__a_EN = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__a_D_IN = vlTOPp->get_A_x;
}

void Vtop::_eval(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_combo__TOP__2(vlSymsp);
    if (((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK)))) {
        vlTOPp->_sequent__TOP__4(vlSymsp);
    }
    vlTOPp->_combo__TOP__5(vlSymsp);
    // Final
    vlTOPp->__Vclklast__TOP__CLK = vlTOPp->CLK;
}

VL_INLINE_OPT QData Vtop::_change_request(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vtop::_change_request_1(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request_1\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vtop::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((CLK & 0xfeU))) {
        Verilated::overWidthError("CLK");}
    if (VL_UNLIKELY((RST_N & 0xfeU))) {
        Verilated::overWidthError("RST_N");}
    if (VL_UNLIKELY((EN_get_A & 0xfeU))) {
        Verilated::overWidthError("EN_get_A");}
    if (VL_UNLIKELY((EN_get_B & 0xfeU))) {
        Verilated::overWidthError("EN_get_B");}
    if (VL_UNLIKELY((EN_get_C & 0xfeU))) {
        Verilated::overWidthError("EN_get_C");}
    if (VL_UNLIKELY((s1_or_s2_tcs & 0xfeU))) {
        Verilated::overWidthError("s1_or_s2_tcs");}
    if (VL_UNLIKELY((EN_s1_or_s2 & 0xfeU))) {
        Verilated::overWidthError("EN_s1_or_s2");}
    if (VL_UNLIKELY((EN_out_result & 0xfeU))) {
        Verilated::overWidthError("EN_out_result");}
}
#endif  // VL_DEBUG
