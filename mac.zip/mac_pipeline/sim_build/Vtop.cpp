// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop.h"
#include "Vtop__Syms.h"

#include "verilated_dpi.h"

//==========

void Vtop::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vtop::eval\n"); );
    Vtop__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac_pipeline/verilog/mkMac.v", 46, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vtop::_eval_initial_loop(Vtop__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac_pipeline/verilog/mkMac.v", 46, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vtop::_combo__TOP__2(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__2\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__CLK = vlTOPp->CLK;
    vlTOPp->mkMac__DOT__RST_N = vlTOPp->RST_N;
    vlTOPp->mkMac__DOT__get_A_x = vlTOPp->get_A_x;
    vlTOPp->mkMac__DOT__EN_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__get_B_y = vlTOPp->get_B_y;
    vlTOPp->mkMac__DOT__EN_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__get_C_z = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__EN_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__s1_or_s2_tcs = vlTOPp->s1_or_s2_tcs;
    vlTOPp->mkMac__DOT__EN_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__EN_out_result = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__WILL_FIRE_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__WILL_FIRE_out_result = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fwrite_1 
        = (0x10000U | (IData)(vlTOPp->get_A_x));
    vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fwrite_1 
        = (0x10000U | (IData)(vlTOPp->get_B_y));
    vlTOPp->mkMac__DOT__tcs_ififo_rv_port1___05Fwrite_1 
        = (2U | (IData)(vlTOPp->s1_or_s2_tcs));
}

VL_INLINE_OPT void Vtop::_sequent__TOP__4(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_sequent__TOP__4\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__cdummy_EN) {
            vlTOPp->mkMac__DOT__cdummy = vlTOPp->mkMac__DOT__cdummy_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__cdummy = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__tcs_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__tcs_ififo_rv = vlTOPp->mkMac__DOT__tcs_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__tcs_ififo_rv = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__result_ofifo_rv_EN) {
            vlTOPp->mkMac__DOT__result_ofifo_rv = vlTOPp->mkMac__DOT__result_ofifo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__result_ofifo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__product_ofifo_rv_EN) {
            vlTOPp->mkMac__DOT__product_ofifo_rv = vlTOPp->mkMac__DOT__product_ofifo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__product_ofifo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__c_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__c_ififo_rv = vlTOPp->mkMac__DOT__c_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__b_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__b_ififo_rv = vlTOPp->mkMac__DOT__b_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__b_ififo_rv = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__a_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__a_ififo_rv = vlTOPp->mkMac__DOT__a_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__a_ififo_rv = 0U;
    }
    vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(vlTOPp->mkMac__DOT__cdummy)));
    vlTOPp->mkMac__DOT__CAN_FIRE_s1_or_s2 = (1U & (~ 
                                                   ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                                                    >> 1U)));
    vlTOPp->mkMac__DOT__RDY_s1_or_s2 = (1U & (~ ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                                                 >> 1U)));
    vlTOPp->mkMac__DOT__CAN_FIRE_out_result = (1U & (IData)(
                                                            (vlTOPp->mkMac__DOT__result_ofifo_rv 
                                                             >> 0x20U)));
    vlTOPp->mkMac__DOT__out_result = (IData)(vlTOPp->mkMac__DOT__result_ofifo_rv);
    vlTOPp->mkMac__DOT__RDY_out_result = (1U & (IData)(
                                                       (vlTOPp->mkMac__DOT__result_ofifo_rv 
                                                        >> 0x20U)));
    vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
        = (IData)(vlTOPp->mkMac__DOT__product_ofifo_rv);
    vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
        = (IData)(vlTOPp->mkMac__DOT__c_ififo_rv);
    vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2 
        = (0xffffU & vlTOPp->mkMac__DOT__b_ififo_rv);
    vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1 
        = (0xffffU & vlTOPp->mkMac__DOT__a_ififo_rv);
    vlTOPp->RDY_s1_or_s2 = vlTOPp->mkMac__DOT__RDY_s1_or_s2;
    vlTOPp->out_result = vlTOPp->mkMac__DOT__out_result;
    vlTOPp->RDY_out_result = vlTOPp->mkMac__DOT__RDY_out_result;
    vlTOPp->mkMac__DOT__mant_x___05Fh115945 = (0x40000000U 
                                               | (0x3fffff80U 
                                                  & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                     << 7U)));
    vlTOPp->mkMac__DOT__exp_x___05Fh115943 = (0xffU 
                                              & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh115565 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh115759 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh115177 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh115371 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh115820 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh114789 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh114983 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh114401 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114595 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh114013 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh114207 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh113625 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh113819 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh115626 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh113237 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh113431 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh112849 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh113043 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh112461 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh112655 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh112073 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh112267 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh115432 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh111685 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh111879 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh111297 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh111491 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh110909 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh111103 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh115238 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh110521 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh110715 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh110133 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh110327 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_BITS_31_TO_0_BIT_0_XOR_c_i_ETC___05Fq17 
        = ((1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                  ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh109937 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh115044 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh114850 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh114656 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114462 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2024 
        = ((1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                  >> 0x1fU)) == (1U & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                       >> 0x1fU)));
    vlTOPp->mkMac__DOT__x___05Fh114268 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh114074 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh113880 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh113686 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh113492 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh113298 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh113104 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh112910 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh112716 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh112522 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh112328 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh112134 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh111940 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh111746 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh111552 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh111358 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh111164 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh110970 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh110776 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh110582 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh110388 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh110194 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh109938 = (1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4));
    vlTOPp->mkMac__DOT__mant_y___05Fh115946 = (0x40000000U 
                                               | (0x3fffff80U 
                                                  & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                                     << 7U)));
    vlTOPp->mkMac__DOT__exp_y___05Fh115944 = (0xffU 
                                              & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                                 >> 0x17U));
    vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7 
        = (0xffU & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2));
    vlTOPp->mkMac__DOT__result_sign___05Fh61773 = (1U 
                                                   & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                                      >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh90723 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh90782 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh90535 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh90347 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh90159 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh90594 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh89971 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh89783 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh90406 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh89595 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26 
        = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                  ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                 >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh90218 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh90030 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh89842 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__y___05Fh89596 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 7U));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5 
        = (0xffU & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2008 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh109937) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh109938)) 
            << 1U) | (1U & vlTOPp->mkMac__DOT__IF_product_ofifo_rv_BITS_31_TO_0_BIT_0_XOR_c_i_ETC___05Fq17));
    vlTOPp->mkMac__DOT__y___05Fh110193 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh109938));
    vlTOPp->mkMac__DOT__y___05Fh110195 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh109938));
    vlTOPp->mkMac__DOT__x___05Fh116088 = (vlTOPp->mkMac__DOT__exp_y___05Fh115944 
                                          - vlTOPp->mkMac__DOT__exp_x___05Fh115943);
    vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F71_ETC___05F_d2029 
        = (vlTOPp->mkMac__DOT__exp_x___05Fh115943 <= vlTOPp->mkMac__DOT__exp_y___05Fh115944);
    vlTOPp->mkMac__DOT__x___05Fh116135 = (vlTOPp->mkMac__DOT__exp_x___05Fh115943 
                                          - vlTOPp->mkMac__DOT__exp_y___05Fh115944);
    vlTOPp->mkMac__DOT__ext_b___05Fh1687 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10 
        = ((IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh90956 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89595) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__y___05Fh89841 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__y___05Fh89843 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__mant_mult___05Fh65071 = (0x80U 
                                                 | ((0xffff0000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938) 
                                                    | ((0x7eU 
                                                        & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)) 
                                                       | (1U 
                                                          & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938))));
    vlTOPp->mkMac__DOT__ext_a___05Fh1686 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5));
    vlTOPp->mkMac__DOT__x___05Fh110192 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110194) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110195));
    vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh116085 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh116088)
            ? (vlTOPp->mkMac__DOT__mant_x___05Fh115945 
               >> vlTOPp->mkMac__DOT__x___05Fh116088)
            : 0U);
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608 
        = (0xffU & ((1U & ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F71_ETC___05F_d2029)) 
                           | (vlTOPp->mkMac__DOT__exp_y___05Fh115944 
                              <= vlTOPp->mkMac__DOT__exp_x___05Fh115943)))
                     ? (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                        >> 0x17U) : (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                     >> 0x17U)));
    vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh116108 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh116135)
            ? (vlTOPp->mkMac__DOT__mant_y___05Fh115946 
               >> vlTOPp->mkMac__DOT__x___05Fh116135)
            : 0U);
    vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 = (~ vlTOPp->mkMac__DOT__ext_b___05Fh1687);
    vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh92318 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh90956) 
                                               ^ vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10));
    vlTOPp->mkMac__DOT__y___05Fh91145 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90956) 
                                         & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10);
    vlTOPp->mkMac__DOT__x___05Fh89840 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89842) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89843));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh65071
            : 0U);
    vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 = (~ vlTOPp->mkMac__DOT__ext_a___05Fh1686);
    vlTOPp->mkMac__DOT__y___05Fh110134 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110192) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110193));
    vlTOPp->mkMac__DOT__mant_x___05Fh115950 = ((1U 
                                                & ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F71_ETC___05F_d2029)) 
                                                   | (vlTOPp->mkMac__DOT__exp_y___05Fh115944 
                                                      <= vlTOPp->mkMac__DOT__exp_x___05Fh115943)))
                                                ? vlTOPp->mkMac__DOT__mant_x___05Fh115945
                                                : vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh116085);
    vlTOPp->mkMac__DOT__exp_x___05Fh115948 = vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608;
    vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2611 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh137242 = (1U & (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                                 >> 1U) 
                                                & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)));
    vlTOPp->mkMac__DOT__mant_y___05Fh115951 = ((IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F71_ETC___05F_d2029)
                                                ? vlTOPp->mkMac__DOT__mant_y___05Fh115946
                                                : vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh116108);
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh3182 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                               >> 1U) 
                                              & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8));
    vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1538 
        = ((1U & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh92507 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                                         & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535);
    vlTOPp->mkMac__DOT__y___05Fh89784 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89840) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89841));
    vlTOPp->mkMac__DOT__x___05Fh69756 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh69374 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh69565 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh68992 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh69183 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh68610 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 2U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh68801 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh69816 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh69625 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh69434 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh69243 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh69052 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh68861 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 2U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh68611 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 1U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh19879 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6));
    vlTOPp->mkMac__DOT__y___05Fh110387 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110134));
    vlTOPp->mkMac__DOT__y___05Fh110389 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110134));
    vlTOPp->mkMac__DOT__y___05Fh137430 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh137242));
    vlTOPp->mkMac__DOT__x___05Fh122868 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh122480 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh122674 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2043 
        = (vlTOPp->mkMac__DOT__mant_x___05Fh115950 
           < vlTOPp->mkMac__DOT__mant_y___05Fh115951);
    vlTOPp->mkMac__DOT__x___05Fh122092 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh122286 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh122929 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh121704 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh121898 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh121316 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121510 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh120928 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh121122 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh122735 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh120540 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120734 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh120152 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120346 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh119764 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh119958 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh119376 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119570 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh122541 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh118988 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119182 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh118600 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118794 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118212 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118406 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh122347 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh117824 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh118018 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh117436 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117630 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_mant_x15950_BIT_0_XOR_mant_y15951_BIT_0_THE_ETC___05Fq14 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                  ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh117048 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh117242 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh122153 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh121959 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh121765 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh121571 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121377 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh121183 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh120989 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh120795 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120601 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh120407 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120213 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh120019 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh119825 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh119631 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119437 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh119243 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119049 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118855 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118661 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh118467 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118273 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh118079 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh117885 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh117691 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117497 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh117303 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh115951) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh117049 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                & vlTOPp->mkMac__DOT__mant_y___05Fh115951));
    vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 = 
        (~ vlTOPp->mkMac__DOT__mant_y___05Fh115951);
    vlTOPp->mkMac__DOT__y___05Fh3373 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3182));
    vlTOPp->mkMac__DOT__x___05Fh91144 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89783) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh90029 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh90031 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh68860 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68611));
    vlTOPp->mkMac__DOT__y___05Fh68862 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68611));
    vlTOPp->mkMac__DOT__y___05Fh20070 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh19879));
    vlTOPp->mkMac__DOT__x___05Fh110386 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110388) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110389));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2635 
        = ((8U & ((0xfffffff8U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137430) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137242) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2611))));
    vlTOPp->mkMac__DOT__y___05Fh137618 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh137430));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh116160 
        = (1U & ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2043)
                  ? (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                     >> 0x1fU) : (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                  >> 0x1fU)));
    vlTOPp->mkMac__DOT__y___05Fh117302 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117049));
    vlTOPp->mkMac__DOT__y___05Fh117304 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117049));
    vlTOPp->mkMac__DOT__x___05Fh129329 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh129523 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh136177 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh136371 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh129717 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh136565 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh128941 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh129135 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh135789 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh135983 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh128553 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh128747 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh135401 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh135595 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh129778 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh136626 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh128165 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128359 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh135013 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh135207 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh127777 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh127971 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh134625 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh134819 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh127389 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127583 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh134237 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh134431 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh129584 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh136432 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh127001 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127195 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh133849 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh134043 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh126613 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh126807 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh133461 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh133655 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh126225 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126419 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh133073 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh133267 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh125837 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh126031 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh132685 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh132879 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh129390 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh136238 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh125449 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125643 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh132297 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh132491 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh125061 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125255 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh131909 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh132103 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh124673 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh124867 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh131521 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh131715 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh129196 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh136044 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh124285 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124479 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh131133 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh131327 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_INV_INV_mant_y159513_BIT_0_XOR_mant_x15950___05FETC___05Fq15 
        = ((1U & (vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                  ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__IF_INV_mant_x15950_BIT_0_XOR_INV_mant_y159513___05FETC___05Fq16 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                  ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh123897 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh124091 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh130745 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh130939 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh129002 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh135850 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh128808 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh135656 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh128614 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh135462 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh128420 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh135268 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128226 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh135074 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh128032 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh134880 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh127838 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh134686 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh127644 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh134492 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127450 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh134298 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh127256 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh134104 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127062 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh133910 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh126868 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh133716 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh126674 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh133522 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh126480 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh133328 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126286 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh133134 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh126092 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh132940 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh125898 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh132746 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh125704 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh132552 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125510 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh132358 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh125316 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh132164 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125122 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh131970 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh124928 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh131776 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh124734 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh131582 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh124540 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh131388 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124346 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh131194 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh124152 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh131000 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh115950) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh123958 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                                & vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13));
    vlTOPp->mkMac__DOT__x___05Fh130806 = (1U & (vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                                & vlTOPp->mkMac__DOT__mant_x___05Fh115950));
    vlTOPp->mkMac__DOT__INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d56 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3373) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3182) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32))));
    vlTOPp->mkMac__DOT__y___05Fh3564 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3373));
    vlTOPp->mkMac__DOT__x___05Fh92506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91144) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91145));
    vlTOPp->mkMac__DOT__y___05Fh91333 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91144) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91145));
    vlTOPp->mkMac__DOT__x___05Fh90028 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90030) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90031));
    vlTOPp->mkMac__DOT__x___05Fh68859 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68861) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68862));
    vlTOPp->mkMac__DOT__INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d97 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20070) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh19879) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73))));
    vlTOPp->mkMac__DOT__y___05Fh20261 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20070));
    vlTOPp->mkMac__DOT__y___05Fh110328 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110386) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110387));
    vlTOPp->mkMac__DOT__y___05Fh137806 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh137618));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh116003 
        = (1U & ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2024)
                  ? (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                     >> 0x1fU) : (IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh116160)));
    vlTOPp->mkMac__DOT__x___05Fh117301 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117303) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117304));
    vlTOPp->mkMac__DOT__x___05Fh123956 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh123958) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh115950));
    vlTOPp->mkMac__DOT__x___05Fh130804 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh130806) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13));
    vlTOPp->mkMac__DOT__y___05Fh3755 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3564));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1632 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92507)) 
            << 2U) | ((2U & (((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                              ^ vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535) 
                             << 1U)) | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1538)));
    vlTOPp->mkMac__DOT__y___05Fh92695 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92507));
    vlTOPp->mkMac__DOT__y___05Fh89972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90028) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90029));
    vlTOPp->mkMac__DOT__y___05Fh68802 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68859) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68860));
    vlTOPp->mkMac__DOT__y___05Fh20452 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20261));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2009 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110327) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110328)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110133) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110134)) 
                       << 2U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2008)));
    vlTOPp->mkMac__DOT__y___05Fh110581 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110328));
    vlTOPp->mkMac__DOT__y___05Fh110583 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110328));
    vlTOPp->mkMac__DOT__y___05Fh137994 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh137806));
    vlTOPp->mkMac__DOT__y___05Fh117243 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117301) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117302));
    vlTOPp->mkMac__DOT__y___05Fh123898 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh123956) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13));
    vlTOPp->mkMac__DOT__y___05Fh130746 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh130804) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh115950));
    vlTOPp->mkMac__DOT__y___05Fh3946 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3755));
    vlTOPp->mkMac__DOT__x___05Fh91332 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89971) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__y___05Fh90217 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__y___05Fh90219 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1033 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68801) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68802)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68610) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68611)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946))));
    vlTOPp->mkMac__DOT__y___05Fh69051 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68802));
    vlTOPp->mkMac__DOT__y___05Fh69053 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68802));
    vlTOPp->mkMac__DOT__y___05Fh20643 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20452));
    vlTOPp->mkMac__DOT__x___05Fh110580 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110582) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110583));
    vlTOPp->mkMac__DOT__y___05Fh138182 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608) 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh137994));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2704 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117242) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117243)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117048) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117049)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_mant_x15950_BIT_0_XOR_mant_y15951_BIT_0_THE_ETC___05Fq14)));
    vlTOPp->mkMac__DOT__y___05Fh117496 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117243));
    vlTOPp->mkMac__DOT__y___05Fh117498 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117243));
    vlTOPp->mkMac__DOT__y___05Fh124151 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh123898));
    vlTOPp->mkMac__DOT__y___05Fh124153 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh123898));
    vlTOPp->mkMac__DOT__y___05Fh130999 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130746));
    vlTOPp->mkMac__DOT__y___05Fh131001 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130746));
    vlTOPp->mkMac__DOT__y___05Fh4137 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3946));
    vlTOPp->mkMac__DOT__x___05Fh92694 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91332) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91333));
    vlTOPp->mkMac__DOT__y___05Fh91521 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91332) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91333));
    vlTOPp->mkMac__DOT__x___05Fh90216 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90218) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90219));
    vlTOPp->mkMac__DOT__x___05Fh69050 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69052) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69053));
    vlTOPp->mkMac__DOT__y___05Fh20834 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20643));
    vlTOPp->mkMac__DOT__y___05Fh110522 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110580) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110581));
    vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh136757 
        = ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2611) 
           | ((0x80U & ((0xffffff80U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh138182) 
                           << 7U))) | ((0x40U & ((0xffffffc0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh137994) 
                                                  << 6U))) 
                                       | ((0x20U & 
                                           ((0xffffffe0U 
                                             & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                                            ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137806) 
                                               << 5U))) 
                                          | ((0x10U 
                                              & ((0xfffffff0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2608)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh137618) 
                                                  << 4U))) 
                                             | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2635))))));
    vlTOPp->mkMac__DOT__x___05Fh117495 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117497) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117498));
    vlTOPp->mkMac__DOT__x___05Fh124150 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124152) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124153));
    vlTOPp->mkMac__DOT__x___05Fh130998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131000) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131001));
    vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2692 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh4137) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3946) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh3755) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3564) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d56))))));
    vlTOPp->mkMac__DOT__y___05Fh92883 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92695));
    vlTOPp->mkMac__DOT__y___05Fh90160 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90216) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90217));
    vlTOPp->mkMac__DOT__y___05Fh68993 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69050) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69051));
    vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19389 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20834) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20643) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh20452) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20261) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d97))))));
    vlTOPp->mkMac__DOT__y___05Fh110775 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110522));
    vlTOPp->mkMac__DOT__y___05Fh110777 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110522));
    vlTOPp->mkMac__DOT__y___05Fh117437 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117495) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117496));
    vlTOPp->mkMac__DOT__y___05Fh124092 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124150) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124151));
    vlTOPp->mkMac__DOT__y___05Fh130940 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh130998) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh130999));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2692
            : vlTOPp->mkMac__DOT__ext_b___05Fh1687);
    vlTOPp->mkMac__DOT__x___05Fh91520 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90159) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh90405 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh90407 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh69242 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68993));
    vlTOPp->mkMac__DOT__y___05Fh69244 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68993));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1))
            ? vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19389
            : vlTOPp->mkMac__DOT__ext_a___05Fh1686);
    vlTOPp->mkMac__DOT__x___05Fh110774 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110776) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110777));
    vlTOPp->mkMac__DOT__y___05Fh117690 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117437));
    vlTOPp->mkMac__DOT__y___05Fh117692 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117437));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2862 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124091) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124092)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh123897) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh123898)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_mant_x15950_BIT_0_XOR_INV_mant_y159513___05FETC___05Fq16)));
    vlTOPp->mkMac__DOT__y___05Fh124345 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124092));
    vlTOPp->mkMac__DOT__y___05Fh124347 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124092));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2783 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh130939) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh130940)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh130745) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh130746)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_mant_y159513_BIT_0_XOR_mant_x15950___05FETC___05Fq15)));
    vlTOPp->mkMac__DOT__y___05Fh131193 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130940));
    vlTOPp->mkMac__DOT__y___05Fh131195 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130940));
    vlTOPp->mkMac__DOT__x___05Fh92882 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91520) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91521));
    vlTOPp->mkMac__DOT__y___05Fh91709 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91520) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91521));
    vlTOPp->mkMac__DOT__x___05Fh90404 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90406) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90407));
    vlTOPp->mkMac__DOT__x___05Fh69241 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69243) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69244));
    vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__y___05Fh110716 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110774) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110775));
    vlTOPp->mkMac__DOT__x___05Fh117689 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117691) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117692));
    vlTOPp->mkMac__DOT__x___05Fh124344 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124346) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124347));
    vlTOPp->mkMac__DOT__x___05Fh131192 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131194) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131195));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1633 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92883)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92695)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1632)));
    vlTOPp->mkMac__DOT__y___05Fh93071 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92883));
    vlTOPp->mkMac__DOT__y___05Fh90348 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90404) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90405));
    vlTOPp->mkMac__DOT__y___05Fh69184 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69241) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69242));
    vlTOPp->mkMac__DOT__product___05Fh18926 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102) 
                                               | ((0xfffeU 
                                                   & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100) 
                                                  | (1U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102)));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2010 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110715) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110716)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110521) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110522)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2009)));
    vlTOPp->mkMac__DOT__y___05Fh110969 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110716));
    vlTOPp->mkMac__DOT__y___05Fh110971 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110716));
    vlTOPp->mkMac__DOT__y___05Fh117631 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117689) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117690));
    vlTOPp->mkMac__DOT__y___05Fh124286 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124344) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124345));
    vlTOPp->mkMac__DOT__y___05Fh131134 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131192) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131193));
    vlTOPp->mkMac__DOT__x___05Fh91708 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90347) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__y___05Fh90593 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__y___05Fh90595 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1034 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69183) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69184)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68992) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68993)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1033)));
    vlTOPp->mkMac__DOT__y___05Fh69433 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69184));
    vlTOPp->mkMac__DOT__y___05Fh69435 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69184));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh18926
            : 0U);
    vlTOPp->mkMac__DOT__x___05Fh110968 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110970) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110971));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2705 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117630) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117631)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117436) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117437)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2704)));
    vlTOPp->mkMac__DOT__y___05Fh117884 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117631));
    vlTOPp->mkMac__DOT__y___05Fh117886 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117631));
    vlTOPp->mkMac__DOT__y___05Fh124539 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124286));
    vlTOPp->mkMac__DOT__y___05Fh124541 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124286));
    vlTOPp->mkMac__DOT__y___05Fh131387 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131134));
    vlTOPp->mkMac__DOT__y___05Fh131389 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131134));
    vlTOPp->mkMac__DOT__x___05Fh93070 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91708) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91709));
    vlTOPp->mkMac__DOT__y___05Fh91897 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91708) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91709));
    vlTOPp->mkMac__DOT__x___05Fh90592 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90594) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90595));
    vlTOPp->mkMac__DOT__x___05Fh69432 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69434) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69435));
    vlTOPp->mkMac__DOT__x___05Fh28094 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh28285 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__x___05Fh27712 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh27903 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh27330 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27521 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh28345 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh26948 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27139 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh26566 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26757 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh26184 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26375 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh28154 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh25802 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 2U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh25993 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh27963 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh27772 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh27581 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27390 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh27199 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27008 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh26817 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26626 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh26435 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26244 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh26053 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 2U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh25803 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh110910 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110968) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110969));
    vlTOPp->mkMac__DOT__x___05Fh117883 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117885) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117886));
    vlTOPp->mkMac__DOT__x___05Fh124538 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124540) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124541));
    vlTOPp->mkMac__DOT__x___05Fh131386 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131388) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131389));
    vlTOPp->mkMac__DOT__y___05Fh93259 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh93071));
    vlTOPp->mkMac__DOT__y___05Fh90536 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90592) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90593));
    vlTOPp->mkMac__DOT__y___05Fh69375 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69432) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69433));
    vlTOPp->mkMac__DOT__y___05Fh26052 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25803));
    vlTOPp->mkMac__DOT__y___05Fh26054 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25803));
    vlTOPp->mkMac__DOT__y___05Fh111163 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110910));
    vlTOPp->mkMac__DOT__y___05Fh111165 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110910));
    vlTOPp->mkMac__DOT__y___05Fh117825 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117883) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117884));
    vlTOPp->mkMac__DOT__y___05Fh124480 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124538) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124539));
    vlTOPp->mkMac__DOT__y___05Fh131328 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131386) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131387));
    vlTOPp->mkMac__DOT__y___05Fh90781 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__x___05Fh91896 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90535) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__y___05Fh90783 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__y___05Fh69624 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69375));
    vlTOPp->mkMac__DOT__y___05Fh69626 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69375));
    vlTOPp->mkMac__DOT__x___05Fh26051 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26053) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26054));
    vlTOPp->mkMac__DOT__x___05Fh111162 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111164) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111165));
    vlTOPp->mkMac__DOT__y___05Fh118078 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117825));
    vlTOPp->mkMac__DOT__y___05Fh118080 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117825));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2863 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124479) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124480)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124285) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124286)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2862)));
    vlTOPp->mkMac__DOT__y___05Fh124733 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124480));
    vlTOPp->mkMac__DOT__y___05Fh124735 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124480));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2784 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh131327) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh131328)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh131133) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh131134)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2783)));
    vlTOPp->mkMac__DOT__y___05Fh131581 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131328));
    vlTOPp->mkMac__DOT__y___05Fh131583 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131328));
    vlTOPp->mkMac__DOT__y___05Fh92085 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91896) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91897));
    vlTOPp->mkMac__DOT__x___05Fh93258 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91896) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91897));
    vlTOPp->mkMac__DOT__x___05Fh90780 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90782) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90783));
    vlTOPp->mkMac__DOT__x___05Fh69623 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69625) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69626));
    vlTOPp->mkMac__DOT__y___05Fh25994 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26051) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26052));
    vlTOPp->mkMac__DOT__y___05Fh111104 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111162) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111163));
    vlTOPp->mkMac__DOT__x___05Fh118077 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118079) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118080));
    vlTOPp->mkMac__DOT__x___05Fh124732 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124734) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124735));
    vlTOPp->mkMac__DOT__x___05Fh131580 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131582) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131583));
    vlTOPp->mkMac__DOT__y___05Fh93447 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh93259));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1634 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93259)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93071)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1633)));
    vlTOPp->mkMac__DOT__y___05Fh90724 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90780) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90781));
    vlTOPp->mkMac__DOT__y___05Fh69566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69623) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69624));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d238 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh25993) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh25994)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh25802) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh25803)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108) 
                                        ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110))));
    vlTOPp->mkMac__DOT__y___05Fh26243 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25994));
    vlTOPp->mkMac__DOT__y___05Fh26245 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25994));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2011 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111103) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111104)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110909) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110910)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2010)));
    vlTOPp->mkMac__DOT__y___05Fh111357 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111104));
    vlTOPp->mkMac__DOT__y___05Fh111359 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111104));
    vlTOPp->mkMac__DOT__y___05Fh118019 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118077) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118078));
    vlTOPp->mkMac__DOT__y___05Fh124674 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124732) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124733));
    vlTOPp->mkMac__DOT__y___05Fh131522 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131580) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131581));
    vlTOPp->mkMac__DOT__x___05Fh92084 = (1U & (~ ((IData)(vlTOPp->mkMac__DOT__x___05Fh90723) 
                                                  ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90724))));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1035 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69565) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69566)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69374) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69375)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1034)));
    vlTOPp->mkMac__DOT__y___05Fh69815 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69566));
    vlTOPp->mkMac__DOT__y___05Fh69817 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69566));
    vlTOPp->mkMac__DOT__x___05Fh26242 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26244) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26245));
    vlTOPp->mkMac__DOT__x___05Fh111356 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111358) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111359));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2706 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118018) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118019)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117824) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117825)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2705)));
    vlTOPp->mkMac__DOT__y___05Fh118272 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118019));
    vlTOPp->mkMac__DOT__y___05Fh118274 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118019));
    vlTOPp->mkMac__DOT__y___05Fh124927 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124674));
    vlTOPp->mkMac__DOT__y___05Fh124929 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124674));
    vlTOPp->mkMac__DOT__y___05Fh131775 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131522));
    vlTOPp->mkMac__DOT__y___05Fh131777 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131522));
    vlTOPp->mkMac__DOT__x___05Fh93446 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92084) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92085));
    vlTOPp->mkMac__DOT__x___05Fh69814 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69816) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69817));
    vlTOPp->mkMac__DOT__y___05Fh26185 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26242) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26243));
    vlTOPp->mkMac__DOT__y___05Fh111298 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111356) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111357));
    vlTOPp->mkMac__DOT__x___05Fh118271 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118273) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118274));
    vlTOPp->mkMac__DOT__x___05Fh124926 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124928) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124929));
    vlTOPp->mkMac__DOT__x___05Fh131774 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131776) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131777));
    vlTOPp->mkMac__DOT__y___05Fh70006 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69814) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69815));
    vlTOPp->mkMac__DOT__y___05Fh26434 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26185));
    vlTOPp->mkMac__DOT__y___05Fh26436 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26185));
    vlTOPp->mkMac__DOT__y___05Fh111551 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111298));
    vlTOPp->mkMac__DOT__y___05Fh111553 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111298));
    vlTOPp->mkMac__DOT__y___05Fh118213 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118271) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118272));
    vlTOPp->mkMac__DOT__y___05Fh124868 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124926) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124927));
    vlTOPp->mkMac__DOT__y___05Fh131716 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131774) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131775));
    vlTOPp->mkMac__DOT__y___05Fh70008 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh70006));
    vlTOPp->mkMac__DOT__x___05Fh26433 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26435) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26436));
    vlTOPp->mkMac__DOT__x___05Fh111550 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111552) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111553));
    vlTOPp->mkMac__DOT__y___05Fh118466 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118213));
    vlTOPp->mkMac__DOT__y___05Fh118468 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118213));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2864 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124867) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124868)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124673) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124674)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2863)));
    vlTOPp->mkMac__DOT__y___05Fh125121 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124868));
    vlTOPp->mkMac__DOT__y___05Fh125123 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124868));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2785 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh131715) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh131716)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh131521) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh131522)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2784)));
    vlTOPp->mkMac__DOT__y___05Fh131969 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131716));
    vlTOPp->mkMac__DOT__y___05Fh131971 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131716));
    vlTOPp->mkMac__DOT__x___05Fh70005 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 8U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh70008)));
    vlTOPp->mkMac__DOT__y___05Fh26376 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26433) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26434));
    vlTOPp->mkMac__DOT__y___05Fh111492 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111550) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111551));
    vlTOPp->mkMac__DOT__x___05Fh118465 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118467) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118468));
    vlTOPp->mkMac__DOT__x___05Fh125120 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125122) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125123));
    vlTOPp->mkMac__DOT__x___05Fh131968 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131970) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131971));
    vlTOPp->mkMac__DOT__y___05Fh69948 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh70005) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh70006));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d239 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26375) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26376)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26184) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26185)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d238)));
    vlTOPp->mkMac__DOT__y___05Fh26625 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26376));
    vlTOPp->mkMac__DOT__y___05Fh26627 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26376));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2012 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111491) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111492)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111297) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111298)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2011)));
    vlTOPp->mkMac__DOT__y___05Fh111745 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111492));
    vlTOPp->mkMac__DOT__y___05Fh111747 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111492));
    vlTOPp->mkMac__DOT__y___05Fh118407 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118465) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118466));
    vlTOPp->mkMac__DOT__y___05Fh125062 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125120) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125121));
    vlTOPp->mkMac__DOT__y___05Fh131910 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh131968) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh131969));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1036 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh69948) 
                         << 9U))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69756) 
                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh70006)) 
                                      << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1035)));
    vlTOPp->mkMac__DOT__y___05Fh70199 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69948));
    vlTOPp->mkMac__DOT__x___05Fh26624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26626) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26627));
    vlTOPp->mkMac__DOT__x___05Fh111744 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111746) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111747));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2707 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118406) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118407)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118212) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118213)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2706)));
    vlTOPp->mkMac__DOT__y___05Fh118660 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118407));
    vlTOPp->mkMac__DOT__y___05Fh118662 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118407));
    vlTOPp->mkMac__DOT__y___05Fh125315 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125062));
    vlTOPp->mkMac__DOT__y___05Fh125317 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125062));
    vlTOPp->mkMac__DOT__y___05Fh132163 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131910));
    vlTOPp->mkMac__DOT__y___05Fh132165 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131910));
    vlTOPp->mkMac__DOT__y___05Fh70390 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70199));
    vlTOPp->mkMac__DOT__y___05Fh26567 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26624) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26625));
    vlTOPp->mkMac__DOT__y___05Fh111686 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111744) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111745));
    vlTOPp->mkMac__DOT__x___05Fh118659 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118661) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118662));
    vlTOPp->mkMac__DOT__x___05Fh125314 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125316) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125317));
    vlTOPp->mkMac__DOT__x___05Fh132162 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132164) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132165));
    vlTOPp->mkMac__DOT__y___05Fh70581 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70390));
    vlTOPp->mkMac__DOT__y___05Fh26816 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26567));
    vlTOPp->mkMac__DOT__y___05Fh26818 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26567));
    vlTOPp->mkMac__DOT__y___05Fh111939 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111686));
    vlTOPp->mkMac__DOT__y___05Fh111941 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111686));
    vlTOPp->mkMac__DOT__y___05Fh118601 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118659) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118660));
    vlTOPp->mkMac__DOT__y___05Fh125256 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125314) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125315));
    vlTOPp->mkMac__DOT__y___05Fh132104 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132162) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132163));
    vlTOPp->mkMac__DOT__y___05Fh70772 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70581));
    vlTOPp->mkMac__DOT__x___05Fh26815 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26817) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26818));
    vlTOPp->mkMac__DOT__x___05Fh111938 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111940) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111941));
    vlTOPp->mkMac__DOT__y___05Fh118854 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118601));
    vlTOPp->mkMac__DOT__y___05Fh118856 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118601));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2865 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125255) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125256)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125061) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125062)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2864)));
    vlTOPp->mkMac__DOT__y___05Fh125509 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125256));
    vlTOPp->mkMac__DOT__y___05Fh125511 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125256));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2786 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh132103) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh132104)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh131909) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh131910)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2785)));
    vlTOPp->mkMac__DOT__y___05Fh132357 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh132104));
    vlTOPp->mkMac__DOT__y___05Fh132359 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh132104));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1038 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70772) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70581) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70390) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh70199) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1036)))));
    vlTOPp->mkMac__DOT__y___05Fh70963 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70772));
    vlTOPp->mkMac__DOT__y___05Fh26758 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26815) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26816));
    vlTOPp->mkMac__DOT__y___05Fh111880 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111938) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111939));
    vlTOPp->mkMac__DOT__x___05Fh118853 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118855) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118856));
    vlTOPp->mkMac__DOT__x___05Fh125508 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125510) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125511));
    vlTOPp->mkMac__DOT__x___05Fh132356 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132358) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132359));
    vlTOPp->mkMac__DOT__y___05Fh71094 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70963));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d240 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26757) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26758)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26566) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26567)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d239)));
    vlTOPp->mkMac__DOT__y___05Fh27007 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26758));
    vlTOPp->mkMac__DOT__y___05Fh27009 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26758));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2013 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111879) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111880)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111685) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111686)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2012)));
    vlTOPp->mkMac__DOT__y___05Fh112133 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111880));
    vlTOPp->mkMac__DOT__y___05Fh112135 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh111880));
    vlTOPp->mkMac__DOT__y___05Fh118795 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118853) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118854));
    vlTOPp->mkMac__DOT__y___05Fh125450 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125508) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125509));
    vlTOPp->mkMac__DOT__y___05Fh132298 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132356) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132357));
    vlTOPp->mkMac__DOT__mant_mult___05Fh64627 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh71094) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh70963) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1038))));
    vlTOPp->mkMac__DOT__x___05Fh27006 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27008) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27009));
    vlTOPp->mkMac__DOT__x___05Fh112132 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112134) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112135));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2708 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118794) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118795)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118600) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118601)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2707)));
    vlTOPp->mkMac__DOT__y___05Fh119048 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118795));
    vlTOPp->mkMac__DOT__y___05Fh119050 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118795));
    vlTOPp->mkMac__DOT__y___05Fh125703 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125450));
    vlTOPp->mkMac__DOT__y___05Fh125705 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125450));
    vlTOPp->mkMac__DOT__y___05Fh132551 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh132298));
    vlTOPp->mkMac__DOT__y___05Fh132553 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh132298));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
        = ((2U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh64627
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944);
    vlTOPp->mkMac__DOT__y___05Fh26949 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27006) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27007));
    vlTOPp->mkMac__DOT__y___05Fh112074 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112132) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112133));
    vlTOPp->mkMac__DOT__x___05Fh119047 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119049) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119050));
    vlTOPp->mkMac__DOT__x___05Fh125702 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125704) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125705));
    vlTOPp->mkMac__DOT__x___05Fh132550 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132552) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132553));
    vlTOPp->mkMac__DOT__x___05Fh72673 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh72864 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh72291 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh72482 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh71909 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh72100 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh71718 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh72924 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh72733 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh72542 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh72351 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh72160 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh71969 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh71719 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 2U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh27198 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26949));
    vlTOPp->mkMac__DOT__y___05Fh27200 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26949));
    vlTOPp->mkMac__DOT__y___05Fh112327 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112074));
    vlTOPp->mkMac__DOT__y___05Fh112329 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112074));
    vlTOPp->mkMac__DOT__y___05Fh118989 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119047) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119048));
    vlTOPp->mkMac__DOT__y___05Fh125644 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125702) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125703));
    vlTOPp->mkMac__DOT__y___05Fh132492 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132550) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132551));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1121 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh71718) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh71719)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                             ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042))));
    vlTOPp->mkMac__DOT__y___05Fh71968 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71719));
    vlTOPp->mkMac__DOT__y___05Fh71970 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71719));
    vlTOPp->mkMac__DOT__x___05Fh27197 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27199) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27200));
    vlTOPp->mkMac__DOT__x___05Fh112326 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112328) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112329));
    vlTOPp->mkMac__DOT__y___05Fh119242 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118989));
    vlTOPp->mkMac__DOT__y___05Fh119244 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118989));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2866 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125643) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125644)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125449) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125450)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2865)));
    vlTOPp->mkMac__DOT__y___05Fh125897 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125644));
    vlTOPp->mkMac__DOT__y___05Fh125899 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125644));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2787 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh132491) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh132492)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh132297) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh132298)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2786)));
    vlTOPp->mkMac__DOT__y___05Fh132745 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132492));
    vlTOPp->mkMac__DOT__y___05Fh132747 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132492));
    vlTOPp->mkMac__DOT__x___05Fh71967 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh71969) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh71970));
    vlTOPp->mkMac__DOT__y___05Fh27140 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27197) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27198));
    vlTOPp->mkMac__DOT__y___05Fh112268 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112326) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112327));
    vlTOPp->mkMac__DOT__x___05Fh119241 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119243) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119244));
    vlTOPp->mkMac__DOT__x___05Fh125896 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125898) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125899));
    vlTOPp->mkMac__DOT__x___05Fh132744 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132746) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132747));
    vlTOPp->mkMac__DOT__y___05Fh71910 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh71967) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh71968));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d241 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27139) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27140)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26948) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26949)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d240)));
    vlTOPp->mkMac__DOT__y___05Fh27389 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27140));
    vlTOPp->mkMac__DOT__y___05Fh27391 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27140));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2014 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112267) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112268)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112073) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112074)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2013)));
    vlTOPp->mkMac__DOT__y___05Fh112521 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112268));
    vlTOPp->mkMac__DOT__y___05Fh112523 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112268));
    vlTOPp->mkMac__DOT__y___05Fh119183 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119241) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119242));
    vlTOPp->mkMac__DOT__y___05Fh125838 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125896) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125897));
    vlTOPp->mkMac__DOT__y___05Fh132686 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132744) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132745));
    vlTOPp->mkMac__DOT__y___05Fh72159 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71910));
    vlTOPp->mkMac__DOT__y___05Fh72161 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71910));
    vlTOPp->mkMac__DOT__x___05Fh27388 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27390) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27391));
    vlTOPp->mkMac__DOT__x___05Fh112520 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112522) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112523));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2709 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119182) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119183)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118988) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118989)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2708)));
    vlTOPp->mkMac__DOT__y___05Fh119436 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119183));
    vlTOPp->mkMac__DOT__y___05Fh119438 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119183));
    vlTOPp->mkMac__DOT__y___05Fh126091 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125838));
    vlTOPp->mkMac__DOT__y___05Fh126093 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125838));
    vlTOPp->mkMac__DOT__y___05Fh132939 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132686));
    vlTOPp->mkMac__DOT__y___05Fh132941 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132686));
    vlTOPp->mkMac__DOT__x___05Fh72158 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72160) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72161));
    vlTOPp->mkMac__DOT__y___05Fh27331 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27388) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27389));
    vlTOPp->mkMac__DOT__y___05Fh112462 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112520) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112521));
    vlTOPp->mkMac__DOT__x___05Fh119435 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119437) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119438));
    vlTOPp->mkMac__DOT__x___05Fh126090 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126092) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126093));
    vlTOPp->mkMac__DOT__x___05Fh132938 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132940) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132941));
    vlTOPp->mkMac__DOT__y___05Fh72101 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72158) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72159));
    vlTOPp->mkMac__DOT__y___05Fh27580 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27331));
    vlTOPp->mkMac__DOT__y___05Fh27582 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27331));
    vlTOPp->mkMac__DOT__y___05Fh112715 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112462));
    vlTOPp->mkMac__DOT__y___05Fh112717 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112462));
    vlTOPp->mkMac__DOT__y___05Fh119377 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119435) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119436));
    vlTOPp->mkMac__DOT__y___05Fh126032 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126090) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126091));
    vlTOPp->mkMac__DOT__y___05Fh132880 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh132938) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh132939));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1122 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72100) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72101)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh71909) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh71910)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1121)));
    vlTOPp->mkMac__DOT__y___05Fh72350 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72101));
    vlTOPp->mkMac__DOT__y___05Fh72352 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72101));
    vlTOPp->mkMac__DOT__x___05Fh27579 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27581) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27582));
    vlTOPp->mkMac__DOT__x___05Fh112714 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112716) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112717));
    vlTOPp->mkMac__DOT__y___05Fh119630 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119377));
    vlTOPp->mkMac__DOT__y___05Fh119632 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119377));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2867 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126031) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126032)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125837) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125838)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2866)));
    vlTOPp->mkMac__DOT__y___05Fh126285 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126032));
    vlTOPp->mkMac__DOT__y___05Fh126287 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126032));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2788 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh132879) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh132880)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh132685) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh132686)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2787)));
    vlTOPp->mkMac__DOT__y___05Fh133133 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132880));
    vlTOPp->mkMac__DOT__y___05Fh133135 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh132880));
    vlTOPp->mkMac__DOT__x___05Fh72349 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72351) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72352));
    vlTOPp->mkMac__DOT__y___05Fh27522 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27579) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27580));
    vlTOPp->mkMac__DOT__y___05Fh112656 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112714) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112715));
    vlTOPp->mkMac__DOT__x___05Fh119629 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119631) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119632));
    vlTOPp->mkMac__DOT__x___05Fh126284 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126286) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126287));
    vlTOPp->mkMac__DOT__x___05Fh133132 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133134) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133135));
    vlTOPp->mkMac__DOT__y___05Fh72292 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72349) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72350));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d242 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27521) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27522)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27330) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27331)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d241)));
    vlTOPp->mkMac__DOT__y___05Fh27771 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27522));
    vlTOPp->mkMac__DOT__y___05Fh27773 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27522));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2015 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112655) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112656)) 
            << 0xfU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112461) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112462)) 
                         << 0xeU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2014)));
    vlTOPp->mkMac__DOT__y___05Fh112909 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112656));
    vlTOPp->mkMac__DOT__y___05Fh112911 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112656));
    vlTOPp->mkMac__DOT__y___05Fh119571 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119629) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119630));
    vlTOPp->mkMac__DOT__y___05Fh126226 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126284) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126285));
    vlTOPp->mkMac__DOT__y___05Fh133074 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133132) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133133));
    vlTOPp->mkMac__DOT__y___05Fh72541 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72292));
    vlTOPp->mkMac__DOT__y___05Fh72543 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72292));
    vlTOPp->mkMac__DOT__x___05Fh27770 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27772) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27773));
    vlTOPp->mkMac__DOT__x___05Fh112908 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112910) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112911));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2710 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119570) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119571)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119376) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119377)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2709)));
    vlTOPp->mkMac__DOT__y___05Fh119824 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119571));
    vlTOPp->mkMac__DOT__y___05Fh119826 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119571));
    vlTOPp->mkMac__DOT__y___05Fh126479 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126226));
    vlTOPp->mkMac__DOT__y___05Fh126481 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126226));
    vlTOPp->mkMac__DOT__y___05Fh133327 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133074));
    vlTOPp->mkMac__DOT__y___05Fh133329 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133074));
    vlTOPp->mkMac__DOT__x___05Fh72540 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72542) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72543));
    vlTOPp->mkMac__DOT__y___05Fh27713 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27770) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27771));
    vlTOPp->mkMac__DOT__y___05Fh112850 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112908) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112909));
    vlTOPp->mkMac__DOT__x___05Fh119823 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119825) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119826));
    vlTOPp->mkMac__DOT__x___05Fh126478 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126480) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126481));
    vlTOPp->mkMac__DOT__x___05Fh133326 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133328) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133329));
    vlTOPp->mkMac__DOT__y___05Fh72483 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72540) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72541));
    vlTOPp->mkMac__DOT__y___05Fh27962 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27713));
    vlTOPp->mkMac__DOT__y___05Fh27964 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27713));
    vlTOPp->mkMac__DOT__y___05Fh113103 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112850));
    vlTOPp->mkMac__DOT__y___05Fh113105 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112850));
    vlTOPp->mkMac__DOT__y___05Fh119765 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119823) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119824));
    vlTOPp->mkMac__DOT__y___05Fh126420 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126478) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126479));
    vlTOPp->mkMac__DOT__y___05Fh133268 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133326) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133327));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1123 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72482) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72483)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72291) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72292)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1122)));
    vlTOPp->mkMac__DOT__y___05Fh72732 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72483));
    vlTOPp->mkMac__DOT__y___05Fh72734 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72483));
    vlTOPp->mkMac__DOT__x___05Fh27961 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27963) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27964));
    vlTOPp->mkMac__DOT__x___05Fh113102 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113104) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113105));
    vlTOPp->mkMac__DOT__y___05Fh120018 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119765));
    vlTOPp->mkMac__DOT__y___05Fh120020 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119765));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2868 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126419) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126420)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126225) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126226)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2867)));
    vlTOPp->mkMac__DOT__y___05Fh126673 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126420));
    vlTOPp->mkMac__DOT__y___05Fh126675 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126420));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2789 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh133267) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh133268)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh133073) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh133074)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2788)));
    vlTOPp->mkMac__DOT__y___05Fh133521 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133268));
    vlTOPp->mkMac__DOT__y___05Fh133523 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133268));
    vlTOPp->mkMac__DOT__x___05Fh72731 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72733) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72734));
    vlTOPp->mkMac__DOT__y___05Fh27904 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27961) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27962));
    vlTOPp->mkMac__DOT__y___05Fh113044 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113102) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113103));
    vlTOPp->mkMac__DOT__x___05Fh120017 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120019) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120020));
    vlTOPp->mkMac__DOT__x___05Fh126672 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126674) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126675));
    vlTOPp->mkMac__DOT__x___05Fh133520 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133522) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133523));
    vlTOPp->mkMac__DOT__y___05Fh72674 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72731) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72732));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d243 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27903) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27904)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27712) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27713)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d242)));
    vlTOPp->mkMac__DOT__y___05Fh28153 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27904));
    vlTOPp->mkMac__DOT__y___05Fh28155 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27904));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2016 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113043) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113044)) 
            << 0x11U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112849) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112850)) 
                          << 0x10U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2015)));
    vlTOPp->mkMac__DOT__y___05Fh113297 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113044));
    vlTOPp->mkMac__DOT__y___05Fh113299 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113044));
    vlTOPp->mkMac__DOT__y___05Fh119959 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120017) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120018));
    vlTOPp->mkMac__DOT__y___05Fh126614 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126672) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126673));
    vlTOPp->mkMac__DOT__y___05Fh133462 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133520) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133521));
    vlTOPp->mkMac__DOT__y___05Fh72923 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72674));
    vlTOPp->mkMac__DOT__y___05Fh72925 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72674));
    vlTOPp->mkMac__DOT__x___05Fh28152 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28154) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28155));
    vlTOPp->mkMac__DOT__x___05Fh113296 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113298) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113299));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2711 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119958) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119959)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119764) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119765)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2710)));
    vlTOPp->mkMac__DOT__y___05Fh120212 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119959));
    vlTOPp->mkMac__DOT__y___05Fh120214 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119959));
    vlTOPp->mkMac__DOT__y___05Fh126867 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126614));
    vlTOPp->mkMac__DOT__y___05Fh126869 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126614));
    vlTOPp->mkMac__DOT__y___05Fh133715 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133462));
    vlTOPp->mkMac__DOT__y___05Fh133717 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133462));
    vlTOPp->mkMac__DOT__x___05Fh72922 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72924) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72925));
    vlTOPp->mkMac__DOT__y___05Fh28095 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28152) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28153));
    vlTOPp->mkMac__DOT__y___05Fh113238 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113296) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113297));
    vlTOPp->mkMac__DOT__x___05Fh120211 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120213) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120214));
    vlTOPp->mkMac__DOT__x___05Fh126866 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126868) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126869));
    vlTOPp->mkMac__DOT__x___05Fh133714 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133716) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133717));
    vlTOPp->mkMac__DOT__y___05Fh73114 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72922) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72923));
    vlTOPp->mkMac__DOT__y___05Fh28344 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28095));
    vlTOPp->mkMac__DOT__y___05Fh28346 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28095));
    vlTOPp->mkMac__DOT__y___05Fh113491 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113238));
    vlTOPp->mkMac__DOT__y___05Fh113493 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113238));
    vlTOPp->mkMac__DOT__y___05Fh120153 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120211) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120212));
    vlTOPp->mkMac__DOT__y___05Fh126808 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126866) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126867));
    vlTOPp->mkMac__DOT__y___05Fh133656 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133714) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133715));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1124 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72864) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh73114)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72673) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72674)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1123)));
    vlTOPp->mkMac__DOT__y___05Fh73116 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh73114));
    vlTOPp->mkMac__DOT__x___05Fh28343 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28345) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28346));
    vlTOPp->mkMac__DOT__x___05Fh113490 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113492) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113493));
    vlTOPp->mkMac__DOT__y___05Fh120406 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120153));
    vlTOPp->mkMac__DOT__y___05Fh120408 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120153));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2869 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126807) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126808)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126613) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126614)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2868)));
    vlTOPp->mkMac__DOT__y___05Fh127061 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126808));
    vlTOPp->mkMac__DOT__y___05Fh127063 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126808));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2790 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh133655) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh133656)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh133461) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh133462)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2789)));
    vlTOPp->mkMac__DOT__y___05Fh133909 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133656));
    vlTOPp->mkMac__DOT__y___05Fh133911 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133656));
    vlTOPp->mkMac__DOT__x___05Fh73113 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 9U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh73116)));
    vlTOPp->mkMac__DOT__y___05Fh28286 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28343) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28344));
    vlTOPp->mkMac__DOT__y___05Fh113432 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113490) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113491));
    vlTOPp->mkMac__DOT__x___05Fh120405 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120407) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120408));
    vlTOPp->mkMac__DOT__x___05Fh127060 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127062) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127063));
    vlTOPp->mkMac__DOT__x___05Fh133908 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133910) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133911));
    vlTOPp->mkMac__DOT__y___05Fh73056 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh73113) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh73114));
    vlTOPp->mkMac__DOT__product___05Fh16839 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28285) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28286)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28094) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28095)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d243))));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2017 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113431) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113432)) 
            << 0x13U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113237) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113238)) 
                          << 0x12U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2016));
    vlTOPp->mkMac__DOT__y___05Fh113685 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113432));
    vlTOPp->mkMac__DOT__y___05Fh113687 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113432));
    vlTOPp->mkMac__DOT__y___05Fh120347 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120405) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120406));
    vlTOPp->mkMac__DOT__y___05Fh127002 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127060) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127061));
    vlTOPp->mkMac__DOT__y___05Fh133850 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh133908) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh133909));
    vlTOPp->mkMac__DOT__y___05Fh73307 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73056));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
        = ((2U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh16839
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108);
    vlTOPp->mkMac__DOT__x___05Fh113684 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113686) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113687));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2712 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120346) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120347)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120152) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120153)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2711));
    vlTOPp->mkMac__DOT__y___05Fh120600 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120347));
    vlTOPp->mkMac__DOT__y___05Fh120602 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120347));
    vlTOPp->mkMac__DOT__y___05Fh127255 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127002));
    vlTOPp->mkMac__DOT__y___05Fh127257 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127002));
    vlTOPp->mkMac__DOT__y___05Fh134103 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133850));
    vlTOPp->mkMac__DOT__y___05Fh134105 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh133850));
    vlTOPp->mkMac__DOT__y___05Fh73498 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73307));
    vlTOPp->mkMac__DOT__x___05Fh32651 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh32842 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh32269 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32460 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh31887 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh32078 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh32902 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh31505 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31696 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31123 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31314 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh30741 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh30932 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh32711 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh30550 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh32520 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32329 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh32138 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh31947 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31756 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31565 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh31374 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31183 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh30992 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh30801 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh30551 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 2U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh113626 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113684) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113685));
    vlTOPp->mkMac__DOT__x___05Fh120599 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120601) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120602));
    vlTOPp->mkMac__DOT__x___05Fh127254 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127256) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127257));
    vlTOPp->mkMac__DOT__x___05Fh134102 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134104) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134105));
    vlTOPp->mkMac__DOT__y___05Fh73689 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73498));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d354 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30550) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30551)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245) 
                             ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247))));
    vlTOPp->mkMac__DOT__y___05Fh30800 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30551));
    vlTOPp->mkMac__DOT__y___05Fh30802 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30551));
    vlTOPp->mkMac__DOT__y___05Fh113879 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113626));
    vlTOPp->mkMac__DOT__y___05Fh113881 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113626));
    vlTOPp->mkMac__DOT__y___05Fh120541 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120599) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120600));
    vlTOPp->mkMac__DOT__y___05Fh127196 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127254) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127255));
    vlTOPp->mkMac__DOT__y___05Fh134044 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134102) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134103));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1126 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73689) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73498) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73307) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh73056) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1124)))));
    vlTOPp->mkMac__DOT__y___05Fh73880 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73689));
    vlTOPp->mkMac__DOT__x___05Fh30799 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30801) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30802));
    vlTOPp->mkMac__DOT__x___05Fh113878 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113880) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113881));
    vlTOPp->mkMac__DOT__y___05Fh120794 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120541));
    vlTOPp->mkMac__DOT__y___05Fh120796 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120541));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2870 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127195) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127196)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127001) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127002)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2869));
    vlTOPp->mkMac__DOT__y___05Fh127449 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127196));
    vlTOPp->mkMac__DOT__y___05Fh127451 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127196));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2791 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh134043) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh134044)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh133849) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh133850)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2790));
    vlTOPp->mkMac__DOT__y___05Fh134297 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134044));
    vlTOPp->mkMac__DOT__y___05Fh134299 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134044));
    vlTOPp->mkMac__DOT__y___05Fh74011 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73880));
    vlTOPp->mkMac__DOT__y___05Fh30742 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30799) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30800));
    vlTOPp->mkMac__DOT__y___05Fh113820 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113878) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113879));
    vlTOPp->mkMac__DOT__x___05Fh120793 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120795) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120796));
    vlTOPp->mkMac__DOT__x___05Fh127448 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127450) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127451));
    vlTOPp->mkMac__DOT__x___05Fh134296 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134298) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134299));
    vlTOPp->mkMac__DOT__mant_mult___05Fh64183 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh74011) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh73880) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1126))));
    vlTOPp->mkMac__DOT__y___05Fh30991 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30742));
    vlTOPp->mkMac__DOT__y___05Fh30993 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30742));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2018 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113819) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113820)) 
            << 0x15U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113625) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113626)) 
                          << 0x14U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2017));
    vlTOPp->mkMac__DOT__y___05Fh114073 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113820));
    vlTOPp->mkMac__DOT__y___05Fh114075 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113820));
    vlTOPp->mkMac__DOT__y___05Fh120735 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120793) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120794));
    vlTOPp->mkMac__DOT__y___05Fh127390 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127448) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127449));
    vlTOPp->mkMac__DOT__y___05Fh134238 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134296) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134297));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
        = ((4U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh64183
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040);
    vlTOPp->mkMac__DOT__x___05Fh30990 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30992) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30993));
    vlTOPp->mkMac__DOT__x___05Fh114072 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114074) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114075));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2713 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120734) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120735)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120540) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120541)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2712));
    vlTOPp->mkMac__DOT__y___05Fh120988 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120735));
    vlTOPp->mkMac__DOT__y___05Fh120990 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120735));
    vlTOPp->mkMac__DOT__y___05Fh127643 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127390));
    vlTOPp->mkMac__DOT__y___05Fh127645 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127390));
    vlTOPp->mkMac__DOT__y___05Fh134491 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134238));
    vlTOPp->mkMac__DOT__y___05Fh134493 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134238));
    vlTOPp->mkMac__DOT__x___05Fh75972 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh75590 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh75781 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh75208 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh75399 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh74826 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh75017 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh76032 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh75841 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh75650 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh75459 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh75268 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh75077 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh74827 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 3U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh30933 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30990) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30991));
    vlTOPp->mkMac__DOT__y___05Fh114014 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114072) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114073));
    vlTOPp->mkMac__DOT__x___05Fh120987 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120989) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120990));
    vlTOPp->mkMac__DOT__x___05Fh127642 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127644) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127645));
    vlTOPp->mkMac__DOT__x___05Fh134490 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134492) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134493));
    vlTOPp->mkMac__DOT__y___05Fh75076 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh74827));
    vlTOPp->mkMac__DOT__y___05Fh75078 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh74827));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d355 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30932) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30933)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30741) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30742)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d354)));
    vlTOPp->mkMac__DOT__y___05Fh31182 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30933));
    vlTOPp->mkMac__DOT__y___05Fh31184 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30933));
    vlTOPp->mkMac__DOT__y___05Fh114267 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114014));
    vlTOPp->mkMac__DOT__y___05Fh114269 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114014));
    vlTOPp->mkMac__DOT__y___05Fh120929 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120987) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120988));
    vlTOPp->mkMac__DOT__y___05Fh127584 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127642) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127643));
    vlTOPp->mkMac__DOT__y___05Fh134432 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134490) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134491));
    vlTOPp->mkMac__DOT__x___05Fh75075 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75077) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75078));
    vlTOPp->mkMac__DOT__x___05Fh31181 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31183) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31184));
    vlTOPp->mkMac__DOT__x___05Fh114266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114268) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114269));
    vlTOPp->mkMac__DOT__y___05Fh121182 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120929));
    vlTOPp->mkMac__DOT__y___05Fh121184 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120929));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2871 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127583) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127584)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127389) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127390)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2870));
    vlTOPp->mkMac__DOT__y___05Fh127837 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127584));
    vlTOPp->mkMac__DOT__y___05Fh127839 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127584));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2792 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh134431) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh134432)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh134237) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh134238)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2791));
    vlTOPp->mkMac__DOT__y___05Fh134685 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134432));
    vlTOPp->mkMac__DOT__y___05Fh134687 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134432));
    vlTOPp->mkMac__DOT__y___05Fh75018 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75075) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75076));
    vlTOPp->mkMac__DOT__y___05Fh31124 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31181) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31182));
    vlTOPp->mkMac__DOT__y___05Fh114208 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114266) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114267));
    vlTOPp->mkMac__DOT__x___05Fh121181 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121183) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121184));
    vlTOPp->mkMac__DOT__x___05Fh127836 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127838) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127839));
    vlTOPp->mkMac__DOT__x___05Fh134684 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134686) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134687));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1206 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75017) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75018)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh74826) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh74827)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130)))));
    vlTOPp->mkMac__DOT__y___05Fh75267 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75018));
    vlTOPp->mkMac__DOT__y___05Fh75269 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75018));
    vlTOPp->mkMac__DOT__y___05Fh31373 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31124));
    vlTOPp->mkMac__DOT__y___05Fh31375 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31124));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2019 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114207) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114208)) 
            << 0x17U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114013) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114014)) 
                          << 0x16U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2018));
    vlTOPp->mkMac__DOT__y___05Fh114461 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114208));
    vlTOPp->mkMac__DOT__y___05Fh114463 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114208));
    vlTOPp->mkMac__DOT__y___05Fh121123 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121181) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121182));
    vlTOPp->mkMac__DOT__y___05Fh127778 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127836) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127837));
    vlTOPp->mkMac__DOT__y___05Fh134626 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134684) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134685));
    vlTOPp->mkMac__DOT__x___05Fh75266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75268) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75269));
    vlTOPp->mkMac__DOT__x___05Fh31372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31374) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31375));
    vlTOPp->mkMac__DOT__x___05Fh114460 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114462) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114463));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2714 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121122) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121123)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120928) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120929)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2713));
    vlTOPp->mkMac__DOT__y___05Fh121376 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121123));
    vlTOPp->mkMac__DOT__y___05Fh121378 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121123));
    vlTOPp->mkMac__DOT__y___05Fh128031 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127778));
    vlTOPp->mkMac__DOT__y___05Fh128033 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127778));
    vlTOPp->mkMac__DOT__y___05Fh134879 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134626));
    vlTOPp->mkMac__DOT__y___05Fh134881 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134626));
    vlTOPp->mkMac__DOT__y___05Fh75209 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75266) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75267));
    vlTOPp->mkMac__DOT__y___05Fh31315 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31372) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31373));
    vlTOPp->mkMac__DOT__y___05Fh114402 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114460) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114461));
    vlTOPp->mkMac__DOT__x___05Fh121375 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121377) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121378));
    vlTOPp->mkMac__DOT__x___05Fh128030 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128032) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128033));
    vlTOPp->mkMac__DOT__x___05Fh134878 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134880) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134881));
    vlTOPp->mkMac__DOT__y___05Fh75458 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75209));
    vlTOPp->mkMac__DOT__y___05Fh75460 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75209));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d356 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31314) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31315)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31123) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31124)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d355)));
    vlTOPp->mkMac__DOT__y___05Fh31564 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31315));
    vlTOPp->mkMac__DOT__y___05Fh31566 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31315));
    vlTOPp->mkMac__DOT__y___05Fh114655 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114402));
    vlTOPp->mkMac__DOT__y___05Fh114657 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114402));
    vlTOPp->mkMac__DOT__y___05Fh121317 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121375) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121376));
    vlTOPp->mkMac__DOT__y___05Fh127972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128030) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128031));
    vlTOPp->mkMac__DOT__y___05Fh134820 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh134878) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh134879));
    vlTOPp->mkMac__DOT__x___05Fh75457 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75459) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75460));
    vlTOPp->mkMac__DOT__x___05Fh31563 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31565) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31566));
    vlTOPp->mkMac__DOT__x___05Fh114654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114656) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114657));
    vlTOPp->mkMac__DOT__y___05Fh121570 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121317));
    vlTOPp->mkMac__DOT__y___05Fh121572 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121317));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2872 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127971) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127972)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127777) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127778)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2871));
    vlTOPp->mkMac__DOT__y___05Fh128225 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127972));
    vlTOPp->mkMac__DOT__y___05Fh128227 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127972));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2793 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh134819) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh134820)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh134625) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh134626)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2792));
    vlTOPp->mkMac__DOT__y___05Fh135073 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134820));
    vlTOPp->mkMac__DOT__y___05Fh135075 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134820));
    vlTOPp->mkMac__DOT__y___05Fh75400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75457) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75458));
    vlTOPp->mkMac__DOT__y___05Fh31506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31563) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31564));
    vlTOPp->mkMac__DOT__y___05Fh114596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114654) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114655));
    vlTOPp->mkMac__DOT__x___05Fh121569 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121571) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121572));
    vlTOPp->mkMac__DOT__x___05Fh128224 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128226) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128227));
    vlTOPp->mkMac__DOT__x___05Fh135072 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135074) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135075));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1207 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75399) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75400)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75208) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75209)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1206)));
    vlTOPp->mkMac__DOT__y___05Fh75649 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75400));
    vlTOPp->mkMac__DOT__y___05Fh75651 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75400));
    vlTOPp->mkMac__DOT__y___05Fh31755 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31506));
    vlTOPp->mkMac__DOT__y___05Fh31757 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31506));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2020 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114595) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114596)) 
            << 0x19U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114401) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114402)) 
                          << 0x18U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2019));
    vlTOPp->mkMac__DOT__y___05Fh114849 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114596));
    vlTOPp->mkMac__DOT__y___05Fh114851 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114596));
    vlTOPp->mkMac__DOT__y___05Fh121511 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121569) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121570));
    vlTOPp->mkMac__DOT__y___05Fh128166 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128224) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128225));
    vlTOPp->mkMac__DOT__y___05Fh135014 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135072) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135073));
    vlTOPp->mkMac__DOT__x___05Fh75648 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75650) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75651));
    vlTOPp->mkMac__DOT__x___05Fh31754 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31756) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31757));
    vlTOPp->mkMac__DOT__x___05Fh114848 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114850) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114851));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2715 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121510) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121511)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121316) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121317)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2714));
    vlTOPp->mkMac__DOT__y___05Fh121764 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121511));
    vlTOPp->mkMac__DOT__y___05Fh121766 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121511));
    vlTOPp->mkMac__DOT__y___05Fh128419 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128166));
    vlTOPp->mkMac__DOT__y___05Fh128421 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128166));
    vlTOPp->mkMac__DOT__y___05Fh135267 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135014));
    vlTOPp->mkMac__DOT__y___05Fh135269 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135014));
    vlTOPp->mkMac__DOT__y___05Fh75591 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75648) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75649));
    vlTOPp->mkMac__DOT__y___05Fh31697 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31754) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31755));
    vlTOPp->mkMac__DOT__y___05Fh114790 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114848) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114849));
    vlTOPp->mkMac__DOT__x___05Fh121763 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121765) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121766));
    vlTOPp->mkMac__DOT__x___05Fh128418 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128420) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128421));
    vlTOPp->mkMac__DOT__x___05Fh135266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135268) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135269));
    vlTOPp->mkMac__DOT__y___05Fh75840 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75591));
    vlTOPp->mkMac__DOT__y___05Fh75842 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75591));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d357 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31696) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31697)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31505) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31506)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d356)));
    vlTOPp->mkMac__DOT__y___05Fh31946 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31697));
    vlTOPp->mkMac__DOT__y___05Fh31948 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31697));
    vlTOPp->mkMac__DOT__y___05Fh115043 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114790));
    vlTOPp->mkMac__DOT__y___05Fh115045 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114790));
    vlTOPp->mkMac__DOT__y___05Fh121705 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121763) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121764));
    vlTOPp->mkMac__DOT__y___05Fh128360 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128418) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128419));
    vlTOPp->mkMac__DOT__y___05Fh135208 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135266) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135267));
    vlTOPp->mkMac__DOT__x___05Fh75839 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75841) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75842));
    vlTOPp->mkMac__DOT__x___05Fh31945 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31947) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31948));
    vlTOPp->mkMac__DOT__x___05Fh115042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115044) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115045));
    vlTOPp->mkMac__DOT__y___05Fh121958 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121705));
    vlTOPp->mkMac__DOT__y___05Fh121960 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121705));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2873 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128359) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128360)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128165) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128166)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2872));
    vlTOPp->mkMac__DOT__y___05Fh128613 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128360));
    vlTOPp->mkMac__DOT__y___05Fh128615 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128360));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2794 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135207) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135208)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135013) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135014)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2793));
    vlTOPp->mkMac__DOT__y___05Fh135461 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135208));
    vlTOPp->mkMac__DOT__y___05Fh135463 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135208));
    vlTOPp->mkMac__DOT__y___05Fh75782 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75839) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75840));
    vlTOPp->mkMac__DOT__y___05Fh31888 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31945) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31946));
    vlTOPp->mkMac__DOT__y___05Fh114984 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115042) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115043));
    vlTOPp->mkMac__DOT__x___05Fh121957 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121959) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121960));
    vlTOPp->mkMac__DOT__x___05Fh128612 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128614) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128615));
    vlTOPp->mkMac__DOT__x___05Fh135460 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135462) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135463));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1208 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75781) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75782)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75590) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75591)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1207)));
    vlTOPp->mkMac__DOT__y___05Fh76031 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75782));
    vlTOPp->mkMac__DOT__y___05Fh76033 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75782));
    vlTOPp->mkMac__DOT__y___05Fh32137 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31888));
    vlTOPp->mkMac__DOT__y___05Fh32139 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh31888));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2021 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114983) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114984)) 
            << 0x1bU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114789) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114790)) 
                          << 0x1aU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2020));
    vlTOPp->mkMac__DOT__y___05Fh115237 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114984));
    vlTOPp->mkMac__DOT__y___05Fh115239 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114984));
    vlTOPp->mkMac__DOT__y___05Fh121899 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121957) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121958));
    vlTOPp->mkMac__DOT__y___05Fh128554 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128612) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128613));
    vlTOPp->mkMac__DOT__y___05Fh135402 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135460) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135461));
    vlTOPp->mkMac__DOT__x___05Fh76030 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76032) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76033));
    vlTOPp->mkMac__DOT__x___05Fh32136 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32138) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32139));
    vlTOPp->mkMac__DOT__x___05Fh115236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115238) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115239));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2716 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121898) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121899)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121704) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121705)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2715));
    vlTOPp->mkMac__DOT__y___05Fh122152 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121899));
    vlTOPp->mkMac__DOT__y___05Fh122154 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121899));
    vlTOPp->mkMac__DOT__y___05Fh128807 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128554));
    vlTOPp->mkMac__DOT__y___05Fh128809 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128554));
    vlTOPp->mkMac__DOT__y___05Fh135655 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135402));
    vlTOPp->mkMac__DOT__y___05Fh135657 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135402));
    vlTOPp->mkMac__DOT__y___05Fh76222 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76030) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76031));
    vlTOPp->mkMac__DOT__y___05Fh32079 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32136) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32137));
    vlTOPp->mkMac__DOT__y___05Fh115178 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115236) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115237));
    vlTOPp->mkMac__DOT__x___05Fh122151 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122153) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122154));
    vlTOPp->mkMac__DOT__x___05Fh128806 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128808) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128809));
    vlTOPp->mkMac__DOT__x___05Fh135654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135656) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135657));
    vlTOPp->mkMac__DOT__y___05Fh76224 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76222));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d358 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32078) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32079)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31887) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31888)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d357)));
    vlTOPp->mkMac__DOT__y___05Fh32328 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh32079));
    vlTOPp->mkMac__DOT__y___05Fh32330 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32079));
    vlTOPp->mkMac__DOT__y___05Fh115431 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115178));
    vlTOPp->mkMac__DOT__y___05Fh115433 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115178));
    vlTOPp->mkMac__DOT__y___05Fh122093 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122151) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122152));
    vlTOPp->mkMac__DOT__y___05Fh128748 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128806) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128807));
    vlTOPp->mkMac__DOT__y___05Fh135596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135654) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135655));
    vlTOPp->mkMac__DOT__x___05Fh76221 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 0xaU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh76224)));
    vlTOPp->mkMac__DOT__x___05Fh32327 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32329) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32330));
    vlTOPp->mkMac__DOT__x___05Fh115430 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115432) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115433));
    vlTOPp->mkMac__DOT__y___05Fh122346 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122093));
    vlTOPp->mkMac__DOT__y___05Fh122348 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122093));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2874 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128747) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128748)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128553) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128554)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2873));
    vlTOPp->mkMac__DOT__y___05Fh129001 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128748));
    vlTOPp->mkMac__DOT__y___05Fh129003 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128748));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2795 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135595) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135596)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135401) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135402)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2794));
    vlTOPp->mkMac__DOT__y___05Fh135849 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135596));
    vlTOPp->mkMac__DOT__y___05Fh135851 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135596));
    vlTOPp->mkMac__DOT__y___05Fh76164 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76221) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76222));
    vlTOPp->mkMac__DOT__y___05Fh32270 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32327) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32328));
    vlTOPp->mkMac__DOT__y___05Fh115372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115430) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115431));
    vlTOPp->mkMac__DOT__x___05Fh122345 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122347) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122348));
    vlTOPp->mkMac__DOT__x___05Fh129000 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129002) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129003));
    vlTOPp->mkMac__DOT__x___05Fh135848 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135850) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135851));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1209 
        = ((0x800U & ((0xfffff800U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh76164) 
                         << 0xbU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75972) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76222)) 
                                        << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1208)));
    vlTOPp->mkMac__DOT__y___05Fh76415 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76164));
    vlTOPp->mkMac__DOT__y___05Fh32519 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32270));
    vlTOPp->mkMac__DOT__y___05Fh32521 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32270));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2022 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115371) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115372)) 
            << 0x1dU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115177) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115178)) 
                          << 0x1cU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2021));
    vlTOPp->mkMac__DOT__y___05Fh115625 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115372));
    vlTOPp->mkMac__DOT__y___05Fh115627 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115372));
    vlTOPp->mkMac__DOT__y___05Fh122287 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122345) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122346));
    vlTOPp->mkMac__DOT__y___05Fh128942 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129000) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129001));
    vlTOPp->mkMac__DOT__y___05Fh135790 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh135848) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh135849));
    vlTOPp->mkMac__DOT__y___05Fh76606 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76415));
    vlTOPp->mkMac__DOT__x___05Fh32518 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32520) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32521));
    vlTOPp->mkMac__DOT__x___05Fh115624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115626) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115627));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2717 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122286) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122287)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122092) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122093)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2716));
    vlTOPp->mkMac__DOT__y___05Fh122540 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122287));
    vlTOPp->mkMac__DOT__y___05Fh122542 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122287));
    vlTOPp->mkMac__DOT__y___05Fh129195 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128942));
    vlTOPp->mkMac__DOT__y___05Fh129197 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128942));
    vlTOPp->mkMac__DOT__y___05Fh136043 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135790));
    vlTOPp->mkMac__DOT__y___05Fh136045 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135790));
    vlTOPp->mkMac__DOT__y___05Fh76797 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76606));
    vlTOPp->mkMac__DOT__y___05Fh32461 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32518) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32519));
    vlTOPp->mkMac__DOT__y___05Fh115566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115624) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115625));
    vlTOPp->mkMac__DOT__x___05Fh122539 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122541) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122542));
    vlTOPp->mkMac__DOT__x___05Fh129194 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129196) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129197));
    vlTOPp->mkMac__DOT__x___05Fh136042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136044) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136045));
    vlTOPp->mkMac__DOT__y___05Fh76928 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76797));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d359 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32460) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32461)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32269) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32270)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d358)));
    vlTOPp->mkMac__DOT__y___05Fh32710 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32461));
    vlTOPp->mkMac__DOT__y___05Fh32712 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32461));
    vlTOPp->mkMac__DOT__y___05Fh115819 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115566));
    vlTOPp->mkMac__DOT__y___05Fh115821 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115566));
    vlTOPp->mkMac__DOT__y___05Fh122481 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122539) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122540));
    vlTOPp->mkMac__DOT__y___05Fh129136 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129194) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129195));
    vlTOPp->mkMac__DOT__y___05Fh135984 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136042) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136043));
    vlTOPp->mkMac__DOT__mant_mult___05Fh63739 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh76928) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh76797) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh76606) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh76415) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1209))))));
    vlTOPp->mkMac__DOT__x___05Fh32709 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32711) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32712));
    vlTOPp->mkMac__DOT__x___05Fh115818 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115820) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115821));
    vlTOPp->mkMac__DOT__y___05Fh122734 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122481));
    vlTOPp->mkMac__DOT__y___05Fh122736 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122481));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2875 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129135) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129136)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128941) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128942)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2874));
    vlTOPp->mkMac__DOT__y___05Fh129389 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129136));
    vlTOPp->mkMac__DOT__y___05Fh129391 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129136));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2796 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135983) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135984)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh135789) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh135790)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2795));
    vlTOPp->mkMac__DOT__y___05Fh136237 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135984));
    vlTOPp->mkMac__DOT__y___05Fh136239 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135984));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
        = ((8U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh63739
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128);
    vlTOPp->mkMac__DOT__y___05Fh32652 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32709) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32710));
    vlTOPp->mkMac__DOT__y___05Fh115760 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115818) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115819));
    vlTOPp->mkMac__DOT__x___05Fh122733 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122735) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122736));
    vlTOPp->mkMac__DOT__x___05Fh129388 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129390) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129391));
    vlTOPp->mkMac__DOT__x___05Fh136236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136238) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136239));
    vlTOPp->mkMac__DOT__x___05Fh78889 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh79080 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh78507 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh78698 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh78125 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78316 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh77934 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh79140 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh78949 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh78758 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh78567 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh78376 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78185 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh77935 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 4U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh32901 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32652));
    vlTOPp->mkMac__DOT__y___05Fh32903 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32652));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2023 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115759) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115760)) 
            << 0x1fU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115565) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115566)) 
                          << 0x1eU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2022));
    vlTOPp->mkMac__DOT__y___05Fh122675 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122733) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122734));
    vlTOPp->mkMac__DOT__y___05Fh129330 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129388) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129389));
    vlTOPp->mkMac__DOT__y___05Fh136178 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136236) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136237));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1287 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh77934) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh77935)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214))));
    vlTOPp->mkMac__DOT__y___05Fh78184 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh77935));
    vlTOPp->mkMac__DOT__y___05Fh78186 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh77935));
    vlTOPp->mkMac__DOT__x___05Fh32900 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32902) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32903));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2718 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122674) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122675)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122480) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122481)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2717));
    vlTOPp->mkMac__DOT__y___05Fh122928 = ((vlTOPp->mkMac__DOT__mant_y___05Fh115951 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122675));
    vlTOPp->mkMac__DOT__y___05Fh122930 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122675));
    vlTOPp->mkMac__DOT__y___05Fh129583 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129330));
    vlTOPp->mkMac__DOT__y___05Fh129585 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129330));
    vlTOPp->mkMac__DOT__y___05Fh136431 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136178));
    vlTOPp->mkMac__DOT__y___05Fh136433 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136178));
    vlTOPp->mkMac__DOT__x___05Fh78183 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78185) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78186));
    vlTOPp->mkMac__DOT__y___05Fh32843 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32900) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32901));
    vlTOPp->mkMac__DOT__x___05Fh122927 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122929) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122930));
    vlTOPp->mkMac__DOT__x___05Fh129582 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129584) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129585));
    vlTOPp->mkMac__DOT__x___05Fh136430 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136432) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136433));
    vlTOPp->mkMac__DOT__y___05Fh78126 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78183) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78184));
    vlTOPp->mkMac__DOT__product___05Fh14752 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32842) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32843)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32651) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32652)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d359))));
    vlTOPp->mkMac__DOT__y___05Fh122869 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122927) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122928));
    vlTOPp->mkMac__DOT__y___05Fh129524 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129582) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129583));
    vlTOPp->mkMac__DOT__y___05Fh136372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136430) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136431));
    vlTOPp->mkMac__DOT__y___05Fh78375 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78126));
    vlTOPp->mkMac__DOT__y___05Fh78377 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78126));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
        = ((4U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh14752
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245);
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2876 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129523) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129524)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129329) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129330)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2875));
    vlTOPp->mkMac__DOT__y___05Fh129777 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129524));
    vlTOPp->mkMac__DOT__y___05Fh129779 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129524));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2797 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh136371) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh136372)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh136177) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh136178)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2796));
    vlTOPp->mkMac__DOT__y___05Fh136625 = ((vlTOPp->mkMac__DOT__mant_x___05Fh115950 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136372));
    vlTOPp->mkMac__DOT__y___05Fh136627 = ((vlTOPp->mkMac__DOT__INV_mant_y15951___05Fq13 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136372));
    vlTOPp->mkMac__DOT__x___05Fh78374 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78376) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78377));
    vlTOPp->mkMac__DOT__x___05Fh37208 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh37399 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh36826 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh37017 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh36444 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36635 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh37459 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh36062 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36253 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh35680 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh35871 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh35298 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh35489 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh37268 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh37077 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh36886 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh36695 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36504 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh36313 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36122 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh35931 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh35740 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh35549 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh35299 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 3U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__x___05Fh129776 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129778) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129779));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2878 
        = ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2024)
            ? vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2718
            : ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2043)
                ? vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2797
                : vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2876));
    vlTOPp->mkMac__DOT__x___05Fh136624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136626) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136627));
    vlTOPp->mkMac__DOT__y___05Fh78317 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78374) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78375));
    vlTOPp->mkMac__DOT__y___05Fh35548 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35299));
    vlTOPp->mkMac__DOT__y___05Fh35550 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35299));
    vlTOPp->mkMac__DOT__y___05Fh129718 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129776) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129777));
    vlTOPp->mkMac__DOT__y___05Fh136566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh136624) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh136625));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1288 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78316) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78317)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78125) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78126)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1287)));
    vlTOPp->mkMac__DOT__y___05Fh78566 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78317));
    vlTOPp->mkMac__DOT__y___05Fh78568 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78317));
    vlTOPp->mkMac__DOT__x___05Fh35547 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35549) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35550));
    vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0_ETC___05F_d2606 
        = ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2043)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh136565) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh136566))
            : ((IData)(vlTOPp->mkMac__DOT__x___05Fh129717) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129718)));
    vlTOPp->mkMac__DOT__x___05Fh78565 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78567) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78568));
    vlTOPp->mkMac__DOT__y___05Fh35490 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35547) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35548));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2607 
        = ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2024)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh122868) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122869))
            : (IData)(vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0_ETC___05F_d2606));
    vlTOPp->mkMac__DOT__y___05Fh78508 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78565) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78566));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d462 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35489) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35490)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35298) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35299)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361) 
                                        ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363)))));
    vlTOPp->mkMac__DOT__y___05Fh35739 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35490));
    vlTOPp->mkMac__DOT__y___05Fh35741 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35490));
    if (vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2607) {
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05Fq19 
            = vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh136757;
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
            = (((IData)(vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2607) 
                << 0x1eU) | (0x3fffffffU & (vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2878 
                                            >> 1U)));
    } else {
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05Fq19 
            = vlTOPp->mkMac__DOT__exp_x___05Fh115948;
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
            = vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2878;
    }
    vlTOPp->mkMac__DOT__y___05Fh78757 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78508));
    vlTOPp->mkMac__DOT__y___05Fh78759 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78508));
    vlTOPp->mkMac__DOT__x___05Fh35738 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35740) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35741));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713___05FETC___05Fq18 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__y___05Fh140755 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                                 >> 8U) 
                                                & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                                   >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh78756 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78758) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78759));
    vlTOPp->mkMac__DOT__y___05Fh35681 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35738) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35739));
    vlTOPp->mkMac__DOT__y___05Fh140943 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh140755));
    vlTOPp->mkMac__DOT__y___05Fh78699 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78756) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78757));
    vlTOPp->mkMac__DOT__y___05Fh35930 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35681));
    vlTOPp->mkMac__DOT__y___05Fh35932 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35681));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2959 
        = ((0x400U & ((0xfffffc00U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh140943) 
                         << 0xaU))) | ((0x200U & ((0xfffffe00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh140755) 
                                                   << 9U))) 
                                       | ((0x100U & 
                                           ((0xffffff00U 
                                             & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                            ^ (0xffffff00U 
                                               & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                                  << 1U)))) 
                                          | ((0x80U 
                                              & ((~ 
                                                  (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                                   >> 7U)) 
                                                 << 7U)) 
                                             | ((0x7eU 
                                                 & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                | (1U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713___05FETC___05Fq18))))));
    vlTOPp->mkMac__DOT__y___05Fh141131 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh140943));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1289 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78698) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78699)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78507) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78508)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1288)));
    vlTOPp->mkMac__DOT__y___05Fh78948 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78699));
    vlTOPp->mkMac__DOT__y___05Fh78950 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78699));
    vlTOPp->mkMac__DOT__x___05Fh35929 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35931) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35932));
    vlTOPp->mkMac__DOT__y___05Fh141319 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh141131));
    vlTOPp->mkMac__DOT__x___05Fh78947 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78949) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78950));
    vlTOPp->mkMac__DOT__y___05Fh35872 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35929) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35930));
    vlTOPp->mkMac__DOT__y___05Fh141507 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh141319));
    vlTOPp->mkMac__DOT__y___05Fh78890 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78947) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78948));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d463 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35871) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35872)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35680) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35681)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d462)));
    vlTOPp->mkMac__DOT__y___05Fh36121 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35872));
    vlTOPp->mkMac__DOT__y___05Fh36123 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35872));
    vlTOPp->mkMac__DOT__y___05Fh141695 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh141507));
    vlTOPp->mkMac__DOT__y___05Fh79139 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78890));
    vlTOPp->mkMac__DOT__y___05Fh79141 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh78890));
    vlTOPp->mkMac__DOT__x___05Fh36120 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36122) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36123));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2961 
        = ((0x4000U & ((0xffffc000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh141695) 
                          << 0xeU))) | ((0x2000U & 
                                         ((0xffffe000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh141507) 
                                             << 0xdU))) 
                                        | ((0x1000U 
                                            & ((0xfffff000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh141319) 
                                                  << 0xcU))) 
                                           | ((0x800U 
                                               & ((0xfffff800U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh141131) 
                                                   << 0xbU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2959)))));
    vlTOPp->mkMac__DOT__y___05Fh141883 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh141695));
    vlTOPp->mkMac__DOT__x___05Fh79138 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79140) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79141));
    vlTOPp->mkMac__DOT__y___05Fh36063 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36120) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36121));
    vlTOPp->mkMac__DOT__y___05Fh142071 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh141883));
    vlTOPp->mkMac__DOT__y___05Fh79330 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79138) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79139));
    vlTOPp->mkMac__DOT__y___05Fh36312 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36063));
    vlTOPp->mkMac__DOT__y___05Fh36314 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36063));
    vlTOPp->mkMac__DOT__y___05Fh142259 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh142071));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1290 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79080) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79330)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78889) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78890)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1289)));
    vlTOPp->mkMac__DOT__y___05Fh79332 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79330));
    vlTOPp->mkMac__DOT__x___05Fh36311 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36313) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36314));
    vlTOPp->mkMac__DOT__y___05Fh142447 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh142259));
    vlTOPp->mkMac__DOT__x___05Fh79329 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xbU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh79332)));
    vlTOPp->mkMac__DOT__y___05Fh36254 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36311) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36312));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2963 
        = ((0x40000U & ((0xfffc0000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh142447) 
                           << 0x12U))) | ((0x20000U 
                                           & ((0xfffe0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh142259) 
                                                 << 0x11U))) 
                                          | ((0x10000U 
                                              & ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh142071) 
                                                  << 0x10U))) 
                                             | ((0x8000U 
                                                 & ((0xffff8000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh141883) 
                                                     << 0xfU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2961)))));
    vlTOPp->mkMac__DOT__y___05Fh142635 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh142447));
    vlTOPp->mkMac__DOT__y___05Fh79272 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79329) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79330));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d464 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36253) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36254)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36062) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36063)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d463)));
    vlTOPp->mkMac__DOT__y___05Fh36503 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36254));
    vlTOPp->mkMac__DOT__y___05Fh36505 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36254));
    vlTOPp->mkMac__DOT__y___05Fh142823 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh142635));
    vlTOPp->mkMac__DOT__y___05Fh79523 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79272));
    vlTOPp->mkMac__DOT__x___05Fh36502 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36504) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36505));
    vlTOPp->mkMac__DOT__y___05Fh143011 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh142823));
    vlTOPp->mkMac__DOT__y___05Fh79714 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79523));
    vlTOPp->mkMac__DOT__y___05Fh36445 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36502) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36503));
    vlTOPp->mkMac__DOT__y___05Fh143199 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143011));
    vlTOPp->mkMac__DOT__y___05Fh79845 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79714));
    vlTOPp->mkMac__DOT__y___05Fh36694 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36445));
    vlTOPp->mkMac__DOT__y___05Fh36696 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36445));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2965 
        = ((0x400000U & ((0xffc00000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh143199) 
                            << 0x16U))) | ((0x200000U 
                                            & ((0xffe00000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh143011) 
                                                  << 0x15U))) 
                                           | ((0x100000U 
                                               & ((0xfff00000U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh142823) 
                                                   << 0x14U))) 
                                              | ((0x80000U 
                                                  & ((0xfff80000U 
                                                      & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh142635) 
                                                      << 0x13U))) 
                                                 | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2963))));
    vlTOPp->mkMac__DOT__y___05Fh143387 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143199));
    vlTOPp->mkMac__DOT__mant_mult___05Fh63295 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh79845) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh79714) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh79523) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh79272) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1290))))));
    vlTOPp->mkMac__DOT__x___05Fh36693 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36695) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36696));
    vlTOPp->mkMac__DOT__y___05Fh143575 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143387));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
        = ((0x10U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh63295
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212);
    vlTOPp->mkMac__DOT__y___05Fh36636 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36693) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36694));
    vlTOPp->mkMac__DOT__y___05Fh143763 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143575));
    vlTOPp->mkMac__DOT__x___05Fh82188 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh81806 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh81997 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh81424 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh81615 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh81042 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh81233 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh82248 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh82057 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh81866 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh81675 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh81484 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh81293 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh81043 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 5U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d465 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36635) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36636)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36444) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36445)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d464)));
    vlTOPp->mkMac__DOT__y___05Fh36885 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36636));
    vlTOPp->mkMac__DOT__y___05Fh36887 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36636));
    vlTOPp->mkMac__DOT__y___05Fh143951 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143763));
    vlTOPp->mkMac__DOT__y___05Fh81292 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81043));
    vlTOPp->mkMac__DOT__y___05Fh81294 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81043));
    vlTOPp->mkMac__DOT__x___05Fh36884 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36886) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36887));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2967 
        = ((0x4000000U & ((0xfc000000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh143951) 
                             << 0x1aU))) | ((0x2000000U 
                                             & ((0xfe000000U 
                                                 & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh143763) 
                                                   << 0x19U))) 
                                            | ((0x1000000U 
                                                & ((0xff000000U 
                                                    & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh143575) 
                                                    << 0x18U))) 
                                               | ((0x800000U 
                                                   & ((0xff800000U 
                                                       & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh143387) 
                                                       << 0x17U))) 
                                                  | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2965))));
    vlTOPp->mkMac__DOT__y___05Fh144139 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh143951));
    vlTOPp->mkMac__DOT__x___05Fh81291 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81293) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81294));
    vlTOPp->mkMac__DOT__y___05Fh36827 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36884) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36885));
    vlTOPp->mkMac__DOT__y___05Fh144327 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh144139));
    vlTOPp->mkMac__DOT__y___05Fh81234 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81291) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81292));
    vlTOPp->mkMac__DOT__y___05Fh37076 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36827));
    vlTOPp->mkMac__DOT__y___05Fh37078 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36827));
    vlTOPp->mkMac__DOT__y___05Fh144515 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh144327));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1365 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81233) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81234)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81042) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81043)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295)))));
    vlTOPp->mkMac__DOT__y___05Fh81483 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81234));
    vlTOPp->mkMac__DOT__y___05Fh81485 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81234));
    vlTOPp->mkMac__DOT__x___05Fh37075 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37077) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37078));
    vlTOPp->mkMac__DOT__y___05Fh144703 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh144515));
    vlTOPp->mkMac__DOT__x___05Fh81482 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81484) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81485));
    vlTOPp->mkMac__DOT__y___05Fh37018 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37075) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37076));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2969 
        = ((0x40000000U & ((0xc0000000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh144703) 
                              << 0x1eU))) | ((0x20000000U 
                                              & ((0xe0000000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh144515) 
                                                  << 0x1dU))) 
                                             | ((0x10000000U 
                                                 & ((0xf0000000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh144327) 
                                                     << 0x1cU))) 
                                                | ((0x8000000U 
                                                    & ((0xf8000000U 
                                                        & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh144139) 
                                                        << 0x1bU))) 
                                                   | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2967))));
    vlTOPp->mkMac__DOT__y___05Fh81425 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81482) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81483));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d466 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37017) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37018)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36826) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36827)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d465)));
    vlTOPp->mkMac__DOT__y___05Fh37267 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37018));
    vlTOPp->mkMac__DOT__y___05Fh37269 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37018));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713___05FETC___05Fq20 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881)
            ? vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2969
            : vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05F_d2881);
    vlTOPp->mkMac__DOT__y___05Fh81674 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81425));
    vlTOPp->mkMac__DOT__y___05Fh81676 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81425));
    vlTOPp->mkMac__DOT__x___05Fh37266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37268) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37269));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2972 
        = (((IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh116003) 
            << 0x1fU) | ((0x7f800000U & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_ETC___05Fq19 
                                         << 0x17U)) 
                         | (0x7fffffU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F713___05FETC___05Fq20 
                                         >> 7U))));
    vlTOPp->mkMac__DOT__x___05Fh81673 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81675) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81676));
    vlTOPp->mkMac__DOT__y___05Fh37209 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37266) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37267));
    vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(((1U & (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv))
                                              ? vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_71_ETC___05F_d2023
                                              : vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F713_BIT_32_ETC___05F_d2972))));
    vlTOPp->mkMac__DOT__y___05Fh81616 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81673) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81674));
    vlTOPp->mkMac__DOT__y___05Fh37458 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37209));
    vlTOPp->mkMac__DOT__y___05Fh37460 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37209));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1366 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81615) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81616)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81424) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81425)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1365)));
    vlTOPp->mkMac__DOT__y___05Fh81865 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81616));
    vlTOPp->mkMac__DOT__y___05Fh81867 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81616));
    vlTOPp->mkMac__DOT__x___05Fh37457 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37459) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37460));
    vlTOPp->mkMac__DOT__x___05Fh81864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81866) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81867));
    vlTOPp->mkMac__DOT__y___05Fh37400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37457) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37458));
    vlTOPp->mkMac__DOT__y___05Fh81807 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81864) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81865));
    vlTOPp->mkMac__DOT__product___05Fh12665 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37399) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37400)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37208) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37209)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d466))));
    vlTOPp->mkMac__DOT__y___05Fh82056 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81807));
    vlTOPp->mkMac__DOT__y___05Fh82058 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh81807));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
        = ((8U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh12665
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361);
    vlTOPp->mkMac__DOT__x___05Fh82055 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82057) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82058));
    vlTOPp->mkMac__DOT__x___05Fh41765 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh41956 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh41383 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41574 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41001 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41192 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh42016 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh40619 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh40810 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh40237 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40428 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40046 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh41825 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41634 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41443 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh41252 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41061 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh40870 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh40679 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40488 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40297 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh40047 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 4U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh81998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82055) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82056));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d561 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40046) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40047)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468) 
                                ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470))));
    vlTOPp->mkMac__DOT__y___05Fh40296 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40047));
    vlTOPp->mkMac__DOT__y___05Fh40298 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40047));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1367 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81997) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81998)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81806) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81807)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1366)));
    vlTOPp->mkMac__DOT__y___05Fh82247 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81998));
    vlTOPp->mkMac__DOT__y___05Fh82249 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh81998));
    vlTOPp->mkMac__DOT__x___05Fh40295 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40297) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40298));
    vlTOPp->mkMac__DOT__x___05Fh82246 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82248) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82249));
    vlTOPp->mkMac__DOT__y___05Fh40238 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40295) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40296));
    vlTOPp->mkMac__DOT__y___05Fh82438 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82246) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82247));
    vlTOPp->mkMac__DOT__y___05Fh40487 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40238));
    vlTOPp->mkMac__DOT__y___05Fh40489 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40238));
    vlTOPp->mkMac__DOT__y___05Fh82440 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82438));
    vlTOPp->mkMac__DOT__x___05Fh40486 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40488) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40489));
    vlTOPp->mkMac__DOT__x___05Fh82437 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xcU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh82440)));
    vlTOPp->mkMac__DOT__y___05Fh40429 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40486) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40487));
    vlTOPp->mkMac__DOT__y___05Fh82380 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82437) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82438));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d562 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40428) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40429)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40237) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40238)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d561)));
    vlTOPp->mkMac__DOT__y___05Fh40678 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40429));
    vlTOPp->mkMac__DOT__y___05Fh40680 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40429));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1368 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh82380) 
                          << 0xdU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82188) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82438)) 
                                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1367)));
    vlTOPp->mkMac__DOT__y___05Fh82631 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82380));
    vlTOPp->mkMac__DOT__x___05Fh40677 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40679) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40680));
    vlTOPp->mkMac__DOT__y___05Fh82762 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82631));
    vlTOPp->mkMac__DOT__y___05Fh40620 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40677) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40678));
    vlTOPp->mkMac__DOT__mant_mult___05Fh62851 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh82762) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh82631) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1368))));
    vlTOPp->mkMac__DOT__y___05Fh40869 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40620));
    vlTOPp->mkMac__DOT__y___05Fh40871 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40620));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
        = ((0x20U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh62851
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293);
    vlTOPp->mkMac__DOT__x___05Fh40868 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40870) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40871));
    vlTOPp->mkMac__DOT__x___05Fh85296 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh85105 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh84723 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh84914 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh84341 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh84532 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh84150 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh85356 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh85165 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh84974 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh84783 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh84592 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh84401 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh84151 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 6U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh40811 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40868) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40869));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1439 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84150) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84151)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372))));
    vlTOPp->mkMac__DOT__y___05Fh84400 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84151));
    vlTOPp->mkMac__DOT__y___05Fh84402 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84151));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d563 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40810) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40811)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40619) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40620)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d562)));
    vlTOPp->mkMac__DOT__y___05Fh41060 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40811));
    vlTOPp->mkMac__DOT__y___05Fh41062 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40811));
    vlTOPp->mkMac__DOT__x___05Fh84399 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84401) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84402));
    vlTOPp->mkMac__DOT__x___05Fh41059 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41061) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41062));
    vlTOPp->mkMac__DOT__y___05Fh84342 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84399) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84400));
    vlTOPp->mkMac__DOT__y___05Fh41002 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41059) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41060));
    vlTOPp->mkMac__DOT__y___05Fh84591 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84342));
    vlTOPp->mkMac__DOT__y___05Fh84593 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84342));
    vlTOPp->mkMac__DOT__y___05Fh41251 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41002));
    vlTOPp->mkMac__DOT__y___05Fh41253 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41002));
    vlTOPp->mkMac__DOT__x___05Fh84590 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84592) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84593));
    vlTOPp->mkMac__DOT__x___05Fh41250 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41252) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41253));
    vlTOPp->mkMac__DOT__y___05Fh84533 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84590) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84591));
    vlTOPp->mkMac__DOT__y___05Fh41193 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41250) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41251));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1440 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84532) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84533)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84341) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84342)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1439)));
    vlTOPp->mkMac__DOT__y___05Fh84782 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84533));
    vlTOPp->mkMac__DOT__y___05Fh84784 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84533));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d564 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41192) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41193)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41001) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41002)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d563)));
    vlTOPp->mkMac__DOT__y___05Fh41442 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41193));
    vlTOPp->mkMac__DOT__y___05Fh41444 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41193));
    vlTOPp->mkMac__DOT__x___05Fh84781 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84783) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84784));
    vlTOPp->mkMac__DOT__x___05Fh41441 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41443) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41444));
    vlTOPp->mkMac__DOT__y___05Fh84724 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84781) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84782));
    vlTOPp->mkMac__DOT__y___05Fh41384 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41441) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41442));
    vlTOPp->mkMac__DOT__y___05Fh84973 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84724));
    vlTOPp->mkMac__DOT__y___05Fh84975 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh84724));
    vlTOPp->mkMac__DOT__y___05Fh41633 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41384));
    vlTOPp->mkMac__DOT__y___05Fh41635 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41384));
    vlTOPp->mkMac__DOT__x___05Fh84972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84974) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84975));
    vlTOPp->mkMac__DOT__x___05Fh41632 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41634) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41635));
    vlTOPp->mkMac__DOT__y___05Fh84915 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84972) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84973));
    vlTOPp->mkMac__DOT__y___05Fh41575 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41632) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41633));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1441 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84914) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84915)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84723) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84724)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1440)));
    vlTOPp->mkMac__DOT__y___05Fh85164 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84915));
    vlTOPp->mkMac__DOT__y___05Fh85166 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh84915));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d565 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41574) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41575)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41383) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41384)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d564)));
    vlTOPp->mkMac__DOT__y___05Fh41824 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41575));
    vlTOPp->mkMac__DOT__y___05Fh41826 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41575));
    vlTOPp->mkMac__DOT__x___05Fh85163 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85165) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85166));
    vlTOPp->mkMac__DOT__x___05Fh41823 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41825) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41826));
    vlTOPp->mkMac__DOT__y___05Fh85106 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85163) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85164));
    vlTOPp->mkMac__DOT__y___05Fh41766 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41823) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41824));
    vlTOPp->mkMac__DOT__y___05Fh85355 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85106));
    vlTOPp->mkMac__DOT__y___05Fh85357 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85106));
    vlTOPp->mkMac__DOT__y___05Fh42015 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41766));
    vlTOPp->mkMac__DOT__y___05Fh42017 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41766));
    vlTOPp->mkMac__DOT__x___05Fh85354 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85356) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85357));
    vlTOPp->mkMac__DOT__x___05Fh42014 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42016) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42017));
    vlTOPp->mkMac__DOT__y___05Fh85546 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85354) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85355));
    vlTOPp->mkMac__DOT__y___05Fh41957 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42014) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42015));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1442 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85296) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85546)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85105) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85106)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1441)));
    vlTOPp->mkMac__DOT__y___05Fh85548 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85546));
    vlTOPp->mkMac__DOT__product___05Fh10578 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41956) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41957)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41765) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41766)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d565))));
    vlTOPp->mkMac__DOT__x___05Fh85545 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xdU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh85548)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
        = ((0x10U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh10578
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468);
    vlTOPp->mkMac__DOT__y___05Fh85488 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85545) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85546));
    vlTOPp->mkMac__DOT__x___05Fh46322 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh46513 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh45940 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46131 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh45558 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh45749 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh46573 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh45176 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45367 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh44794 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh44985 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh46382 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh46191 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46000 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh45809 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh45618 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh45427 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45236 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh45045 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh44795 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 5U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh85679 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85488));
    vlTOPp->mkMac__DOT__y___05Fh45044 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44795));
    vlTOPp->mkMac__DOT__y___05Fh45046 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44795));
    vlTOPp->mkMac__DOT__mant_mult___05Fh62407 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh85679) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh85488) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1442))));
    vlTOPp->mkMac__DOT__x___05Fh45043 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45045) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45046));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
        = ((0x40U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh62407
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370);
    vlTOPp->mkMac__DOT__y___05Fh44986 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45043) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45044));
    vlTOPp->mkMac__DOT__x___05Fh88404 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__x___05Fh88213 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xdU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh88022 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh87831 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh88464 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xdU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh87640 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499 
        = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                  >> 7U) ^ (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__x___05Fh87449 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh87258 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh88273 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh88082 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh87891 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh87700 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh87509 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh87259 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 7U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d652 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh44985) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh44986)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh44794) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh44795)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567) 
                                           ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569)))));
    vlTOPp->mkMac__DOT__y___05Fh45235 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44986));
    vlTOPp->mkMac__DOT__y___05Fh45237 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44986));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1502 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501 
        = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
            >> 6U) & ((0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))) 
                      | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499)));
    vlTOPp->mkMac__DOT__x___05Fh95483 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87258) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__y___05Fh87508 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__y___05Fh87510 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__x___05Fh45234 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45236) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45237));
    if (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501) {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1691 
            = (1U & (~ (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499)));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1689 
            = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95483) 
               ^ (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499));
    } else {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1691 
            = (1U & (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1689 
            = vlTOPp->mkMac__DOT__x___05Fh95483;
    }
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647 
        = (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492)))) 
           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499) 
               & (0U == ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                         | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492)))) 
              & (IData)(vlTOPp->mkMac__DOT__x___05Fh95483)));
    vlTOPp->mkMac__DOT__y___05Fh95672 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95483) 
                                         & (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499));
    vlTOPp->mkMac__DOT__x___05Fh87507 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87509) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87510));
    vlTOPp->mkMac__DOT__y___05Fh45177 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45234) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45235));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1699 
        = (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1691) 
            << 7U) | ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
                                ? vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1502
                                : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1671 
        = ((0x80U & (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
                       ? (~ (IData)(vlTOPp->mkMac__DOT__x___05Fh95483))
                       : (IData)(vlTOPp->mkMac__DOT__x___05Fh95483)) 
                     << 7U)) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1499) 
                                 << 6U) | (0x3fU & 
                                           (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                            >> 1U))));
    vlTOPp->mkMac__DOT__y___05Fh87450 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87507) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87508));
    vlTOPp->mkMac__DOT__y___05Fh45426 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45177));
    vlTOPp->mkMac__DOT__y___05Fh45428 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45177));
    vlTOPp->mkMac__DOT__x___05Fh95671 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87449) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__y___05Fh87699 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__y___05Fh87701 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__x___05Fh45425 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45427) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45428));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1687 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95672))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95671));
    vlTOPp->mkMac__DOT__y___05Fh104208 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
                                          & (IData)(vlTOPp->mkMac__DOT__x___05Fh95483));
    vlTOPp->mkMac__DOT__y___05Fh95860 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95672));
    vlTOPp->mkMac__DOT__x___05Fh87698 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87700) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87701));
    vlTOPp->mkMac__DOT__y___05Fh45368 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45425) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45426));
    vlTOPp->mkMac__DOT__y___05Fh87641 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87698) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87699));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d653 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45367) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45368)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45176) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45177)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d652)));
    vlTOPp->mkMac__DOT__y___05Fh45617 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45368));
    vlTOPp->mkMac__DOT__y___05Fh45619 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45368));
    vlTOPp->mkMac__DOT__x___05Fh95859 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87640) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__y___05Fh87890 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__y___05Fh87892 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__x___05Fh45616 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45618) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45619));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1672 
        = ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
              ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
                 ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104208))
              : (IData)(vlTOPp->mkMac__DOT__x___05Fh95859)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
                         ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
                            ^ (IData)(vlTOPp->mkMac__DOT__x___05Fh95483))
                         : (IData)(vlTOPp->mkMac__DOT__x___05Fh95671)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1671)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95860))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95859));
    vlTOPp->mkMac__DOT__y___05Fh104396 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104208));
    vlTOPp->mkMac__DOT__y___05Fh96048 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95860));
    vlTOPp->mkMac__DOT__x___05Fh87889 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87891) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87892));
    vlTOPp->mkMac__DOT__y___05Fh45559 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45616) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45617));
    vlTOPp->mkMac__DOT__y___05Fh87832 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87889) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87890));
    vlTOPp->mkMac__DOT__y___05Fh45808 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45559));
    vlTOPp->mkMac__DOT__y___05Fh45810 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45559));
    vlTOPp->mkMac__DOT__x___05Fh96047 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87831) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__y___05Fh88081 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__y___05Fh88083 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__x___05Fh45807 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45809) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45810));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96048))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96047));
    vlTOPp->mkMac__DOT__y___05Fh104584 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104396));
    vlTOPp->mkMac__DOT__y___05Fh96236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96048));
    vlTOPp->mkMac__DOT__x___05Fh88080 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88082) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88083));
    vlTOPp->mkMac__DOT__y___05Fh45750 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45807) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45808));
    vlTOPp->mkMac__DOT__y___05Fh88023 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88080) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88081));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d654 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45749) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45750)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45558) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45559)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d653)));
    vlTOPp->mkMac__DOT__y___05Fh45999 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45750));
    vlTOPp->mkMac__DOT__y___05Fh46001 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45750));
    vlTOPp->mkMac__DOT__x___05Fh96235 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88022) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__y___05Fh88272 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__y___05Fh88274 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__x___05Fh45998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46000) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46001));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1673 
        = ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
              ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
                 ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104584))
              : (IData)(vlTOPp->mkMac__DOT__x___05Fh96235)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
                           ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
                              ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104396))
                           : (IData)(vlTOPp->mkMac__DOT__x___05Fh96047)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1672)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96236))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96235));
    vlTOPp->mkMac__DOT__y___05Fh104772 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104584));
    vlTOPp->mkMac__DOT__y___05Fh96424 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96236));
    vlTOPp->mkMac__DOT__x___05Fh88271 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88273) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88274));
    vlTOPp->mkMac__DOT__y___05Fh45941 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45998) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45999));
    vlTOPp->mkMac__DOT__y___05Fh88214 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88271) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88272));
    vlTOPp->mkMac__DOT__y___05Fh46190 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45941));
    vlTOPp->mkMac__DOT__y___05Fh46192 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45941));
    vlTOPp->mkMac__DOT__x___05Fh96423 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88213) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__y___05Fh88463 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__y___05Fh88465 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__x___05Fh46189 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46191) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46192));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96424))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96423));
    vlTOPp->mkMac__DOT__y___05Fh104960 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104772));
    vlTOPp->mkMac__DOT__y___05Fh96612 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96424));
    vlTOPp->mkMac__DOT__x___05Fh88462 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88464) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88465));
    vlTOPp->mkMac__DOT__y___05Fh46132 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46189) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46190));
    vlTOPp->mkMac__DOT__y___05Fh88654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88462) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88463));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d655 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46131) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46132)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45940) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45941)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d654)));
    vlTOPp->mkMac__DOT__y___05Fh46381 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46132));
    vlTOPp->mkMac__DOT__y___05Fh46383 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46132));
    vlTOPp->mkMac__DOT__x___05Fh96611 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88404) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__y___05Fh88656 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__x___05Fh46380 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46382) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46383));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1674 
        = ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
              ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
                 ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104960))
              : (IData)(vlTOPp->mkMac__DOT__x___05Fh96611)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
                           ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
                              ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104772))
                           : (IData)(vlTOPp->mkMac__DOT__x___05Fh96423)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1673)));
    vlTOPp->mkMac__DOT__y___05Fh105148 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104960));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96612))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96611));
    vlTOPp->mkMac__DOT__y___05Fh96800 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96612));
    vlTOPp->mkMac__DOT__x___05Fh88653 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xeU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh88656)));
    vlTOPp->mkMac__DOT__y___05Fh46323 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46380) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46381));
    vlTOPp->mkMac__DOT__y___05Fh88596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88653) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__y___05Fh46572 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46323));
    vlTOPp->mkMac__DOT__y___05Fh46574 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46323));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488 
        = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                  >> 0xfU) ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88596)));
    vlTOPp->mkMac__DOT__x___05Fh46571 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46573) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46574));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1656 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1647)
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1502 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105148)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1529 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1501)
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1502 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96800)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)));
    vlTOPp->mkMac__DOT__y___05Fh46514 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46571) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46572));
    vlTOPp->mkMac__DOT__mant_mult___05Fh88782 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1656 
                                                  << 0xeU) 
                                                 | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1674));
    if ((1U & ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
               | vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1529))) {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1623 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1538 
                              >> 7U)) | ((IData)(vlTOPp->mkMac__DOT__x___05Fh93446) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93447)));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1638 
            = vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1634;
    } else {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1623 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535 
                              >> 7U)) | (IData)(vlTOPp->mkMac__DOT__x___05Fh93446));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1638 
            = (((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
                << 6U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                           << 5U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
                                      << 4U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                                                 << 3U) 
                                                | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
                                                    << 2U) 
                                                   | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1535)))))));
    }
    vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh93622 
        = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1529 
            << 0xfU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677) 
                         << 0xeU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679) 
                                      << 0xdU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681) 
                                                   << 0xcU) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683) 
                                                      << 0xbU) 
                                                     | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685) 
                                                         << 0xaU) 
                                                        | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1687) 
                                                            << 9U) 
                                                           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1689) 
                                                               << 8U) 
                                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1699)))))))));
    vlTOPp->mkMac__DOT__mant_mult___05Fh100350 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1529 
                                                   << 0xeU) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677) 
                                                      << 0xdU) 
                                                     | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679) 
                                                         << 0xcU) 
                                                        | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681) 
                                                            << 0xbU) 
                                                           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683) 
                                                               << 0xaU) 
                                                              | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685) 
                                                                  << 9U) 
                                                                 | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1687) 
                                                                     << 8U) 
                                                                    | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1689) 
                                                                        << 7U) 
                                                                       | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1691) 
                                                                           << 6U) 
                                                                          | (0x3fU 
                                                                             & (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                                                >> 1U)))))))))));
    vlTOPp->mkMac__DOT__product___05Fh8491 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46513) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46514)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46322) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46323)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d655))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh93624 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1529)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh100350
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh93622);
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
        = ((0x20U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh8491
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567);
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05Fq12 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh88782
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh93624);
    vlTOPp->mkMac__DOT__x___05Fh50879 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh51070 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh50497 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh50688 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh50115 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50306 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh51130 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh49733 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh49924 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh49542 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh50939 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh50748 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh50557 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh50366 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50175 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh49984 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh49793 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh49543 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 6U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__product___05Fh61772 = (((IData)(vlTOPp->mkMac__DOT__result_sign___05Fh61773) 
                                                << 0x1fU) 
                                               | ((0x40000000U 
                                                   & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1623 
                                                      << 0x1eU)) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1638) 
                                                      << 0x17U) 
                                                     | (0x7f0000U 
                                                        & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05Fq12 
                                                           << 9U)))));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d734 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49542) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49543)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657) 
                                ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659))));
    vlTOPp->mkMac__DOT__y___05Fh49792 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49543));
    vlTOPp->mkMac__DOT__y___05Fh49794 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49543));
    vlTOPp->mkMac__DOT__x___05Fh49791 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49793) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49794));
    vlTOPp->mkMac__DOT__y___05Fh49734 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49791) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49792));
    vlTOPp->mkMac__DOT__y___05Fh49983 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49734));
    vlTOPp->mkMac__DOT__y___05Fh49985 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49734));
    vlTOPp->mkMac__DOT__x___05Fh49982 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49984) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49985));
    vlTOPp->mkMac__DOT__y___05Fh49925 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49982) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49983));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d735 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49924) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49925)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49733) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49734)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d734)));
    vlTOPp->mkMac__DOT__y___05Fh50174 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49925));
    vlTOPp->mkMac__DOT__y___05Fh50176 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49925));
    vlTOPp->mkMac__DOT__x___05Fh50173 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50175) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50176));
    vlTOPp->mkMac__DOT__y___05Fh50116 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50173) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50174));
    vlTOPp->mkMac__DOT__y___05Fh50365 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50116));
    vlTOPp->mkMac__DOT__y___05Fh50367 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50116));
    vlTOPp->mkMac__DOT__x___05Fh50364 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50366) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50367));
    vlTOPp->mkMac__DOT__y___05Fh50307 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50364) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50365));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d736 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50306) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50307)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50115) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50116)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d735)));
    vlTOPp->mkMac__DOT__y___05Fh50556 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50307));
    vlTOPp->mkMac__DOT__y___05Fh50558 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50307));
    vlTOPp->mkMac__DOT__x___05Fh50555 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50557) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50558));
    vlTOPp->mkMac__DOT__y___05Fh50498 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50555) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50556));
    vlTOPp->mkMac__DOT__y___05Fh50747 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50498));
    vlTOPp->mkMac__DOT__y___05Fh50749 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50498));
    vlTOPp->mkMac__DOT__x___05Fh50746 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50748) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50749));
    vlTOPp->mkMac__DOT__y___05Fh50689 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50746) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50747));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d737 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50688) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50689)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50497) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50498)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d736)));
    vlTOPp->mkMac__DOT__y___05Fh50938 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50689));
    vlTOPp->mkMac__DOT__y___05Fh50940 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50689));
    vlTOPp->mkMac__DOT__x___05Fh50937 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50939) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50940));
    vlTOPp->mkMac__DOT__y___05Fh50880 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50937) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50938));
    vlTOPp->mkMac__DOT__y___05Fh51129 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50880));
    vlTOPp->mkMac__DOT__y___05Fh51131 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50880));
    vlTOPp->mkMac__DOT__x___05Fh51128 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51130) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51131));
    vlTOPp->mkMac__DOT__y___05Fh51071 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51128) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51129));
    vlTOPp->mkMac__DOT__product___05Fh6404 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh51070) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh51071)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50879) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50880)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d737))));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh6404
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657);
    vlTOPp->mkMac__DOT__x___05Fh55436 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh55627 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh55054 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55245 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55687 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh54672 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh54863 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh54290 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh54481 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh55496 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55305 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55114 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh54923 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh54732 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh54541 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh54291 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 7U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh54540 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54291));
    vlTOPp->mkMac__DOT__y___05Fh54542 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54291));
    vlTOPp->mkMac__DOT__x___05Fh54539 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54541) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54542));
    vlTOPp->mkMac__DOT__y___05Fh54482 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54539) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54540));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d808 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54481) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54482)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54290) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54291)) 
                       << 8U) | ((0x80U & ((0xffffff80U 
                                            & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739) 
                                           ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                              << 7U))) 
                                 | ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741)))));
    vlTOPp->mkMac__DOT__y___05Fh54731 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54482));
    vlTOPp->mkMac__DOT__y___05Fh54733 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54482));
    vlTOPp->mkMac__DOT__x___05Fh54730 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54732) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54733));
    vlTOPp->mkMac__DOT__y___05Fh54673 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54730) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54731));
    vlTOPp->mkMac__DOT__y___05Fh54922 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54673));
    vlTOPp->mkMac__DOT__y___05Fh54924 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh54673));
    vlTOPp->mkMac__DOT__x___05Fh54921 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54923) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54924));
    vlTOPp->mkMac__DOT__y___05Fh54864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54921) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54922));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d809 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54863) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54864)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54672) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54673)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d808)));
    vlTOPp->mkMac__DOT__y___05Fh55113 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54864));
    vlTOPp->mkMac__DOT__y___05Fh55115 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh54864));
    vlTOPp->mkMac__DOT__x___05Fh55112 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55114) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55115));
    vlTOPp->mkMac__DOT__y___05Fh55055 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55112) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55113));
    vlTOPp->mkMac__DOT__y___05Fh55304 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55055));
    vlTOPp->mkMac__DOT__y___05Fh55306 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55055));
    vlTOPp->mkMac__DOT__x___05Fh55303 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55305) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55306));
    vlTOPp->mkMac__DOT__y___05Fh55246 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55303) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55304));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d810 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55245) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55246)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55054) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55055)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d809)));
    vlTOPp->mkMac__DOT__y___05Fh55495 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55246));
    vlTOPp->mkMac__DOT__y___05Fh55497 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55246));
    vlTOPp->mkMac__DOT__x___05Fh55494 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55496) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55497));
    vlTOPp->mkMac__DOT__y___05Fh55437 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55494) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55495));
    vlTOPp->mkMac__DOT__y___05Fh55686 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55437));
    vlTOPp->mkMac__DOT__y___05Fh55688 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55437));
    vlTOPp->mkMac__DOT__x___05Fh55685 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55687) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55688));
    vlTOPp->mkMac__DOT__y___05Fh55628 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55685) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55686));
    vlTOPp->mkMac__DOT__product___05Fh4317 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55627) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55628)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55436) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55437)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d810))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688 
        = ((0x80U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh4317
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739);
    vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
        = (~ vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688);
    vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1688_BIT_0_THEN_1_ELSE_0___05Fq11 
        = ((1U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh56056 = (1U & ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9));
    vlTOPp->mkMac__DOT__y___05Fh56247 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56056));
    vlTOPp->mkMac__DOT__y___05Fh56438 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56247));
    vlTOPp->mkMac__DOT__y___05Fh56629 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56438));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d912 
        = ((0x20U & ((0xffffffe0U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                     ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56629) 
                        << 5U))) | ((0x10U & ((0xfffffff0U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56438) 
                                                 << 4U))) 
                                    | ((8U & ((0xfffffff8U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56247) 
                                                 << 3U))) 
                                       | ((4U & ((0xfffffffcU 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh56056) 
                                                  << 2U))) 
                                          | ((2U & 
                                              ((0xfffffffeU 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ (vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                                  << 1U))) 
                                             | (1U 
                                                & vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1688_BIT_0_THEN_1_ELSE_0___05Fq11))))));
    vlTOPp->mkMac__DOT__y___05Fh56820 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56629));
    vlTOPp->mkMac__DOT__y___05Fh57011 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56820));
    vlTOPp->mkMac__DOT__y___05Fh57202 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57011));
    vlTOPp->mkMac__DOT__y___05Fh57393 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57202));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d914 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57393) 
                         << 9U))) | ((0x100U & ((0xffffff00U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57202) 
                                                   << 8U))) 
                                     | ((0x80U & ((0xffffff80U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57011) 
                                                   << 7U))) 
                                        | ((0x40U & 
                                            ((0xffffffc0U 
                                              & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56820) 
                                                << 6U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d912)))));
    vlTOPp->mkMac__DOT__y___05Fh57584 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57393));
    vlTOPp->mkMac__DOT__y___05Fh57775 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57584));
    vlTOPp->mkMac__DOT__y___05Fh57966 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57775));
    vlTOPp->mkMac__DOT__y___05Fh58157 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57966));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d916 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58157) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57966) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57775) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57584) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d914)))));
    vlTOPp->mkMac__DOT__y___05Fh58348 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58157));
    vlTOPp->mkMac__DOT__y___05Fh58539 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58348));
    vlTOPp->mkMac__DOT__y___05Fh58730 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xfU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58539));
    vlTOPp->mkMac__DOT__y___05Fh58921 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x10U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58730));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d918 
        = ((0x20000U & ((0xfffe0000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58921) 
                           << 0x11U))) | ((0x10000U 
                                           & ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58730) 
                                                 << 0x10U))) 
                                          | ((0x8000U 
                                              & ((0xffff8000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh58539) 
                                                  << 0xfU))) 
                                             | ((0x4000U 
                                                 & ((0xffffc000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh58348) 
                                                     << 0xeU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d916)))));
    vlTOPp->mkMac__DOT__y___05Fh59112 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x11U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58921));
    vlTOPp->mkMac__DOT__y___05Fh59303 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x12U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59112));
    vlTOPp->mkMac__DOT__y___05Fh59494 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x13U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59303));
    vlTOPp->mkMac__DOT__y___05Fh59685 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x14U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59494));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d920 
        = ((0x200000U & ((0xffe00000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59685) 
                            << 0x15U))) | ((0x100000U 
                                            & ((0xfff00000U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59494) 
                                                  << 0x14U))) 
                                           | ((0x80000U 
                                               & ((0xfff80000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh59303) 
                                                   << 0x13U))) 
                                              | ((0x40000U 
                                                  & ((0xfffc0000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh59112) 
                                                      << 0x12U))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d918))));
    vlTOPp->mkMac__DOT__y___05Fh59876 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x15U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59685));
    vlTOPp->mkMac__DOT__y___05Fh60067 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x16U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59876));
    vlTOPp->mkMac__DOT__y___05Fh60258 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x17U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60067));
    vlTOPp->mkMac__DOT__y___05Fh60449 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x18U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60258));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d922 
        = ((0x2000000U & ((0xfe000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60449) 
                             << 0x19U))) | ((0x1000000U 
                                             & ((0xff000000U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60258) 
                                                   << 0x18U))) 
                                            | ((0x800000U 
                                                & ((0xff800000U 
                                                    & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh60067) 
                                                    << 0x17U))) 
                                               | ((0x400000U 
                                                   & ((0xffc00000U 
                                                       & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh59876) 
                                                       << 0x16U))) 
                                                  | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d920))));
    vlTOPp->mkMac__DOT__y___05Fh60640 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x19U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60449));
    vlTOPp->mkMac__DOT__y___05Fh60831 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1aU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60640));
    vlTOPp->mkMac__DOT__y___05Fh61022 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1bU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60831));
    vlTOPp->mkMac__DOT__y___05Fh61213 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1cU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61022));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d924 
        = ((0x20000000U & ((0xe0000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh61213) 
                              << 0x1dU))) | ((0x10000000U 
                                              & ((0xf0000000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh61022) 
                                                  << 0x1cU))) 
                                             | ((0x8000000U 
                                                 & ((0xf8000000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh60831) 
                                                     << 0x1bU))) 
                                                | ((0x4000000U 
                                                    & ((0xfc000000U 
                                                        & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh60640) 
                                                        << 0x1aU))) 
                                                   | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d922))));
    vlTOPp->mkMac__DOT__y___05Fh61404 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1dU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61213));
    vlTOPp->mkMac__DOT__y___05Fh61595 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1eU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61404));
    vlTOPp->mkMac__DOT__product___05Fh1806 = ((0x80000000U 
                                               & ((0x80000000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh61595) 
                                                   << 0x1fU))) 
                                              | ((0x40000000U 
                                                  & ((0xc0000000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh61404) 
                                                      << 0x1eU))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d924));
    vlTOPp->mkMac__DOT__product___05Fh1681 = ((IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26)
                                               ? vlTOPp->mkMac__DOT__product___05Fh1806
                                               : vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688);
    vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(((1U & (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv))
                                              ? vlTOPp->mkMac__DOT__product___05Fh1681
                                              : vlTOPp->mkMac__DOT__product___05Fh61772))));
}

VL_INLINE_OPT void Vtop::_combo__TOP__5(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__5\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__cdummy_EN = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__cdummy_D_IN = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__tcs_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_s1_or_s2) ? (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv_port1___05Fwrite_1)
            : (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv));
    vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread 
        = ((IData)(vlTOPp->EN_out_result) ? vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1
            : vlTOPp->mkMac__DOT__result_ofifo_rv);
    vlTOPp->mkMac__DOT__tcs_ififo_rv_D_IN = vlTOPp->mkMac__DOT__tcs_ififo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage 
        = (1U & (((((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                    >> 1U) & (IData)((vlTOPp->mkMac__DOT__product_ofifo_rv 
                                      >> 0x20U))) & (IData)(
                                                            (vlTOPp->mkMac__DOT__c_ififo_rv 
                                                             >> 0x20U))) 
                 & (~ (IData)((vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread 
                               >> 0x20U)))));
    vlTOPp->mkMac__DOT__WILL_FIRE_RL_rl_adder_stage 
        = vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage;
    if (vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage) {
        vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fwrite_1;
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv;
        vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread;
    }
    vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage = 
        (1U & (((((vlTOPp->mkMac__DOT__a_ififo_rv & vlTOPp->mkMac__DOT__b_ififo_rv) 
                  >> 0x10U) & ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                               >> 1U)) & (~ (IData)(
                                                    (vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
                                                     >> 0x20U)))) 
               & (~ (IData)((vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
                             >> 0x20U)))));
    vlTOPp->mkMac__DOT__result_ofifo_rv_D_IN = vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__WILL_FIRE_RL_rl_mult_stage 
        = vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage;
    if (vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage) {
        vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fwrite_1;
        vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fwrite_1;
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread;
        vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv;
        vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__b_ififo_rv;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread;
    }
    vlTOPp->mkMac__DOT__c_ififo_rv_D_IN = vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__CAN_FIRE_get_A = (1U & (~ (vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
                                                   >> 0x10U)));
    vlTOPp->mkMac__DOT__RDY_get_A = (1U & (~ (vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
                                              >> 0x10U)));
    vlTOPp->mkMac__DOT__a_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_get_A) ? vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fwrite_1
            : vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread);
    vlTOPp->mkMac__DOT__CAN_FIRE_get_B = (1U & (~ (vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
                                                   >> 0x10U)));
    vlTOPp->mkMac__DOT__RDY_get_B = (1U & (~ (vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
                                              >> 0x10U)));
    vlTOPp->mkMac__DOT__b_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_get_B) ? vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fwrite_1
            : vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread);
    vlTOPp->mkMac__DOT__product_ofifo_rv_D_IN = vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread;
    vlTOPp->RDY_get_A = vlTOPp->mkMac__DOT__RDY_get_A;
    vlTOPp->mkMac__DOT__a_ififo_rv_D_IN = vlTOPp->mkMac__DOT__a_ififo_rv_port2___05Fread;
    vlTOPp->RDY_get_B = vlTOPp->mkMac__DOT__RDY_get_B;
    vlTOPp->mkMac__DOT__b_ififo_rv_D_IN = vlTOPp->mkMac__DOT__b_ififo_rv_port2___05Fread;
}

void Vtop::_eval(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_combo__TOP__2(vlSymsp);
    if (((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK)))) {
        vlTOPp->_sequent__TOP__4(vlSymsp);
    }
    vlTOPp->_combo__TOP__5(vlSymsp);
    // Final
    vlTOPp->__Vclklast__TOP__CLK = vlTOPp->CLK;
}

VL_INLINE_OPT QData Vtop::_change_request(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vtop::_change_request_1(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request_1\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vtop::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((CLK & 0xfeU))) {
        Verilated::overWidthError("CLK");}
    if (VL_UNLIKELY((RST_N & 0xfeU))) {
        Verilated::overWidthError("RST_N");}
    if (VL_UNLIKELY((EN_get_A & 0xfeU))) {
        Verilated::overWidthError("EN_get_A");}
    if (VL_UNLIKELY((EN_get_B & 0xfeU))) {
        Verilated::overWidthError("EN_get_B");}
    if (VL_UNLIKELY((EN_get_C & 0xfeU))) {
        Verilated::overWidthError("EN_get_C");}
    if (VL_UNLIKELY((s1_or_s2_tcs & 0xfeU))) {
        Verilated::overWidthError("s1_or_s2_tcs");}
    if (VL_UNLIKELY((EN_s1_or_s2 & 0xfeU))) {
        Verilated::overWidthError("EN_s1_or_s2");}
    if (VL_UNLIKELY((EN_out_result & 0xfeU))) {
        Verilated::overWidthError("EN_out_result");}
}
#endif  // VL_DEBUG
