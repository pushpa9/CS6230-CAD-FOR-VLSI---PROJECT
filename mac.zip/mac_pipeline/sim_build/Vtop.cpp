// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop.h"
#include "Vtop__Syms.h"

#include "verilated_dpi.h"

//==========

void Vtop::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vtop::eval\n"); );
    Vtop__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac_pipeline/verilog/mkMac.v", 46, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vtop::_eval_initial_loop(Vtop__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/shakti/bluespec_demo_examples/mac_pipeline/verilog/mkMac.v", 46, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vtop::_combo__TOP__2(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__2\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__CLK = vlTOPp->CLK;
    vlTOPp->mkMac__DOT__RST_N = vlTOPp->RST_N;
    vlTOPp->mkMac__DOT__get_A_x = vlTOPp->get_A_x;
    vlTOPp->mkMac__DOT__EN_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__get_B_y = vlTOPp->get_B_y;
    vlTOPp->mkMac__DOT__EN_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__get_C_z = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__EN_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__s1_or_s2_tcs = vlTOPp->s1_or_s2_tcs;
    vlTOPp->mkMac__DOT__EN_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__EN_out_result = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_A = vlTOPp->EN_get_A;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_B = vlTOPp->EN_get_B;
    vlTOPp->mkMac__DOT__WILL_FIRE_get_C = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__WILL_FIRE_s1_or_s2 = vlTOPp->EN_s1_or_s2;
    vlTOPp->mkMac__DOT__WILL_FIRE_out_result = vlTOPp->EN_out_result;
    vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fwrite_1 
        = (0x10000U | (IData)(vlTOPp->get_A_x));
    vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fwrite_1 
        = (0x10000U | (IData)(vlTOPp->get_B_y));
    vlTOPp->mkMac__DOT__tcs_ififo_rv_port1___05Fwrite_1 
        = (2U | (IData)(vlTOPp->s1_or_s2_tcs));
}

VL_INLINE_OPT void Vtop::_sequent__TOP__4(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_sequent__TOP__4\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__cdummy_EN) {
            vlTOPp->mkMac__DOT__cdummy = vlTOPp->mkMac__DOT__cdummy_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__cdummy = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__tcs_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__tcs_ififo_rv = vlTOPp->mkMac__DOT__tcs_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__tcs_ififo_rv = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__result_ofifo_rv_EN) {
            vlTOPp->mkMac__DOT__result_ofifo_rv = vlTOPp->mkMac__DOT__result_ofifo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__result_ofifo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__product_ofifo_rv_EN) {
            vlTOPp->mkMac__DOT__product_ofifo_rv = vlTOPp->mkMac__DOT__product_ofifo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__product_ofifo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__c_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__c_ififo_rv = vlTOPp->mkMac__DOT__c_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv = 0ULL;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__b_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__b_ififo_rv = vlTOPp->mkMac__DOT__b_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__b_ififo_rv = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkMac__DOT__a_ififo_rv_EN) {
            vlTOPp->mkMac__DOT__a_ififo_rv = vlTOPp->mkMac__DOT__a_ififo_rv_D_IN;
        }
    } else {
        vlTOPp->mkMac__DOT__a_ififo_rv = 0U;
    }
    vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(vlTOPp->mkMac__DOT__cdummy)));
    vlTOPp->mkMac__DOT__CAN_FIRE_s1_or_s2 = (1U & (~ 
                                                   ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                                                    >> 1U)));
    vlTOPp->mkMac__DOT__RDY_s1_or_s2 = (1U & (~ ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                                                 >> 1U)));
    vlTOPp->mkMac__DOT__CAN_FIRE_out_result = (1U & (IData)(
                                                            (vlTOPp->mkMac__DOT__result_ofifo_rv 
                                                             >> 0x20U)));
    vlTOPp->mkMac__DOT__out_result = (IData)(vlTOPp->mkMac__DOT__result_ofifo_rv);
    vlTOPp->mkMac__DOT__RDY_out_result = (1U & (IData)(
                                                       (vlTOPp->mkMac__DOT__result_ofifo_rv 
                                                        >> 0x20U)));
    vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
        = (IData)(vlTOPp->mkMac__DOT__product_ofifo_rv);
    vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
        = (IData)(vlTOPp->mkMac__DOT__c_ififo_rv);
    vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2 
        = (0xffffU & vlTOPp->mkMac__DOT__b_ififo_rv);
    vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1 
        = (0xffffU & vlTOPp->mkMac__DOT__a_ififo_rv);
    vlTOPp->RDY_s1_or_s2 = vlTOPp->mkMac__DOT__RDY_s1_or_s2;
    vlTOPp->out_result = vlTOPp->mkMac__DOT__out_result;
    vlTOPp->RDY_out_result = vlTOPp->mkMac__DOT__RDY_out_result;
    vlTOPp->mkMac__DOT__mant_x___05Fh109213 = (0x40000000U 
                                               | (0x3fffff80U 
                                                  & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                     << 7U)));
    vlTOPp->mkMac__DOT__exp_x___05Fh109211 = (0xffU 
                                              & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh108833 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh109027 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh108445 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh108639 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh109088 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh108057 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh108251 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh107669 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh107863 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh107281 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh107475 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh106893 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh107087 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh108894 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh106505 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh106699 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh106117 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh106311 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh105729 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh105923 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh105341 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh105535 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh108700 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh104953 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh105147 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh104565 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh104759 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh104177 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh104371 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh108506 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh103789 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh103983 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh103401 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh103595 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_BITS_31_TO_0_BIT_0_XOR_c_i_ETC___05Fq17 
        = ((1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                  ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh103205 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 ^ vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh108312 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh108118 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh107924 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh107730 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2018 
        = ((1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                  >> 0x1fU)) == (1U & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                       >> 0x1fU)));
    vlTOPp->mkMac__DOT__x___05Fh107536 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh107342 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh107148 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh106954 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh106760 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh106566 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh106372 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh106178 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh105984 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh105790 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh105596 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh105402 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh105208 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh105014 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh104820 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh104626 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh104432 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh104238 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh104044 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh103850 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh103656 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh103462 = (1U & ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                 & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh103206 = (1U & (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                                & vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4));
    vlTOPp->mkMac__DOT__mant_y___05Fh109214 = (0x40000000U 
                                               | (0x3fffff80U 
                                                  & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                                     << 7U)));
    vlTOPp->mkMac__DOT__exp_y___05Fh109212 = (0xffU 
                                              & (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                                 >> 0x17U));
    vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7 
        = (0xffU & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2));
    vlTOPp->mkMac__DOT__result_sign___05Fh61773 = (1U 
                                                   & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                                      >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh90723 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh90782 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh90535 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh90347 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh90159 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh90594 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh89971 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh89783 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh90406 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh89595 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26 
        = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                  ^ (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                 >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh90218 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh90030 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh89842 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 8U));
    vlTOPp->mkMac__DOT__y___05Fh89596 = (1U & (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2)) 
                                               >> 7U));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5 
        = (0xffU & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2002 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh103205) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103206)) 
            << 1U) | (1U & vlTOPp->mkMac__DOT__IF_product_ofifo_rv_BITS_31_TO_0_BIT_0_XOR_c_i_ETC___05Fq17));
    vlTOPp->mkMac__DOT__y___05Fh103461 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103206));
    vlTOPp->mkMac__DOT__y___05Fh103463 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103206));
    vlTOPp->mkMac__DOT__x___05Fh109356 = (vlTOPp->mkMac__DOT__exp_y___05Fh109212 
                                          - vlTOPp->mkMac__DOT__exp_x___05Fh109211);
    vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F70_ETC___05F_d2023 
        = (vlTOPp->mkMac__DOT__exp_x___05Fh109211 <= vlTOPp->mkMac__DOT__exp_y___05Fh109212);
    vlTOPp->mkMac__DOT__x___05Fh109403 = (vlTOPp->mkMac__DOT__exp_x___05Fh109211 
                                          - vlTOPp->mkMac__DOT__exp_y___05Fh109212);
    vlTOPp->mkMac__DOT__ext_b___05Fh1687 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq7));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10 
        = ((IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh90956 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89595) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__y___05Fh89841 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__y___05Fh89843 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89596));
    vlTOPp->mkMac__DOT__mant_mult___05Fh65071 = (0x80U 
                                                 | ((0xffff0000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938) 
                                                    | ((0x7eU 
                                                        & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)) 
                                                       | (1U 
                                                          & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d938))));
    vlTOPp->mkMac__DOT__ext_a___05Fh1686 = ((0xffffff00U 
                                             & ((- (IData)(
                                                           (1U 
                                                            & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5) 
                                                               >> 7U)))) 
                                                << 8U)) 
                                            | (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0_BITS_7_TO_0___05Fq5));
    vlTOPp->mkMac__DOT__x___05Fh103460 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103462) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103463));
    vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh109353 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh109356)
            ? (vlTOPp->mkMac__DOT__mant_x___05Fh109213 
               >> vlTOPp->mkMac__DOT__x___05Fh109356)
            : 0U);
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602 
        = (0xffU & ((1U & ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F70_ETC___05F_d2023)) 
                           | (vlTOPp->mkMac__DOT__exp_y___05Fh109212 
                              <= vlTOPp->mkMac__DOT__exp_x___05Fh109211)))
                     ? (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                        >> 0x17U) : (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                     >> 0x17U)));
    vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh109376 
        = ((0x1fU >= vlTOPp->mkMac__DOT__x___05Fh109403)
            ? (vlTOPp->mkMac__DOT__mant_y___05Fh109214 
               >> vlTOPp->mkMac__DOT__x___05Fh109403)
            : 0U);
    vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 = (~ vlTOPp->mkMac__DOT__ext_b___05Fh1687);
    vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh92318 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh90956) 
                                               ^ vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10));
    vlTOPp->mkMac__DOT__y___05Fh91145 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90956) 
                                         & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05Fq10);
    vlTOPp->mkMac__DOT__x___05Fh89840 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89842) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89843));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh65071
            : 0U);
    vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 = (~ vlTOPp->mkMac__DOT__ext_a___05Fh1686);
    vlTOPp->mkMac__DOT__y___05Fh103402 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103460) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103461));
    vlTOPp->mkMac__DOT__mant_x___05Fh109218 = ((1U 
                                                & ((~ (IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F70_ETC___05F_d2023)) 
                                                   | (vlTOPp->mkMac__DOT__exp_y___05Fh109212 
                                                      <= vlTOPp->mkMac__DOT__exp_x___05Fh109211)))
                                                ? vlTOPp->mkMac__DOT__mant_x___05Fh109213
                                                : vlTOPp->mkMac__DOT__mant_x___05F_1___05Fh109353);
    vlTOPp->mkMac__DOT__exp_x___05Fh109216 = vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602;
    vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2605 
        = ((1U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh130510 = (1U & (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                                 >> 1U) 
                                                & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)));
    vlTOPp->mkMac__DOT__mant_y___05Fh109219 = ((IData)(vlTOPp->mkMac__DOT___0b0_CONCAT_IF_product_ofifo_rv_port0___05Fread___05F70_ETC___05F_d2023)
                                                ? vlTOPp->mkMac__DOT__mant_y___05Fh109214
                                                : vlTOPp->mkMac__DOT__mant_y___05F_1___05Fh109376);
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh3182 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                               >> 1U) 
                                              & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8));
    vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1535 
        = ((1U & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh92507 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                                         & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532);
    vlTOPp->mkMac__DOT__y___05Fh89784 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89840) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh89841));
    vlTOPp->mkMac__DOT__x___05Fh69756 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh69374 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh69565 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh68992 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh69183 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh68610 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 2U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh68801 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh69816 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh69625 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh69434 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh69243 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh69052 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh68861 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 2U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh68611 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 1U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73 
        = ((1U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh19879 = (1U & ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6));
    vlTOPp->mkMac__DOT__y___05Fh103655 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103402));
    vlTOPp->mkMac__DOT__y___05Fh103657 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103402));
    vlTOPp->mkMac__DOT__y___05Fh130698 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130510));
    vlTOPp->mkMac__DOT__x___05Fh116136 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh115748 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh115942 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2037 
        = (vlTOPp->mkMac__DOT__mant_x___05Fh109218 
           < vlTOPp->mkMac__DOT__mant_y___05Fh109219);
    vlTOPp->mkMac__DOT__x___05Fh115360 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh115554 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh116197 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh114972 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh115166 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh114584 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh114778 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114196 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh114390 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh116003 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh113808 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh114002 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh113420 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh113614 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh113032 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh113226 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh112644 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh112838 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh115809 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh112256 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh112450 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh111868 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh112062 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh111480 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh111674 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh115615 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh111092 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh111286 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh110704 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh110898 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_mant_x09218_BIT_0_XOR_mant_y09219_BIT_0_THE_ETC___05Fq14 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                  ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219))
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh110316 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh110510 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh115421 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh115227 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh115033 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh114839 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh114645 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh114451 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh114257 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh114063 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh113869 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh113675 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh113481 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh113287 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh113093 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh112899 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh112705 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh112511 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh112317 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh112123 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh111929 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh111735 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh111541 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh111347 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh111153 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh110959 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh110765 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh110571 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__mant_y___05Fh109219) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__y___05Fh110317 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                & vlTOPp->mkMac__DOT__mant_y___05Fh109219));
    vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 = 
        (~ vlTOPp->mkMac__DOT__mant_y___05Fh109219);
    vlTOPp->mkMac__DOT__y___05Fh3373 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3182));
    vlTOPp->mkMac__DOT__x___05Fh91144 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89783) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh90029 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh90031 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh89784));
    vlTOPp->mkMac__DOT__y___05Fh68860 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68611));
    vlTOPp->mkMac__DOT__y___05Fh68862 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68611));
    vlTOPp->mkMac__DOT__y___05Fh20070 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh19879));
    vlTOPp->mkMac__DOT__x___05Fh103654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103656) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103657));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2629 
        = ((8U & ((0xfffffff8U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh130698) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh130510) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2605))));
    vlTOPp->mkMac__DOT__y___05Fh130886 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130698));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109428 
        = (1U & ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2037)
                  ? (vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                     >> 0x1fU) : (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                  >> 0x1fU)));
    vlTOPp->mkMac__DOT__y___05Fh110570 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110317));
    vlTOPp->mkMac__DOT__y___05Fh110572 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110317));
    vlTOPp->mkMac__DOT__x___05Fh122597 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh122791 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh129445 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh129639 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh122985 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh129833 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1fU));
    vlTOPp->mkMac__DOT__x___05Fh122209 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh122403 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh129057 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh129251 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh121821 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh122015 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh128669 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh128863 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh123046 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh129894 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1eU));
    vlTOPp->mkMac__DOT__x___05Fh121433 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121627 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh128281 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128475 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh121045 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh121239 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh127893 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh128087 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh120657 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120851 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh127505 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127699 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh122852 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh129700 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1dU));
    vlTOPp->mkMac__DOT__x___05Fh120269 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120463 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh127117 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127311 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh119881 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh120075 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh126729 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh126923 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh119493 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119687 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh126341 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126535 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh119105 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119299 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh125953 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh126147 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh122658 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh129506 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1cU));
    vlTOPp->mkMac__DOT__x___05Fh118717 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118911 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh125565 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125759 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118329 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118523 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh125177 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125371 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh117941 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh118135 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh124789 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh124983 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh122464 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh129312 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1bU));
    vlTOPp->mkMac__DOT__x___05Fh117553 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117747 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh124401 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124595 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__IF_INV_INV_mant_y092193_BIT_0_XOR_mant_x09218___05FETC___05Fq15 
        = ((1U & (vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                  ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__IF_INV_mant_x09218_BIT_0_XOR_INV_mant_y092193___05FETC___05Fq16 
        = ((1U & (vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                  ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13))
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__x___05Fh117165 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh117359 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 ^ vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh124013 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh124207 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 ^ vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh122270 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh129118 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x1aU));
    vlTOPp->mkMac__DOT__x___05Fh122076 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh128924 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x19U));
    vlTOPp->mkMac__DOT__x___05Fh121882 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh128730 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x18U));
    vlTOPp->mkMac__DOT__x___05Fh121688 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh128536 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x17U));
    vlTOPp->mkMac__DOT__x___05Fh121494 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh128342 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x16U));
    vlTOPp->mkMac__DOT__x___05Fh121300 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh128148 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x15U));
    vlTOPp->mkMac__DOT__x___05Fh121106 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh127954 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x14U));
    vlTOPp->mkMac__DOT__x___05Fh120912 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh127760 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x13U));
    vlTOPp->mkMac__DOT__x___05Fh120718 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh127566 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x12U));
    vlTOPp->mkMac__DOT__x___05Fh120524 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh127372 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x11U));
    vlTOPp->mkMac__DOT__x___05Fh120330 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh127178 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0x10U));
    vlTOPp->mkMac__DOT__x___05Fh120136 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh126984 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xfU));
    vlTOPp->mkMac__DOT__x___05Fh119942 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh126790 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xeU));
    vlTOPp->mkMac__DOT__x___05Fh119748 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh126596 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xdU));
    vlTOPp->mkMac__DOT__x___05Fh119554 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh126402 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xcU));
    vlTOPp->mkMac__DOT__x___05Fh119360 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh126208 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xbU));
    vlTOPp->mkMac__DOT__x___05Fh119166 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh126014 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 0xaU));
    vlTOPp->mkMac__DOT__x___05Fh118972 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh125820 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 9U));
    vlTOPp->mkMac__DOT__x___05Fh118778 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh125626 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 8U));
    vlTOPp->mkMac__DOT__x___05Fh118584 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh125432 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 7U));
    vlTOPp->mkMac__DOT__x___05Fh118390 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh125238 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 6U));
    vlTOPp->mkMac__DOT__x___05Fh118196 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh125044 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 5U));
    vlTOPp->mkMac__DOT__x___05Fh118002 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh124850 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 4U));
    vlTOPp->mkMac__DOT__x___05Fh117808 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh124656 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 3U));
    vlTOPp->mkMac__DOT__x___05Fh117614 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh124462 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 2U));
    vlTOPp->mkMac__DOT__x___05Fh117420 = (1U & ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                 & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh124268 = (1U & ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                 & vlTOPp->mkMac__DOT__mant_x___05Fh109218) 
                                                >> 1U));
    vlTOPp->mkMac__DOT__x___05Fh117226 = (1U & (vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                                & vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13));
    vlTOPp->mkMac__DOT__x___05Fh124074 = (1U & (vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                                & vlTOPp->mkMac__DOT__mant_x___05Fh109218));
    vlTOPp->mkMac__DOT__INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d56 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3373) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3182) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32))));
    vlTOPp->mkMac__DOT__y___05Fh3564 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3373));
    vlTOPp->mkMac__DOT__x___05Fh92506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91144) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91145));
    vlTOPp->mkMac__DOT__y___05Fh91333 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91144) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91145));
    vlTOPp->mkMac__DOT__x___05Fh90028 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90030) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90031));
    vlTOPp->mkMac__DOT__x___05Fh68859 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68861) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68862));
    vlTOPp->mkMac__DOT__INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d97 
        = ((8U & ((0xfffffff8U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                  ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20070) 
                     << 3U))) | ((4U & ((0xfffffffcU 
                                         & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh19879) 
                                           << 2U))) 
                                 | ((2U & ((0xfffffffeU 
                                            & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                           ^ (vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                              << 1U))) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73))));
    vlTOPp->mkMac__DOT__y___05Fh20261 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20070));
    vlTOPp->mkMac__DOT__y___05Fh103596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103654) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103655));
    vlTOPp->mkMac__DOT__y___05Fh131074 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh130886));
    vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109271 
        = (1U & ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2018)
                  ? (vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                     >> 0x1fU) : (IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109428)));
    vlTOPp->mkMac__DOT__x___05Fh110569 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110571) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110572));
    vlTOPp->mkMac__DOT__x___05Fh117224 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh117226) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh109218));
    vlTOPp->mkMac__DOT__x___05Fh124072 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh124074) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13));
    vlTOPp->mkMac__DOT__y___05Fh3755 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3564));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1629 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92507)) 
            << 2U) | ((2U & (((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                              ^ vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532) 
                             << 1U)) | (1U & vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1535)));
    vlTOPp->mkMac__DOT__y___05Fh92695 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92507));
    vlTOPp->mkMac__DOT__y___05Fh89972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90028) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90029));
    vlTOPp->mkMac__DOT__y___05Fh68802 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh68859) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh68860));
    vlTOPp->mkMac__DOT__y___05Fh20452 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20261));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2003 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh103595) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103596)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh103401) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103402)) 
                       << 2U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2002)));
    vlTOPp->mkMac__DOT__y___05Fh103849 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103596));
    vlTOPp->mkMac__DOT__y___05Fh103851 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103596));
    vlTOPp->mkMac__DOT__y___05Fh131262 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131074));
    vlTOPp->mkMac__DOT__y___05Fh110511 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110569) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110570));
    vlTOPp->mkMac__DOT__y___05Fh117166 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh117224) 
                                                | vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13));
    vlTOPp->mkMac__DOT__y___05Fh124014 = (1U & ((IData)(vlTOPp->mkMac__DOT__x___05Fh124072) 
                                                | vlTOPp->mkMac__DOT__mant_x___05Fh109218));
    vlTOPp->mkMac__DOT__y___05Fh3946 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3755));
    vlTOPp->mkMac__DOT__x___05Fh91332 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh89971) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__y___05Fh90217 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__y___05Fh90219 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh89972));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1033 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68801) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68802)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68610) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68611)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946))));
    vlTOPp->mkMac__DOT__y___05Fh69051 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68802));
    vlTOPp->mkMac__DOT__y___05Fh69053 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68802));
    vlTOPp->mkMac__DOT__y___05Fh20643 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20452));
    vlTOPp->mkMac__DOT__x___05Fh103848 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103850) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103851));
    vlTOPp->mkMac__DOT__y___05Fh131450 = (((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602) 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh131262));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2698 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110510) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110511)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110316) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110317)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_mant_x09218_BIT_0_XOR_mant_y09219_BIT_0_THE_ETC___05Fq14)));
    vlTOPp->mkMac__DOT__y___05Fh110764 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110511));
    vlTOPp->mkMac__DOT__y___05Fh110766 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110511));
    vlTOPp->mkMac__DOT__y___05Fh117419 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117166));
    vlTOPp->mkMac__DOT__y___05Fh117421 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117166));
    vlTOPp->mkMac__DOT__y___05Fh124267 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124014));
    vlTOPp->mkMac__DOT__y___05Fh124269 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124014));
    vlTOPp->mkMac__DOT__y___05Fh4137 = ((vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8 
                                         >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh3946));
    vlTOPp->mkMac__DOT__x___05Fh92694 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91332) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91333));
    vlTOPp->mkMac__DOT__y___05Fh91521 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91332) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91333));
    vlTOPp->mkMac__DOT__x___05Fh90216 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90218) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90219));
    vlTOPp->mkMac__DOT__x___05Fh69050 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69052) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69053));
    vlTOPp->mkMac__DOT__y___05Fh20834 = ((vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh20643));
    vlTOPp->mkMac__DOT__y___05Fh103790 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh103848) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh103849));
    vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh130025 
        = ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_p_ETC___05F_d2605) 
           | ((0x80U & ((0xffffff80U & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh131450) 
                           << 7U))) | ((0x40U & ((0xffffffc0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh131262) 
                                                  << 6U))) 
                                       | ((0x20U & 
                                           ((0xffffffe0U 
                                             & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                                            ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh131074) 
                                               << 5U))) 
                                          | ((0x10U 
                                              & ((0xfffffff0U 
                                                  & (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2602)) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh130886) 
                                                  << 4U))) 
                                             | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2629))))));
    vlTOPp->mkMac__DOT__x___05Fh110763 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110765) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110766));
    vlTOPp->mkMac__DOT__x___05Fh117418 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117420) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117421));
    vlTOPp->mkMac__DOT__x___05Fh124266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124268) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124269));
    vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2692 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT___05FETC___05F_d32) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh4137) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3946) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh3755) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_b687___05Fq8) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh3564) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d56))))));
    vlTOPp->mkMac__DOT__y___05Fh92883 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92695));
    vlTOPp->mkMac__DOT__y___05Fh90160 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90216) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90217));
    vlTOPp->mkMac__DOT__y___05Fh68993 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69050) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69051));
    vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19389 = 
        ((0xffffff00U & vlTOPp->mkMac__DOT__IF_INV_INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT___05FETC___05F_d73) 
         | ((0x80U & ((0xffffff80U & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20834) 
                         << 7U))) | ((0x40U & ((0xffffffc0U 
                                                & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20643) 
                                                  << 6U))) 
                                     | ((0x20U & ((0xffffffe0U 
                                                   & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh20452) 
                                                   << 5U))) 
                                        | ((0x10U & 
                                            ((0xfffffff0U 
                                              & vlTOPp->mkMac__DOT__INV_ext_a686___05Fq6) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh20261) 
                                                << 4U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_SEXT_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d97))))));
    vlTOPp->mkMac__DOT__y___05Fh104043 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103790));
    vlTOPp->mkMac__DOT__y___05Fh104045 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103790));
    vlTOPp->mkMac__DOT__y___05Fh110705 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110763) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110764));
    vlTOPp->mkMac__DOT__y___05Fh117360 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117418) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117419));
    vlTOPp->mkMac__DOT__y___05Fh124208 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124266) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124267));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__ext_b___05F_1___05Fh2692
            : vlTOPp->mkMac__DOT__ext_b___05Fh1687);
    vlTOPp->mkMac__DOT__x___05Fh91520 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90159) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh90405 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh90407 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90160));
    vlTOPp->mkMac__DOT__y___05Fh69242 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68993));
    vlTOPp->mkMac__DOT__y___05Fh69244 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh68993));
    vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
        = ((0x80U & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1))
            ? vlTOPp->mkMac__DOT__ext_a___05F_1___05Fh19389
            : vlTOPp->mkMac__DOT__ext_a___05Fh1686);
    vlTOPp->mkMac__DOT__x___05Fh104042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104044) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104045));
    vlTOPp->mkMac__DOT__y___05Fh110958 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110705));
    vlTOPp->mkMac__DOT__y___05Fh110960 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110705));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2856 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117359) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117360)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117165) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117166)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_mant_x09218_BIT_0_XOR_INV_mant_y092193___05FETC___05Fq16)));
    vlTOPp->mkMac__DOT__y___05Fh117613 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117360));
    vlTOPp->mkMac__DOT__y___05Fh117615 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117360));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2777 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124207) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124208)) 
            << 2U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124013) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124014)) 
                       << 1U) | (1U & vlTOPp->mkMac__DOT__IF_INV_INV_mant_y092193_BIT_0_XOR_mant_x09218___05FETC___05Fq15)));
    vlTOPp->mkMac__DOT__y___05Fh124461 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124208));
    vlTOPp->mkMac__DOT__y___05Fh124463 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124208));
    vlTOPp->mkMac__DOT__x___05Fh92882 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91520) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91521));
    vlTOPp->mkMac__DOT__y___05Fh91709 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91520) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91521));
    vlTOPp->mkMac__DOT__x___05Fh90404 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90406) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90407));
    vlTOPp->mkMac__DOT__x___05Fh69241 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69243) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69244));
    vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__y___05Fh103984 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104042) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104043));
    vlTOPp->mkMac__DOT__x___05Fh110957 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110959) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110960));
    vlTOPp->mkMac__DOT__x___05Fh117612 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117614) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117615));
    vlTOPp->mkMac__DOT__x___05Fh124460 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124462) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124463));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1630 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92883)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92695)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1629)));
    vlTOPp->mkMac__DOT__y___05Fh93071 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh92883));
    vlTOPp->mkMac__DOT__y___05Fh90348 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90404) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90405));
    vlTOPp->mkMac__DOT__y___05Fh69184 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69241) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69242));
    vlTOPp->mkMac__DOT__product___05Fh18926 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102) 
                                               | ((0xfffeU 
                                                   & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100) 
                                                  | (1U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a___05FETC___05F_d102)));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2004 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh103983) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103984)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh103789) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh103790)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2003)));
    vlTOPp->mkMac__DOT__y___05Fh104237 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103984));
    vlTOPp->mkMac__DOT__y___05Fh104239 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh103984));
    vlTOPp->mkMac__DOT__y___05Fh110899 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh110957) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh110958));
    vlTOPp->mkMac__DOT__y___05Fh117554 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117612) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117613));
    vlTOPp->mkMac__DOT__y___05Fh124402 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124460) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124461));
    vlTOPp->mkMac__DOT__x___05Fh91708 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90347) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__y___05Fh90593 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__y___05Fh90595 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90348));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1034 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69183) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69184)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh68992) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh68993)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1033)));
    vlTOPp->mkMac__DOT__y___05Fh69433 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69184));
    vlTOPp->mkMac__DOT__y___05Fh69435 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69184));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh18926
            : 0U);
    vlTOPp->mkMac__DOT__x___05Fh104236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104238) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104239));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2699 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110898) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110899)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh110704) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh110705)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2698)));
    vlTOPp->mkMac__DOT__y___05Fh111152 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110899));
    vlTOPp->mkMac__DOT__y___05Fh111154 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh110899));
    vlTOPp->mkMac__DOT__y___05Fh117807 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117554));
    vlTOPp->mkMac__DOT__y___05Fh117809 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117554));
    vlTOPp->mkMac__DOT__y___05Fh124655 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124402));
    vlTOPp->mkMac__DOT__y___05Fh124657 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124402));
    vlTOPp->mkMac__DOT__x___05Fh93070 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91708) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91709));
    vlTOPp->mkMac__DOT__y___05Fh91897 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91708) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91709));
    vlTOPp->mkMac__DOT__x___05Fh90592 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90594) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90595));
    vlTOPp->mkMac__DOT__x___05Fh69432 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69434) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69435));
    vlTOPp->mkMac__DOT__x___05Fh28094 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh28285 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__x___05Fh27712 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh27903 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh27330 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27521 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh28345 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh26948 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27139 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh26566 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26757 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh26184 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26375 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh28154 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh25802 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 2U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh25993 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh27963 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh27772 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh27581 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh27390 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh27199 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh27008 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh26817 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh26626 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh26435 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh26244 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh26053 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 2U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh25803 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh104178 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104236) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104237));
    vlTOPp->mkMac__DOT__x___05Fh111151 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111153) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111154));
    vlTOPp->mkMac__DOT__x___05Fh117806 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117808) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117809));
    vlTOPp->mkMac__DOT__x___05Fh124654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124656) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124657));
    vlTOPp->mkMac__DOT__y___05Fh93259 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh93071));
    vlTOPp->mkMac__DOT__y___05Fh90536 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90592) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90593));
    vlTOPp->mkMac__DOT__y___05Fh69375 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69432) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69433));
    vlTOPp->mkMac__DOT__y___05Fh26052 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25803));
    vlTOPp->mkMac__DOT__y___05Fh26054 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25803));
    vlTOPp->mkMac__DOT__y___05Fh104431 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104178));
    vlTOPp->mkMac__DOT__y___05Fh104433 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104178));
    vlTOPp->mkMac__DOT__y___05Fh111093 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111151) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111152));
    vlTOPp->mkMac__DOT__y___05Fh117748 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh117806) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh117807));
    vlTOPp->mkMac__DOT__y___05Fh124596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124654) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124655));
    vlTOPp->mkMac__DOT__y___05Fh90781 = (((IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__x___05Fh91896 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90535) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__y___05Fh90783 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh90536));
    vlTOPp->mkMac__DOT__y___05Fh69624 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69375));
    vlTOPp->mkMac__DOT__y___05Fh69626 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69375));
    vlTOPp->mkMac__DOT__x___05Fh26051 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26053) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26054));
    vlTOPp->mkMac__DOT__x___05Fh104430 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104432) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104433));
    vlTOPp->mkMac__DOT__y___05Fh111346 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111093));
    vlTOPp->mkMac__DOT__y___05Fh111348 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111093));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2857 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117747) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117748)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117553) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117554)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2856)));
    vlTOPp->mkMac__DOT__y___05Fh118001 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117748));
    vlTOPp->mkMac__DOT__y___05Fh118003 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117748));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2778 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124595) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124596)) 
            << 4U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124401) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124402)) 
                       << 3U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2777)));
    vlTOPp->mkMac__DOT__y___05Fh124849 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124596));
    vlTOPp->mkMac__DOT__y___05Fh124851 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124596));
    vlTOPp->mkMac__DOT__y___05Fh92085 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91896) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh91897));
    vlTOPp->mkMac__DOT__x___05Fh93258 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh91896) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh91897));
    vlTOPp->mkMac__DOT__x___05Fh90780 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90782) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90783));
    vlTOPp->mkMac__DOT__x___05Fh69623 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69625) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69626));
    vlTOPp->mkMac__DOT__y___05Fh25994 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26051) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26052));
    vlTOPp->mkMac__DOT__y___05Fh104372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104430) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104431));
    vlTOPp->mkMac__DOT__x___05Fh111345 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111347) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111348));
    vlTOPp->mkMac__DOT__x___05Fh118000 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118002) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118003));
    vlTOPp->mkMac__DOT__x___05Fh124848 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124850) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124851));
    vlTOPp->mkMac__DOT__y___05Fh93447 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh93259));
    vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1631 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93259)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93071)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1630)));
    vlTOPp->mkMac__DOT__y___05Fh90724 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh90780) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh90781));
    vlTOPp->mkMac__DOT__y___05Fh69566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69623) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69624));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d238 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh25993) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh25994)) 
            << 3U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh25802) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh25803)) 
                       << 2U) | ((2U & ((0xfffffffeU 
                                         & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108) 
                                        ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                           << 1U))) 
                                 | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110))));
    vlTOPp->mkMac__DOT__y___05Fh26243 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25994));
    vlTOPp->mkMac__DOT__y___05Fh26245 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh25994));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2005 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh104371) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104372)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh104177) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104178)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2004)));
    vlTOPp->mkMac__DOT__y___05Fh104625 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104372));
    vlTOPp->mkMac__DOT__y___05Fh104627 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104372));
    vlTOPp->mkMac__DOT__y___05Fh111287 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111345) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111346));
    vlTOPp->mkMac__DOT__y___05Fh117942 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118000) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118001));
    vlTOPp->mkMac__DOT__y___05Fh124790 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh124848) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh124849));
    vlTOPp->mkMac__DOT__x___05Fh92084 = (1U & (~ ((IData)(vlTOPp->mkMac__DOT__x___05Fh90723) 
                                                  ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh90724))));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1035 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69565) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69566)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69374) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh69375)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1034)));
    vlTOPp->mkMac__DOT__y___05Fh69815 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69566));
    vlTOPp->mkMac__DOT__y___05Fh69817 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69566));
    vlTOPp->mkMac__DOT__x___05Fh26242 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26244) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26245));
    vlTOPp->mkMac__DOT__x___05Fh104624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104626) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104627));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2700 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111286) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111287)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111092) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111093)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2699)));
    vlTOPp->mkMac__DOT__y___05Fh111540 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111287));
    vlTOPp->mkMac__DOT__y___05Fh111542 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111287));
    vlTOPp->mkMac__DOT__y___05Fh118195 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117942));
    vlTOPp->mkMac__DOT__y___05Fh118197 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh117942));
    vlTOPp->mkMac__DOT__y___05Fh125043 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124790));
    vlTOPp->mkMac__DOT__y___05Fh125045 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124790));
    vlTOPp->mkMac__DOT__x___05Fh93446 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh92084) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh92085));
    vlTOPp->mkMac__DOT__x___05Fh69814 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69816) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69817));
    vlTOPp->mkMac__DOT__y___05Fh26185 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26242) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26243));
    vlTOPp->mkMac__DOT__y___05Fh104566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104624) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104625));
    vlTOPp->mkMac__DOT__x___05Fh111539 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111541) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111542));
    vlTOPp->mkMac__DOT__x___05Fh118194 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118196) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118197));
    vlTOPp->mkMac__DOT__x___05Fh125042 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125044) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125045));
    vlTOPp->mkMac__DOT__y___05Fh70006 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh69814) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh69815));
    vlTOPp->mkMac__DOT__y___05Fh26434 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26185));
    vlTOPp->mkMac__DOT__y___05Fh26436 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26185));
    vlTOPp->mkMac__DOT__y___05Fh104819 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104566));
    vlTOPp->mkMac__DOT__y___05Fh104821 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104566));
    vlTOPp->mkMac__DOT__y___05Fh111481 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111539) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111540));
    vlTOPp->mkMac__DOT__y___05Fh118136 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118194) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118195));
    vlTOPp->mkMac__DOT__y___05Fh124984 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125042) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125043));
    vlTOPp->mkMac__DOT__y___05Fh70008 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh70006));
    vlTOPp->mkMac__DOT__x___05Fh26433 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26435) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26436));
    vlTOPp->mkMac__DOT__x___05Fh104818 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104820) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104821));
    vlTOPp->mkMac__DOT__y___05Fh111734 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111481));
    vlTOPp->mkMac__DOT__y___05Fh111736 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111481));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2858 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118135) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118136)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh117941) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh117942)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2857)));
    vlTOPp->mkMac__DOT__y___05Fh118389 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118136));
    vlTOPp->mkMac__DOT__y___05Fh118391 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118136));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2779 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124983) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124984)) 
            << 6U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh124789) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh124790)) 
                       << 5U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2778)));
    vlTOPp->mkMac__DOT__y___05Fh125237 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124984));
    vlTOPp->mkMac__DOT__y___05Fh125239 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh124984));
    vlTOPp->mkMac__DOT__x___05Fh70005 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                                >> 8U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh70008)));
    vlTOPp->mkMac__DOT__y___05Fh26376 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26433) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26434));
    vlTOPp->mkMac__DOT__y___05Fh104760 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh104818) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh104819));
    vlTOPp->mkMac__DOT__x___05Fh111733 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111735) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111736));
    vlTOPp->mkMac__DOT__x___05Fh118388 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118390) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118391));
    vlTOPp->mkMac__DOT__x___05Fh125236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125238) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125239));
    vlTOPp->mkMac__DOT__y___05Fh69948 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh70005) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh70006));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d239 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26375) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26376)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26184) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26185)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d238)));
    vlTOPp->mkMac__DOT__y___05Fh26625 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26376));
    vlTOPp->mkMac__DOT__y___05Fh26627 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26376));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2006 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh104759) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104760)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh104565) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104566)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2005)));
    vlTOPp->mkMac__DOT__y___05Fh105013 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104760));
    vlTOPp->mkMac__DOT__y___05Fh105015 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh104760));
    vlTOPp->mkMac__DOT__y___05Fh111675 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111733) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111734));
    vlTOPp->mkMac__DOT__y___05Fh118330 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118388) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118389));
    vlTOPp->mkMac__DOT__y___05Fh125178 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125236) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125237));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1036 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh69948) 
                         << 9U))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh69756) 
                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh70006)) 
                                      << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1035)));
    vlTOPp->mkMac__DOT__y___05Fh70199 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh69948));
    vlTOPp->mkMac__DOT__x___05Fh26624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26626) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26627));
    vlTOPp->mkMac__DOT__x___05Fh105012 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105014) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105015));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2701 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111674) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111675)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111480) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111481)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2700)));
    vlTOPp->mkMac__DOT__y___05Fh111928 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111675));
    vlTOPp->mkMac__DOT__y___05Fh111930 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111675));
    vlTOPp->mkMac__DOT__y___05Fh118583 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118330));
    vlTOPp->mkMac__DOT__y___05Fh118585 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118330));
    vlTOPp->mkMac__DOT__y___05Fh125431 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125178));
    vlTOPp->mkMac__DOT__y___05Fh125433 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125178));
    vlTOPp->mkMac__DOT__y___05Fh70390 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70199));
    vlTOPp->mkMac__DOT__y___05Fh26567 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26624) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26625));
    vlTOPp->mkMac__DOT__y___05Fh104954 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105012) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105013));
    vlTOPp->mkMac__DOT__x___05Fh111927 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111929) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111930));
    vlTOPp->mkMac__DOT__x___05Fh118582 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118584) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118585));
    vlTOPp->mkMac__DOT__x___05Fh125430 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125432) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125433));
    vlTOPp->mkMac__DOT__y___05Fh70581 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70390));
    vlTOPp->mkMac__DOT__y___05Fh26816 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26567));
    vlTOPp->mkMac__DOT__y___05Fh26818 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26567));
    vlTOPp->mkMac__DOT__y___05Fh105207 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104954));
    vlTOPp->mkMac__DOT__y___05Fh105209 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh104954));
    vlTOPp->mkMac__DOT__y___05Fh111869 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh111927) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh111928));
    vlTOPp->mkMac__DOT__y___05Fh118524 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118582) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118583));
    vlTOPp->mkMac__DOT__y___05Fh125372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125430) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125431));
    vlTOPp->mkMac__DOT__y___05Fh70772 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70581));
    vlTOPp->mkMac__DOT__x___05Fh26815 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26817) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26818));
    vlTOPp->mkMac__DOT__x___05Fh105206 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105208) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105209));
    vlTOPp->mkMac__DOT__y___05Fh112122 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111869));
    vlTOPp->mkMac__DOT__y___05Fh112124 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh111869));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2859 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118523) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118524)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118329) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118330)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2858)));
    vlTOPp->mkMac__DOT__y___05Fh118777 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118524));
    vlTOPp->mkMac__DOT__y___05Fh118779 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118524));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2780 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125371) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125372)) 
            << 8U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125177) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125178)) 
                       << 7U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2779)));
    vlTOPp->mkMac__DOT__y___05Fh125625 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125372));
    vlTOPp->mkMac__DOT__y___05Fh125627 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125372));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1038 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70772) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70581) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh70390) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh70199) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1036)))));
    vlTOPp->mkMac__DOT__y___05Fh70963 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70772));
    vlTOPp->mkMac__DOT__y___05Fh26758 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh26815) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh26816));
    vlTOPp->mkMac__DOT__y___05Fh105148 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105206) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105207));
    vlTOPp->mkMac__DOT__x___05Fh112121 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112123) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112124));
    vlTOPp->mkMac__DOT__x___05Fh118776 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118778) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118779));
    vlTOPp->mkMac__DOT__x___05Fh125624 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125626) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125627));
    vlTOPp->mkMac__DOT__y___05Fh71094 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh70963));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d240 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26757) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26758)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26566) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26567)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d239)));
    vlTOPp->mkMac__DOT__y___05Fh27007 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26758));
    vlTOPp->mkMac__DOT__y___05Fh27009 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26758));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2007 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh105147) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105148)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh104953) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh104954)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2006)));
    vlTOPp->mkMac__DOT__y___05Fh105401 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105148));
    vlTOPp->mkMac__DOT__y___05Fh105403 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105148));
    vlTOPp->mkMac__DOT__y___05Fh112063 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112121) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112122));
    vlTOPp->mkMac__DOT__y___05Fh118718 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118776) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118777));
    vlTOPp->mkMac__DOT__y___05Fh125566 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125624) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125625));
    vlTOPp->mkMac__DOT__mant_mult___05Fh64627 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d946) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh71094) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh70963) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1038))));
    vlTOPp->mkMac__DOT__x___05Fh27006 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27008) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27009));
    vlTOPp->mkMac__DOT__x___05Fh105400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105402) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105403));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2702 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112062) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112063)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh111868) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh111869)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2701)));
    vlTOPp->mkMac__DOT__y___05Fh112316 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112063));
    vlTOPp->mkMac__DOT__y___05Fh112318 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112063));
    vlTOPp->mkMac__DOT__y___05Fh118971 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118718));
    vlTOPp->mkMac__DOT__y___05Fh118973 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh118718));
    vlTOPp->mkMac__DOT__y___05Fh125819 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125566));
    vlTOPp->mkMac__DOT__y___05Fh125821 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh125566));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
        = ((2U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh64627
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d944);
    vlTOPp->mkMac__DOT__y___05Fh26949 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27006) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27007));
    vlTOPp->mkMac__DOT__y___05Fh105342 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105400) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105401));
    vlTOPp->mkMac__DOT__x___05Fh112315 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112317) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112318));
    vlTOPp->mkMac__DOT__x___05Fh118970 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118972) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118973));
    vlTOPp->mkMac__DOT__x___05Fh125818 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125820) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125821));
    vlTOPp->mkMac__DOT__x___05Fh72673 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh72864 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh72291 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh72482 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh71909 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh72100 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh71718 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 3U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh72924 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh72733 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh72542 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh72351 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh72160 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh71969 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 3U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh71719 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 2U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh27198 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26949));
    vlTOPp->mkMac__DOT__y___05Fh27200 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh26949));
    vlTOPp->mkMac__DOT__y___05Fh105595 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105342));
    vlTOPp->mkMac__DOT__y___05Fh105597 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105342));
    vlTOPp->mkMac__DOT__y___05Fh112257 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112315) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112316));
    vlTOPp->mkMac__DOT__y___05Fh118912 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh118970) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh118971));
    vlTOPp->mkMac__DOT__y___05Fh125760 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh125818) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh125819));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1121 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh71718) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh71719)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                             ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042))));
    vlTOPp->mkMac__DOT__y___05Fh71968 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71719));
    vlTOPp->mkMac__DOT__y___05Fh71970 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71719));
    vlTOPp->mkMac__DOT__x___05Fh27197 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27199) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27200));
    vlTOPp->mkMac__DOT__x___05Fh105594 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105596) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105597));
    vlTOPp->mkMac__DOT__y___05Fh112510 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112257));
    vlTOPp->mkMac__DOT__y___05Fh112512 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112257));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2860 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118911) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118912)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh118717) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh118718)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2859)));
    vlTOPp->mkMac__DOT__y___05Fh119165 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118912));
    vlTOPp->mkMac__DOT__y___05Fh119167 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh118912));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2781 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125759) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125760)) 
            << 0xaU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125565) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125566)) 
                         << 9U) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2780)));
    vlTOPp->mkMac__DOT__y___05Fh126013 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125760));
    vlTOPp->mkMac__DOT__y___05Fh126015 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125760));
    vlTOPp->mkMac__DOT__x___05Fh71967 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh71969) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh71970));
    vlTOPp->mkMac__DOT__y___05Fh27140 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27197) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27198));
    vlTOPp->mkMac__DOT__y___05Fh105536 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105594) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105595));
    vlTOPp->mkMac__DOT__x___05Fh112509 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112511) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112512));
    vlTOPp->mkMac__DOT__x___05Fh119164 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119166) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119167));
    vlTOPp->mkMac__DOT__x___05Fh126012 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126014) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126015));
    vlTOPp->mkMac__DOT__y___05Fh71910 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh71967) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh71968));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d241 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27139) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27140)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh26948) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh26949)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d240)));
    vlTOPp->mkMac__DOT__y___05Fh27389 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27140));
    vlTOPp->mkMac__DOT__y___05Fh27391 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27140));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2008 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh105535) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105536)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh105341) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105342)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2007)));
    vlTOPp->mkMac__DOT__y___05Fh105789 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105536));
    vlTOPp->mkMac__DOT__y___05Fh105791 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105536));
    vlTOPp->mkMac__DOT__y___05Fh112451 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112509) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112510));
    vlTOPp->mkMac__DOT__y___05Fh119106 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119164) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119165));
    vlTOPp->mkMac__DOT__y___05Fh125954 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126012) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126013));
    vlTOPp->mkMac__DOT__y___05Fh72159 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71910));
    vlTOPp->mkMac__DOT__y___05Fh72161 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh71910));
    vlTOPp->mkMac__DOT__x___05Fh27388 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27390) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27391));
    vlTOPp->mkMac__DOT__x___05Fh105788 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105790) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105791));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2703 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112450) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112451)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112256) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112257)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2702)));
    vlTOPp->mkMac__DOT__y___05Fh112704 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112451));
    vlTOPp->mkMac__DOT__y___05Fh112706 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112451));
    vlTOPp->mkMac__DOT__y___05Fh119359 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119106));
    vlTOPp->mkMac__DOT__y___05Fh119361 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119106));
    vlTOPp->mkMac__DOT__y___05Fh126207 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125954));
    vlTOPp->mkMac__DOT__y___05Fh126209 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh125954));
    vlTOPp->mkMac__DOT__x___05Fh72158 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72160) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72161));
    vlTOPp->mkMac__DOT__y___05Fh27331 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27388) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27389));
    vlTOPp->mkMac__DOT__y___05Fh105730 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105788) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105789));
    vlTOPp->mkMac__DOT__x___05Fh112703 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112705) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112706));
    vlTOPp->mkMac__DOT__x___05Fh119358 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119360) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119361));
    vlTOPp->mkMac__DOT__x___05Fh126206 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126208) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126209));
    vlTOPp->mkMac__DOT__y___05Fh72101 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72158) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72159));
    vlTOPp->mkMac__DOT__y___05Fh27580 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh27331));
    vlTOPp->mkMac__DOT__y___05Fh27582 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27331));
    vlTOPp->mkMac__DOT__y___05Fh105983 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105730));
    vlTOPp->mkMac__DOT__y___05Fh105985 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105730));
    vlTOPp->mkMac__DOT__y___05Fh112645 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112703) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112704));
    vlTOPp->mkMac__DOT__y___05Fh119300 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119358) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119359));
    vlTOPp->mkMac__DOT__y___05Fh126148 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126206) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126207));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1122 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72100) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72101)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh71909) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh71910)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1121)));
    vlTOPp->mkMac__DOT__y___05Fh72350 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72101));
    vlTOPp->mkMac__DOT__y___05Fh72352 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72101));
    vlTOPp->mkMac__DOT__x___05Fh27579 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27581) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27582));
    vlTOPp->mkMac__DOT__x___05Fh105982 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105984) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105985));
    vlTOPp->mkMac__DOT__y___05Fh112898 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112645));
    vlTOPp->mkMac__DOT__y___05Fh112900 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112645));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2861 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119299) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119300)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119105) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119106)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2860)));
    vlTOPp->mkMac__DOT__y___05Fh119553 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119300));
    vlTOPp->mkMac__DOT__y___05Fh119555 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119300));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2782 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126147) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126148)) 
            << 0xcU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh125953) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh125954)) 
                         << 0xbU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2781)));
    vlTOPp->mkMac__DOT__y___05Fh126401 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126148));
    vlTOPp->mkMac__DOT__y___05Fh126403 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126148));
    vlTOPp->mkMac__DOT__x___05Fh72349 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72351) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72352));
    vlTOPp->mkMac__DOT__y___05Fh27522 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27579) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27580));
    vlTOPp->mkMac__DOT__y___05Fh105924 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh105982) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh105983));
    vlTOPp->mkMac__DOT__x___05Fh112897 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112899) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112900));
    vlTOPp->mkMac__DOT__x___05Fh119552 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119554) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119555));
    vlTOPp->mkMac__DOT__x___05Fh126400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126402) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126403));
    vlTOPp->mkMac__DOT__y___05Fh72292 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72349) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72350));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d242 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27521) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27522)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27330) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27331)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d241)));
    vlTOPp->mkMac__DOT__y___05Fh27771 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27522));
    vlTOPp->mkMac__DOT__y___05Fh27773 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27522));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2009 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh105923) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105924)) 
            << 0xfU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh105729) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh105730)) 
                         << 0xeU) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2008)));
    vlTOPp->mkMac__DOT__y___05Fh106177 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105924));
    vlTOPp->mkMac__DOT__y___05Fh106179 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh105924));
    vlTOPp->mkMac__DOT__y___05Fh112839 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh112897) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh112898));
    vlTOPp->mkMac__DOT__y___05Fh119494 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119552) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119553));
    vlTOPp->mkMac__DOT__y___05Fh126342 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126400) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126401));
    vlTOPp->mkMac__DOT__y___05Fh72541 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72292));
    vlTOPp->mkMac__DOT__y___05Fh72543 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72292));
    vlTOPp->mkMac__DOT__x___05Fh27770 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27772) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27773));
    vlTOPp->mkMac__DOT__x___05Fh106176 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106178) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106179));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2704 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112838) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112839)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh112644) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh112645)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2703)));
    vlTOPp->mkMac__DOT__y___05Fh113092 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112839));
    vlTOPp->mkMac__DOT__y___05Fh113094 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh112839));
    vlTOPp->mkMac__DOT__y___05Fh119747 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119494));
    vlTOPp->mkMac__DOT__y___05Fh119749 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119494));
    vlTOPp->mkMac__DOT__y___05Fh126595 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126342));
    vlTOPp->mkMac__DOT__y___05Fh126597 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126342));
    vlTOPp->mkMac__DOT__x___05Fh72540 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72542) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72543));
    vlTOPp->mkMac__DOT__y___05Fh27713 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27770) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27771));
    vlTOPp->mkMac__DOT__y___05Fh106118 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106176) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106177));
    vlTOPp->mkMac__DOT__x___05Fh113091 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113093) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113094));
    vlTOPp->mkMac__DOT__x___05Fh119746 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119748) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119749));
    vlTOPp->mkMac__DOT__x___05Fh126594 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126596) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126597));
    vlTOPp->mkMac__DOT__y___05Fh72483 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72540) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72541));
    vlTOPp->mkMac__DOT__y___05Fh27962 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27713));
    vlTOPp->mkMac__DOT__y___05Fh27964 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27713));
    vlTOPp->mkMac__DOT__y___05Fh106371 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106118));
    vlTOPp->mkMac__DOT__y___05Fh106373 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106118));
    vlTOPp->mkMac__DOT__y___05Fh113033 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113091) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113092));
    vlTOPp->mkMac__DOT__y___05Fh119688 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119746) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119747));
    vlTOPp->mkMac__DOT__y___05Fh126536 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126594) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126595));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1123 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72482) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72483)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72291) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72292)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1122)));
    vlTOPp->mkMac__DOT__y___05Fh72732 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72483));
    vlTOPp->mkMac__DOT__y___05Fh72734 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72483));
    vlTOPp->mkMac__DOT__x___05Fh27961 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27963) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27964));
    vlTOPp->mkMac__DOT__x___05Fh106370 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106372) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106373));
    vlTOPp->mkMac__DOT__y___05Fh113286 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113033));
    vlTOPp->mkMac__DOT__y___05Fh113288 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113033));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2862 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119687) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119688)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119493) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119494)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2861)));
    vlTOPp->mkMac__DOT__y___05Fh119941 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119688));
    vlTOPp->mkMac__DOT__y___05Fh119943 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119688));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2783 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126535) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126536)) 
            << 0xeU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126341) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126342)) 
                         << 0xdU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2782)));
    vlTOPp->mkMac__DOT__y___05Fh126789 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126536));
    vlTOPp->mkMac__DOT__y___05Fh126791 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126536));
    vlTOPp->mkMac__DOT__x___05Fh72731 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72733) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72734));
    vlTOPp->mkMac__DOT__y___05Fh27904 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh27961) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh27962));
    vlTOPp->mkMac__DOT__y___05Fh106312 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106370) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106371));
    vlTOPp->mkMac__DOT__x___05Fh113285 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113287) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113288));
    vlTOPp->mkMac__DOT__x___05Fh119940 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119942) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119943));
    vlTOPp->mkMac__DOT__x___05Fh126788 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126790) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126791));
    vlTOPp->mkMac__DOT__y___05Fh72674 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72731) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72732));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d243 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27903) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27904)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh27712) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh27713)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d242)));
    vlTOPp->mkMac__DOT__y___05Fh28153 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27904));
    vlTOPp->mkMac__DOT__y___05Fh28155 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh27904));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2010 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh106311) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh106312)) 
            << 0x11U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh106117) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh106118)) 
                          << 0x10U) | (IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2009)));
    vlTOPp->mkMac__DOT__y___05Fh106565 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106312));
    vlTOPp->mkMac__DOT__y___05Fh106567 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106312));
    vlTOPp->mkMac__DOT__y___05Fh113227 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113285) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113286));
    vlTOPp->mkMac__DOT__y___05Fh119882 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh119940) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh119941));
    vlTOPp->mkMac__DOT__y___05Fh126730 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126788) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126789));
    vlTOPp->mkMac__DOT__y___05Fh72923 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72674));
    vlTOPp->mkMac__DOT__y___05Fh72925 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh72674));
    vlTOPp->mkMac__DOT__x___05Fh28152 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28154) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28155));
    vlTOPp->mkMac__DOT__x___05Fh106564 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106566) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106567));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2705 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113226) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113227)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113032) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113033)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2704)));
    vlTOPp->mkMac__DOT__y___05Fh113480 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113227));
    vlTOPp->mkMac__DOT__y___05Fh113482 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113227));
    vlTOPp->mkMac__DOT__y___05Fh120135 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119882));
    vlTOPp->mkMac__DOT__y___05Fh120137 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh119882));
    vlTOPp->mkMac__DOT__y___05Fh126983 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126730));
    vlTOPp->mkMac__DOT__y___05Fh126985 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126730));
    vlTOPp->mkMac__DOT__x___05Fh72922 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72924) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72925));
    vlTOPp->mkMac__DOT__y___05Fh28095 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28152) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28153));
    vlTOPp->mkMac__DOT__y___05Fh106506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106564) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106565));
    vlTOPp->mkMac__DOT__x___05Fh113479 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113481) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113482));
    vlTOPp->mkMac__DOT__x___05Fh120134 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120136) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120137));
    vlTOPp->mkMac__DOT__x___05Fh126982 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126984) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126985));
    vlTOPp->mkMac__DOT__y___05Fh73114 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh72922) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh72923));
    vlTOPp->mkMac__DOT__y___05Fh28344 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28095));
    vlTOPp->mkMac__DOT__y___05Fh28346 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh28095));
    vlTOPp->mkMac__DOT__y___05Fh106759 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106506));
    vlTOPp->mkMac__DOT__y___05Fh106761 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106506));
    vlTOPp->mkMac__DOT__y___05Fh113421 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113479) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113480));
    vlTOPp->mkMac__DOT__y___05Fh120076 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120134) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120135));
    vlTOPp->mkMac__DOT__y___05Fh126924 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh126982) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh126983));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1124 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72864) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh73114)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh72673) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh72674)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1123)));
    vlTOPp->mkMac__DOT__y___05Fh73116 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh73114));
    vlTOPp->mkMac__DOT__x___05Fh28343 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28345) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28346));
    vlTOPp->mkMac__DOT__x___05Fh106758 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106760) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106761));
    vlTOPp->mkMac__DOT__y___05Fh113674 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113421));
    vlTOPp->mkMac__DOT__y___05Fh113676 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113421));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2863 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120075) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120076)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh119881) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh119882)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2862)));
    vlTOPp->mkMac__DOT__y___05Fh120329 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120076));
    vlTOPp->mkMac__DOT__y___05Fh120331 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120076));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2784 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126923) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126924)) 
            << 0x10U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh126729) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh126730)) 
                          << 0xfU) | (IData)(vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2783)));
    vlTOPp->mkMac__DOT__y___05Fh127177 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126924));
    vlTOPp->mkMac__DOT__y___05Fh127179 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh126924));
    vlTOPp->mkMac__DOT__x___05Fh73113 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                                >> 9U) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh73116)));
    vlTOPp->mkMac__DOT__y___05Fh28286 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh28343) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh28344));
    vlTOPp->mkMac__DOT__y___05Fh106700 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106758) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106759));
    vlTOPp->mkMac__DOT__x___05Fh113673 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113675) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113676));
    vlTOPp->mkMac__DOT__x___05Fh120328 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120330) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120331));
    vlTOPp->mkMac__DOT__x___05Fh127176 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127178) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127179));
    vlTOPp->mkMac__DOT__y___05Fh73056 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh73113) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh73114));
    vlTOPp->mkMac__DOT__product___05Fh16839 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d110) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28285) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28286)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh28094) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh28095)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d243))));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2011 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh106699) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh106700)) 
            << 0x13U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh106505) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh106506)) 
                          << 0x12U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2010));
    vlTOPp->mkMac__DOT__y___05Fh106953 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106700));
    vlTOPp->mkMac__DOT__y___05Fh106955 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106700));
    vlTOPp->mkMac__DOT__y___05Fh113615 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113673) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113674));
    vlTOPp->mkMac__DOT__y___05Fh120270 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120328) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120329));
    vlTOPp->mkMac__DOT__y___05Fh127118 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127176) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127177));
    vlTOPp->mkMac__DOT__y___05Fh73307 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73056));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
        = ((2U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh16839
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d108);
    vlTOPp->mkMac__DOT__x___05Fh106952 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106954) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106955));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2706 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113614) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113615)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113420) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113421)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2705));
    vlTOPp->mkMac__DOT__y___05Fh113868 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113615));
    vlTOPp->mkMac__DOT__y___05Fh113870 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113615));
    vlTOPp->mkMac__DOT__y___05Fh120523 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120270));
    vlTOPp->mkMac__DOT__y___05Fh120525 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120270));
    vlTOPp->mkMac__DOT__y___05Fh127371 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127118));
    vlTOPp->mkMac__DOT__y___05Fh127373 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127118));
    vlTOPp->mkMac__DOT__y___05Fh73498 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73307));
    vlTOPp->mkMac__DOT__x___05Fh32651 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh32842 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh32269 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32460 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh31887 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh32078 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh32902 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh31505 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31696 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31123 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31314 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh30741 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh30932 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh32711 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh30550 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 3U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh32520 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh32329 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh32138 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh31947 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh31756 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh31565 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh31374 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh31183 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh30992 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh30801 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 3U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh30551 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                                >> 2U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh106894 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh106952) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh106953));
    vlTOPp->mkMac__DOT__x___05Fh113867 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113869) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113870));
    vlTOPp->mkMac__DOT__x___05Fh120522 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120524) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120525));
    vlTOPp->mkMac__DOT__x___05Fh127370 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127372) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127373));
    vlTOPp->mkMac__DOT__y___05Fh73689 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73498));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d354 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30550) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30551)) 
            << 3U) | ((4U & ((0xfffffffcU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245) 
                             ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                << 2U))) | ((2U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245) 
                                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247))));
    vlTOPp->mkMac__DOT__y___05Fh30800 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30551));
    vlTOPp->mkMac__DOT__y___05Fh30802 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30551));
    vlTOPp->mkMac__DOT__y___05Fh107147 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106894));
    vlTOPp->mkMac__DOT__y___05Fh107149 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh106894));
    vlTOPp->mkMac__DOT__y___05Fh113809 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh113867) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh113868));
    vlTOPp->mkMac__DOT__y___05Fh120464 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120522) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120523));
    vlTOPp->mkMac__DOT__y___05Fh127312 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127370) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127371));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1126 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73689) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73498) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh73307) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh73056) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1124)))));
    vlTOPp->mkMac__DOT__y___05Fh73880 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73689));
    vlTOPp->mkMac__DOT__x___05Fh30799 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30801) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30802));
    vlTOPp->mkMac__DOT__x___05Fh107146 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107148) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107149));
    vlTOPp->mkMac__DOT__y___05Fh114062 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113809));
    vlTOPp->mkMac__DOT__y___05Fh114064 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh113809));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2864 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120463) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120464)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120269) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120270)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2863));
    vlTOPp->mkMac__DOT__y___05Fh120717 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120464));
    vlTOPp->mkMac__DOT__y___05Fh120719 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120464));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2785 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127311) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127312)) 
            << 0x12U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127117) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127118)) 
                          << 0x11U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2784));
    vlTOPp->mkMac__DOT__y___05Fh127565 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127312));
    vlTOPp->mkMac__DOT__y___05Fh127567 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127312));
    vlTOPp->mkMac__DOT__y___05Fh74011 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh73880));
    vlTOPp->mkMac__DOT__y___05Fh30742 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30799) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30800));
    vlTOPp->mkMac__DOT__y___05Fh107088 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107146) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107147));
    vlTOPp->mkMac__DOT__x___05Fh114061 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114063) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114064));
    vlTOPp->mkMac__DOT__x___05Fh120716 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120718) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120719));
    vlTOPp->mkMac__DOT__x___05Fh127564 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127566) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127567));
    vlTOPp->mkMac__DOT__mant_mult___05Fh64183 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1042) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh74011) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh73880) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1126))));
    vlTOPp->mkMac__DOT__y___05Fh30991 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30742));
    vlTOPp->mkMac__DOT__y___05Fh30993 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30742));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2012 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh107087) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107088)) 
            << 0x15U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh106893) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh106894)) 
                          << 0x14U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2011));
    vlTOPp->mkMac__DOT__y___05Fh107341 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107088));
    vlTOPp->mkMac__DOT__y___05Fh107343 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107088));
    vlTOPp->mkMac__DOT__y___05Fh114003 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114061) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114062));
    vlTOPp->mkMac__DOT__y___05Fh120658 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120716) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120717));
    vlTOPp->mkMac__DOT__y___05Fh127506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127564) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127565));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
        = ((4U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh64183
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1040);
    vlTOPp->mkMac__DOT__x___05Fh30990 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30992) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30993));
    vlTOPp->mkMac__DOT__x___05Fh107340 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107342) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107343));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2707 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114002) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114003)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh113808) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh113809)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2706));
    vlTOPp->mkMac__DOT__y___05Fh114256 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114003));
    vlTOPp->mkMac__DOT__y___05Fh114258 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114003));
    vlTOPp->mkMac__DOT__y___05Fh120911 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120658));
    vlTOPp->mkMac__DOT__y___05Fh120913 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120658));
    vlTOPp->mkMac__DOT__y___05Fh127759 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127506));
    vlTOPp->mkMac__DOT__y___05Fh127761 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127506));
    vlTOPp->mkMac__DOT__x___05Fh75972 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh75590 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh75781 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh75208 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh75399 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh74826 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 4U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh75017 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh76032 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh75841 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh75650 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh75459 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh75268 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh75077 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 4U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh74827 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 3U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh30933 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh30990) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh30991));
    vlTOPp->mkMac__DOT__y___05Fh107282 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107340) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107341));
    vlTOPp->mkMac__DOT__x___05Fh114255 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114257) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114258));
    vlTOPp->mkMac__DOT__x___05Fh120910 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120912) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120913));
    vlTOPp->mkMac__DOT__x___05Fh127758 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127760) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127761));
    vlTOPp->mkMac__DOT__y___05Fh75076 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh74827));
    vlTOPp->mkMac__DOT__y___05Fh75078 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh74827));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d355 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30932) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30933)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh30741) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh30742)) 
                       << 4U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d354)));
    vlTOPp->mkMac__DOT__y___05Fh31182 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30933));
    vlTOPp->mkMac__DOT__y___05Fh31184 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh30933));
    vlTOPp->mkMac__DOT__y___05Fh107535 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107282));
    vlTOPp->mkMac__DOT__y___05Fh107537 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107282));
    vlTOPp->mkMac__DOT__y___05Fh114197 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114255) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114256));
    vlTOPp->mkMac__DOT__y___05Fh120852 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh120910) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh120911));
    vlTOPp->mkMac__DOT__y___05Fh127700 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127758) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127759));
    vlTOPp->mkMac__DOT__x___05Fh75075 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75077) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75078));
    vlTOPp->mkMac__DOT__x___05Fh31181 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31183) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31184));
    vlTOPp->mkMac__DOT__x___05Fh107534 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107536) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107537));
    vlTOPp->mkMac__DOT__y___05Fh114450 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114197));
    vlTOPp->mkMac__DOT__y___05Fh114452 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114197));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2865 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120851) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120852)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh120657) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh120658)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2864));
    vlTOPp->mkMac__DOT__y___05Fh121105 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120852));
    vlTOPp->mkMac__DOT__y___05Fh121107 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh120852));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2786 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127699) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127700)) 
            << 0x14U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127505) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127506)) 
                          << 0x13U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2785));
    vlTOPp->mkMac__DOT__y___05Fh127953 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127700));
    vlTOPp->mkMac__DOT__y___05Fh127955 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127700));
    vlTOPp->mkMac__DOT__y___05Fh75018 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75075) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75076));
    vlTOPp->mkMac__DOT__y___05Fh31124 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31181) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31182));
    vlTOPp->mkMac__DOT__y___05Fh107476 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107534) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107535));
    vlTOPp->mkMac__DOT__x___05Fh114449 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114451) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114452));
    vlTOPp->mkMac__DOT__x___05Fh121104 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121106) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121107));
    vlTOPp->mkMac__DOT__x___05Fh127952 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127954) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127955));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1206 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75017) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75018)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh74826) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh74827)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                        ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130)))));
    vlTOPp->mkMac__DOT__y___05Fh75267 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75018));
    vlTOPp->mkMac__DOT__y___05Fh75269 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75018));
    vlTOPp->mkMac__DOT__y___05Fh31373 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31124));
    vlTOPp->mkMac__DOT__y___05Fh31375 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31124));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2013 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh107475) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107476)) 
            << 0x17U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh107281) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107282)) 
                          << 0x16U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2012));
    vlTOPp->mkMac__DOT__y___05Fh107729 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107476));
    vlTOPp->mkMac__DOT__y___05Fh107731 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107476));
    vlTOPp->mkMac__DOT__y___05Fh114391 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114449) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114450));
    vlTOPp->mkMac__DOT__y___05Fh121046 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121104) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121105));
    vlTOPp->mkMac__DOT__y___05Fh127894 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh127952) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh127953));
    vlTOPp->mkMac__DOT__x___05Fh75266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75268) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75269));
    vlTOPp->mkMac__DOT__x___05Fh31372 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31374) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31375));
    vlTOPp->mkMac__DOT__x___05Fh107728 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107730) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107731));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2708 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114390) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114391)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114196) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114197)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2707));
    vlTOPp->mkMac__DOT__y___05Fh114644 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114391));
    vlTOPp->mkMac__DOT__y___05Fh114646 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114391));
    vlTOPp->mkMac__DOT__y___05Fh121299 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121046));
    vlTOPp->mkMac__DOT__y___05Fh121301 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121046));
    vlTOPp->mkMac__DOT__y___05Fh128147 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127894));
    vlTOPp->mkMac__DOT__y___05Fh128149 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh127894));
    vlTOPp->mkMac__DOT__y___05Fh75209 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75266) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75267));
    vlTOPp->mkMac__DOT__y___05Fh31315 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31372) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31373));
    vlTOPp->mkMac__DOT__y___05Fh107670 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107728) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107729));
    vlTOPp->mkMac__DOT__x___05Fh114643 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114645) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114646));
    vlTOPp->mkMac__DOT__x___05Fh121298 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121300) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121301));
    vlTOPp->mkMac__DOT__x___05Fh128146 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128148) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128149));
    vlTOPp->mkMac__DOT__y___05Fh75458 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75209));
    vlTOPp->mkMac__DOT__y___05Fh75460 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75209));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d356 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31314) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31315)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31123) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31124)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d355)));
    vlTOPp->mkMac__DOT__y___05Fh31564 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31315));
    vlTOPp->mkMac__DOT__y___05Fh31566 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31315));
    vlTOPp->mkMac__DOT__y___05Fh107923 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107670));
    vlTOPp->mkMac__DOT__y___05Fh107925 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107670));
    vlTOPp->mkMac__DOT__y___05Fh114585 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114643) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114644));
    vlTOPp->mkMac__DOT__y___05Fh121240 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121298) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121299));
    vlTOPp->mkMac__DOT__y___05Fh128088 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128146) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128147));
    vlTOPp->mkMac__DOT__x___05Fh75457 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75459) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75460));
    vlTOPp->mkMac__DOT__x___05Fh31563 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31565) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31566));
    vlTOPp->mkMac__DOT__x___05Fh107922 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107924) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107925));
    vlTOPp->mkMac__DOT__y___05Fh114838 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114585));
    vlTOPp->mkMac__DOT__y___05Fh114840 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114585));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2866 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121239) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121240)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121045) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121046)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2865));
    vlTOPp->mkMac__DOT__y___05Fh121493 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121240));
    vlTOPp->mkMac__DOT__y___05Fh121495 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121240));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2787 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128087) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128088)) 
            << 0x16U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh127893) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh127894)) 
                          << 0x15U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2786));
    vlTOPp->mkMac__DOT__y___05Fh128341 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128088));
    vlTOPp->mkMac__DOT__y___05Fh128343 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128088));
    vlTOPp->mkMac__DOT__y___05Fh75400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75457) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75458));
    vlTOPp->mkMac__DOT__y___05Fh31506 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31563) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31564));
    vlTOPp->mkMac__DOT__y___05Fh107864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh107922) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh107923));
    vlTOPp->mkMac__DOT__x___05Fh114837 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114839) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114840));
    vlTOPp->mkMac__DOT__x___05Fh121492 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121494) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121495));
    vlTOPp->mkMac__DOT__x___05Fh128340 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128342) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128343));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1207 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75399) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75400)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75208) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75209)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1206)));
    vlTOPp->mkMac__DOT__y___05Fh75649 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75400));
    vlTOPp->mkMac__DOT__y___05Fh75651 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75400));
    vlTOPp->mkMac__DOT__y___05Fh31755 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31506));
    vlTOPp->mkMac__DOT__y___05Fh31757 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31506));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2014 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh107863) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107864)) 
            << 0x19U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh107669) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh107670)) 
                          << 0x18U) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2013));
    vlTOPp->mkMac__DOT__y___05Fh108117 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107864));
    vlTOPp->mkMac__DOT__y___05Fh108119 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh107864));
    vlTOPp->mkMac__DOT__y___05Fh114779 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh114837) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh114838));
    vlTOPp->mkMac__DOT__y___05Fh121434 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121492) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121493));
    vlTOPp->mkMac__DOT__y___05Fh128282 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128340) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128341));
    vlTOPp->mkMac__DOT__x___05Fh75648 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75650) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75651));
    vlTOPp->mkMac__DOT__x___05Fh31754 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31756) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31757));
    vlTOPp->mkMac__DOT__x___05Fh108116 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108118) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108119));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2709 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114778) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114779)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114584) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114585)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2708));
    vlTOPp->mkMac__DOT__y___05Fh115032 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114779));
    vlTOPp->mkMac__DOT__y___05Fh115034 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114779));
    vlTOPp->mkMac__DOT__y___05Fh121687 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121434));
    vlTOPp->mkMac__DOT__y___05Fh121689 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121434));
    vlTOPp->mkMac__DOT__y___05Fh128535 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128282));
    vlTOPp->mkMac__DOT__y___05Fh128537 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128282));
    vlTOPp->mkMac__DOT__y___05Fh75591 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75648) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75649));
    vlTOPp->mkMac__DOT__y___05Fh31697 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31754) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31755));
    vlTOPp->mkMac__DOT__y___05Fh108058 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108116) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108117));
    vlTOPp->mkMac__DOT__x___05Fh115031 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115033) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115034));
    vlTOPp->mkMac__DOT__x___05Fh121686 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121688) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121689));
    vlTOPp->mkMac__DOT__x___05Fh128534 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128536) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128537));
    vlTOPp->mkMac__DOT__y___05Fh75840 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75591));
    vlTOPp->mkMac__DOT__y___05Fh75842 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75591));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d357 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31696) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31697)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31505) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31506)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d356)));
    vlTOPp->mkMac__DOT__y___05Fh31946 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31697));
    vlTOPp->mkMac__DOT__y___05Fh31948 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31697));
    vlTOPp->mkMac__DOT__y___05Fh108311 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108058));
    vlTOPp->mkMac__DOT__y___05Fh108313 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108058));
    vlTOPp->mkMac__DOT__y___05Fh114973 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115031) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115032));
    vlTOPp->mkMac__DOT__y___05Fh121628 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121686) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121687));
    vlTOPp->mkMac__DOT__y___05Fh128476 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128534) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128535));
    vlTOPp->mkMac__DOT__x___05Fh75839 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75841) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75842));
    vlTOPp->mkMac__DOT__x___05Fh31945 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31947) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31948));
    vlTOPp->mkMac__DOT__x___05Fh108310 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108312) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108313));
    vlTOPp->mkMac__DOT__y___05Fh115226 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114973));
    vlTOPp->mkMac__DOT__y___05Fh115228 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh114973));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2867 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121627) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121628)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121433) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121434)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2866));
    vlTOPp->mkMac__DOT__y___05Fh121881 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121628));
    vlTOPp->mkMac__DOT__y___05Fh121883 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121628));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2788 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128475) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128476)) 
            << 0x18U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128281) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128282)) 
                          << 0x17U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2787));
    vlTOPp->mkMac__DOT__y___05Fh128729 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128476));
    vlTOPp->mkMac__DOT__y___05Fh128731 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128476));
    vlTOPp->mkMac__DOT__y___05Fh75782 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh75839) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh75840));
    vlTOPp->mkMac__DOT__y___05Fh31888 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh31945) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh31946));
    vlTOPp->mkMac__DOT__y___05Fh108252 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108310) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108311));
    vlTOPp->mkMac__DOT__x___05Fh115225 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115227) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115228));
    vlTOPp->mkMac__DOT__x___05Fh121880 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121882) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121883));
    vlTOPp->mkMac__DOT__x___05Fh128728 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128730) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128731));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1208 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75781) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75782)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75590) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh75591)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1207)));
    vlTOPp->mkMac__DOT__y___05Fh76031 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75782));
    vlTOPp->mkMac__DOT__y___05Fh76033 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh75782));
    vlTOPp->mkMac__DOT__y___05Fh32137 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh31888));
    vlTOPp->mkMac__DOT__y___05Fh32139 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh31888));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2015 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh108251) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108252)) 
            << 0x1bU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh108057) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108058)) 
                          << 0x1aU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2014));
    vlTOPp->mkMac__DOT__y___05Fh108505 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108252));
    vlTOPp->mkMac__DOT__y___05Fh108507 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108252));
    vlTOPp->mkMac__DOT__y___05Fh115167 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115225) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115226));
    vlTOPp->mkMac__DOT__y___05Fh121822 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh121880) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh121881));
    vlTOPp->mkMac__DOT__y___05Fh128670 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128728) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128729));
    vlTOPp->mkMac__DOT__x___05Fh76030 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76032) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76033));
    vlTOPp->mkMac__DOT__x___05Fh32136 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32138) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32139));
    vlTOPp->mkMac__DOT__x___05Fh108504 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108506) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108507));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2710 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115166) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115167)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh114972) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh114973)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2709));
    vlTOPp->mkMac__DOT__y___05Fh115420 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115167));
    vlTOPp->mkMac__DOT__y___05Fh115422 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115167));
    vlTOPp->mkMac__DOT__y___05Fh122075 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121822));
    vlTOPp->mkMac__DOT__y___05Fh122077 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh121822));
    vlTOPp->mkMac__DOT__y___05Fh128923 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128670));
    vlTOPp->mkMac__DOT__y___05Fh128925 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128670));
    vlTOPp->mkMac__DOT__y___05Fh76222 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76030) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76031));
    vlTOPp->mkMac__DOT__y___05Fh32079 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32136) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32137));
    vlTOPp->mkMac__DOT__y___05Fh108446 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108504) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108505));
    vlTOPp->mkMac__DOT__x___05Fh115419 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115421) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115422));
    vlTOPp->mkMac__DOT__x___05Fh122074 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122076) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122077));
    vlTOPp->mkMac__DOT__x___05Fh128922 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128924) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128925));
    vlTOPp->mkMac__DOT__y___05Fh76224 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76222));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d358 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32078) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32079)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh31887) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh31888)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d357)));
    vlTOPp->mkMac__DOT__y___05Fh32328 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh32079));
    vlTOPp->mkMac__DOT__y___05Fh32330 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32079));
    vlTOPp->mkMac__DOT__y___05Fh108699 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108446));
    vlTOPp->mkMac__DOT__y___05Fh108701 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108446));
    vlTOPp->mkMac__DOT__y___05Fh115361 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115419) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115420));
    vlTOPp->mkMac__DOT__y___05Fh122016 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122074) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122075));
    vlTOPp->mkMac__DOT__y___05Fh128864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh128922) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh128923));
    vlTOPp->mkMac__DOT__x___05Fh76221 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                                >> 0xaU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh76224)));
    vlTOPp->mkMac__DOT__x___05Fh32327 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32329) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32330));
    vlTOPp->mkMac__DOT__x___05Fh108698 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108700) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108701));
    vlTOPp->mkMac__DOT__y___05Fh115614 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115361));
    vlTOPp->mkMac__DOT__y___05Fh115616 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115361));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2868 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122015) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122016)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh121821) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh121822)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2867));
    vlTOPp->mkMac__DOT__y___05Fh122269 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122016));
    vlTOPp->mkMac__DOT__y___05Fh122271 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122016));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2789 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128863) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128864)) 
            << 0x1aU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh128669) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh128670)) 
                          << 0x19U) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2788));
    vlTOPp->mkMac__DOT__y___05Fh129117 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128864));
    vlTOPp->mkMac__DOT__y___05Fh129119 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh128864));
    vlTOPp->mkMac__DOT__y___05Fh76164 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh76221) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh76222));
    vlTOPp->mkMac__DOT__y___05Fh32270 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32327) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32328));
    vlTOPp->mkMac__DOT__y___05Fh108640 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108698) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108699));
    vlTOPp->mkMac__DOT__x___05Fh115613 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115615) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115616));
    vlTOPp->mkMac__DOT__x___05Fh122268 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122270) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122271));
    vlTOPp->mkMac__DOT__x___05Fh129116 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129118) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129119));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1209 
        = ((0x800U & ((0xfffff800U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh76164) 
                         << 0xbU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh75972) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh76222)) 
                                        << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1208)));
    vlTOPp->mkMac__DOT__y___05Fh76415 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76164));
    vlTOPp->mkMac__DOT__y___05Fh32519 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32270));
    vlTOPp->mkMac__DOT__y___05Fh32521 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32270));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2016 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh108639) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108640)) 
            << 0x1dU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh108445) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108446)) 
                          << 0x1cU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2015));
    vlTOPp->mkMac__DOT__y___05Fh108893 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108640));
    vlTOPp->mkMac__DOT__y___05Fh108895 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108640));
    vlTOPp->mkMac__DOT__y___05Fh115555 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115613) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115614));
    vlTOPp->mkMac__DOT__y___05Fh122210 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122268) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122269));
    vlTOPp->mkMac__DOT__y___05Fh129058 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129116) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129117));
    vlTOPp->mkMac__DOT__y___05Fh76606 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76415));
    vlTOPp->mkMac__DOT__x___05Fh32518 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32520) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32521));
    vlTOPp->mkMac__DOT__x___05Fh108892 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108894) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108895));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2711 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115554) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115555)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115360) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115361)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2710));
    vlTOPp->mkMac__DOT__y___05Fh115808 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115555));
    vlTOPp->mkMac__DOT__y___05Fh115810 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115555));
    vlTOPp->mkMac__DOT__y___05Fh122463 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122210));
    vlTOPp->mkMac__DOT__y___05Fh122465 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122210));
    vlTOPp->mkMac__DOT__y___05Fh129311 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129058));
    vlTOPp->mkMac__DOT__y___05Fh129313 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129058));
    vlTOPp->mkMac__DOT__y___05Fh76797 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76606));
    vlTOPp->mkMac__DOT__y___05Fh32461 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32518) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32519));
    vlTOPp->mkMac__DOT__y___05Fh108834 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh108892) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh108893));
    vlTOPp->mkMac__DOT__x___05Fh115807 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115809) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115810));
    vlTOPp->mkMac__DOT__x___05Fh122462 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122464) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122465));
    vlTOPp->mkMac__DOT__x___05Fh129310 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129312) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129313));
    vlTOPp->mkMac__DOT__y___05Fh76928 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh76797));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d359 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32460) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32461)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32269) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32270)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d358)));
    vlTOPp->mkMac__DOT__y___05Fh32710 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32461));
    vlTOPp->mkMac__DOT__y___05Fh32712 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32461));
    vlTOPp->mkMac__DOT__y___05Fh109087 = ((vlTOPp->mkMac__DOT__c_ififo_rv_BITS_31_TO_0___05Fq4 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108834));
    vlTOPp->mkMac__DOT__y___05Fh109089 = ((vlTOPp->mkMac__DOT__product_ofifo_rv_BITS_31_TO_0___05Fq3 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh108834));
    vlTOPp->mkMac__DOT__y___05Fh115749 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh115807) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh115808));
    vlTOPp->mkMac__DOT__y___05Fh122404 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122462) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122463));
    vlTOPp->mkMac__DOT__y___05Fh129252 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129310) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129311));
    vlTOPp->mkMac__DOT__mant_mult___05Fh63739 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1130) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh76928) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh76797) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh76606) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh76415) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1209))))));
    vlTOPp->mkMac__DOT__x___05Fh32709 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32711) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32712));
    vlTOPp->mkMac__DOT__x___05Fh109086 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh109088) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh109089));
    vlTOPp->mkMac__DOT__y___05Fh116002 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115749));
    vlTOPp->mkMac__DOT__y___05Fh116004 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115749));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2869 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122403) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122404)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122209) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122210)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2868));
    vlTOPp->mkMac__DOT__y___05Fh122657 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122404));
    vlTOPp->mkMac__DOT__y___05Fh122659 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122404));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2790 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129251) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129252)) 
            << 0x1cU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129057) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129058)) 
                          << 0x1bU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2789));
    vlTOPp->mkMac__DOT__y___05Fh129505 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129252));
    vlTOPp->mkMac__DOT__y___05Fh129507 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129252));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
        = ((8U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh63739
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1128);
    vlTOPp->mkMac__DOT__y___05Fh32652 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32709) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32710));
    vlTOPp->mkMac__DOT__y___05Fh109028 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh109086) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh109087));
    vlTOPp->mkMac__DOT__x___05Fh116001 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116003) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116004));
    vlTOPp->mkMac__DOT__x___05Fh122656 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122658) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122659));
    vlTOPp->mkMac__DOT__x___05Fh129504 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129506) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129507));
    vlTOPp->mkMac__DOT__x___05Fh78889 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh79080 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh78507 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh78698 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh78125 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78316 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh77934 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 5U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh79140 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh78949 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh78758 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh78567 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh78376 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh78185 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 5U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh77935 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 4U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh32901 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32652));
    vlTOPp->mkMac__DOT__y___05Fh32903 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh32652));
    vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2017 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh109027) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh109028)) 
            << 0x1fU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh108833) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh108834)) 
                          << 0x1eU) | vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2016));
    vlTOPp->mkMac__DOT__y___05Fh115943 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116001) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116002));
    vlTOPp->mkMac__DOT__y___05Fh122598 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122656) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122657));
    vlTOPp->mkMac__DOT__y___05Fh129446 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129504) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129505));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1287 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh77934) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh77935)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214))));
    vlTOPp->mkMac__DOT__y___05Fh78184 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh77935));
    vlTOPp->mkMac__DOT__y___05Fh78186 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh77935));
    vlTOPp->mkMac__DOT__x___05Fh32900 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32902) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32903));
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2712 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115942) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115943)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh115748) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh115749)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2711));
    vlTOPp->mkMac__DOT__y___05Fh116196 = ((vlTOPp->mkMac__DOT__mant_y___05Fh109219 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115943));
    vlTOPp->mkMac__DOT__y___05Fh116198 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh115943));
    vlTOPp->mkMac__DOT__y___05Fh122851 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122598));
    vlTOPp->mkMac__DOT__y___05Fh122853 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122598));
    vlTOPp->mkMac__DOT__y___05Fh129699 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129446));
    vlTOPp->mkMac__DOT__y___05Fh129701 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129446));
    vlTOPp->mkMac__DOT__x___05Fh78183 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78185) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78186));
    vlTOPp->mkMac__DOT__y___05Fh32843 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh32900) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh32901));
    vlTOPp->mkMac__DOT__x___05Fh116195 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116197) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116198));
    vlTOPp->mkMac__DOT__x___05Fh122850 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122852) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122853));
    vlTOPp->mkMac__DOT__x___05Fh129698 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129700) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129701));
    vlTOPp->mkMac__DOT__y___05Fh78126 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78183) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78184));
    vlTOPp->mkMac__DOT__product___05Fh14752 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d247) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32842) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32843)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh32651) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh32652)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d359))));
    vlTOPp->mkMac__DOT__y___05Fh116137 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh116195) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh116196));
    vlTOPp->mkMac__DOT__y___05Fh122792 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh122850) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh122851));
    vlTOPp->mkMac__DOT__y___05Fh129640 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129698) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129699));
    vlTOPp->mkMac__DOT__y___05Fh78375 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78126));
    vlTOPp->mkMac__DOT__y___05Fh78377 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78126));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
        = ((4U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh14752
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d245);
    vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2870 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122791) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122792)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh122597) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122598)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2869));
    vlTOPp->mkMac__DOT__y___05Fh123045 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122792));
    vlTOPp->mkMac__DOT__y___05Fh123047 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh122792));
    vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2791 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129639) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129640)) 
            << 0x1eU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh129445) 
                           ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129446)) 
                          << 0x1dU) | vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2790));
    vlTOPp->mkMac__DOT__y___05Fh129893 = ((vlTOPp->mkMac__DOT__mant_x___05Fh109218 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129640));
    vlTOPp->mkMac__DOT__y___05Fh129895 = ((vlTOPp->mkMac__DOT__INV_mant_y09219___05Fq13 
                                           >> 0x1eU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh129640));
    vlTOPp->mkMac__DOT__x___05Fh78374 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78376) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78377));
    vlTOPp->mkMac__DOT__x___05Fh37208 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh37399 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh36826 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh37017 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh36444 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36635 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh37459 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh36062 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36253 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh35680 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh35871 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh35298 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 4U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh35489 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh37268 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh37077 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh36886 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh36695 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh36504 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh36313 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh36122 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh35931 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh35740 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh35549 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 4U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh35299 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                                >> 3U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__x___05Fh123044 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh123046) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh123047));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2872 
        = ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2018)
            ? vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2712
            : ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2037)
                ? vlTOPp->mkMac__DOT__INV_IF_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2791
                : vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2870));
    vlTOPp->mkMac__DOT__x___05Fh129892 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129894) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129895));
    vlTOPp->mkMac__DOT__y___05Fh78317 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78374) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78375));
    vlTOPp->mkMac__DOT__y___05Fh35548 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35299));
    vlTOPp->mkMac__DOT__y___05Fh35550 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35299));
    vlTOPp->mkMac__DOT__y___05Fh122986 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh123044) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh123045));
    vlTOPp->mkMac__DOT__y___05Fh129834 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh129892) 
                                          | (IData)(vlTOPp->mkMac__DOT__y___05Fh129893));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1288 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78316) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78317)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78125) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78126)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1287)));
    vlTOPp->mkMac__DOT__y___05Fh78566 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78317));
    vlTOPp->mkMac__DOT__y___05Fh78568 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78317));
    vlTOPp->mkMac__DOT__x___05Fh35547 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35549) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35550));
    vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0_ETC___05F_d2600 
        = ((IData)(vlTOPp->mkMac__DOT__IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0___05Fr_ETC___05F_d2037)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh129833) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh129834))
            : ((IData)(vlTOPp->mkMac__DOT__x___05Fh122985) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh122986)));
    vlTOPp->mkMac__DOT__x___05Fh78565 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78567) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78568));
    vlTOPp->mkMac__DOT__y___05Fh35490 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35547) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35548));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2601 
        = ((IData)(vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2018)
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh116136) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh116137))
            : (IData)(vlTOPp->mkMac__DOT__IF_IF_NOT_0b0_CONCAT_IF_product_ofifo_rv_port0_ETC___05F_d2600));
    vlTOPp->mkMac__DOT__y___05Fh78508 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78565) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78566));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d462 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35489) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35490)) 
            << 5U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35298) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35299)) 
                       << 4U) | ((8U & ((0xfffffff8U 
                                         & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361) 
                                        ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                           << 3U))) 
                                 | ((6U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363)))));
    vlTOPp->mkMac__DOT__y___05Fh35739 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35490));
    vlTOPp->mkMac__DOT__y___05Fh35741 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35490));
    if (vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2601) {
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05Fq19 
            = vlTOPp->mkMac__DOT__exp_x___05F_1___05Fh130025;
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
            = (((IData)(vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2601) 
                << 0x1eU) | (0x3fffffffU & (vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2872 
                                            >> 1U)));
    } else {
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05Fq19 
            = vlTOPp->mkMac__DOT__exp_x___05Fh109216;
        vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
            = vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2872;
    }
    vlTOPp->mkMac__DOT__y___05Fh78757 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78508));
    vlTOPp->mkMac__DOT__y___05Fh78759 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78508));
    vlTOPp->mkMac__DOT__x___05Fh35738 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35740) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35741));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707___05FETC___05Fq18 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__y___05Fh134023 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                                 >> 8U) 
                                                & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                                   >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh78756 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78758) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78759));
    vlTOPp->mkMac__DOT__y___05Fh35681 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35738) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35739));
    vlTOPp->mkMac__DOT__y___05Fh134211 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh134023));
    vlTOPp->mkMac__DOT__y___05Fh78699 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78756) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78757));
    vlTOPp->mkMac__DOT__y___05Fh35930 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35681));
    vlTOPp->mkMac__DOT__y___05Fh35932 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35681));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2953 
        = ((0x400U & ((0xfffffc00U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134211) 
                         << 0xaU))) | ((0x200U & ((0xfffffe00U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh134023) 
                                                   << 9U))) 
                                       | ((0x100U & 
                                           ((0xffffff00U 
                                             & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                            ^ (0xffffff00U 
                                               & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                                  << 1U)))) 
                                          | ((0x80U 
                                              & ((~ 
                                                  (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                                   >> 7U)) 
                                                 << 7U)) 
                                             | ((0x7eU 
                                                 & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                | (1U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707___05FETC___05Fq18))))));
    vlTOPp->mkMac__DOT__y___05Fh134399 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xaU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134211));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1289 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78698) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78699)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78507) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78508)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1288)));
    vlTOPp->mkMac__DOT__y___05Fh78948 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78699));
    vlTOPp->mkMac__DOT__y___05Fh78950 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78699));
    vlTOPp->mkMac__DOT__x___05Fh35929 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35931) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35932));
    vlTOPp->mkMac__DOT__y___05Fh134587 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xbU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134399));
    vlTOPp->mkMac__DOT__x___05Fh78947 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78949) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78950));
    vlTOPp->mkMac__DOT__y___05Fh35872 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh35929) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh35930));
    vlTOPp->mkMac__DOT__y___05Fh134775 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xcU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134587));
    vlTOPp->mkMac__DOT__y___05Fh78890 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh78947) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh78948));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d463 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35871) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35872)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh35680) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh35681)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d462)));
    vlTOPp->mkMac__DOT__y___05Fh36121 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35872));
    vlTOPp->mkMac__DOT__y___05Fh36123 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh35872));
    vlTOPp->mkMac__DOT__y___05Fh134963 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xdU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134775));
    vlTOPp->mkMac__DOT__y___05Fh79139 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh78890));
    vlTOPp->mkMac__DOT__y___05Fh79141 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh78890));
    vlTOPp->mkMac__DOT__x___05Fh36120 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36122) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36123));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2955 
        = ((0x4000U & ((0xffffc000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134963) 
                          << 0xeU))) | ((0x2000U & 
                                         ((0xffffe000U 
                                           & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134775) 
                                             << 0xdU))) 
                                        | ((0x1000U 
                                            & ((0xfffff000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh134587) 
                                                  << 0xcU))) 
                                           | ((0x800U 
                                               & ((0xfffff800U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh134399) 
                                                   << 0xbU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2953)))));
    vlTOPp->mkMac__DOT__y___05Fh135151 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xeU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh134963));
    vlTOPp->mkMac__DOT__x___05Fh79138 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79140) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79141));
    vlTOPp->mkMac__DOT__y___05Fh36063 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36120) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36121));
    vlTOPp->mkMac__DOT__y___05Fh135339 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0xfU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135151));
    vlTOPp->mkMac__DOT__y___05Fh79330 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79138) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79139));
    vlTOPp->mkMac__DOT__y___05Fh36312 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36063));
    vlTOPp->mkMac__DOT__y___05Fh36314 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36063));
    vlTOPp->mkMac__DOT__y___05Fh135527 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x10U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135339));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1290 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh79080) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh79330)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh78889) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh78890)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1289)));
    vlTOPp->mkMac__DOT__y___05Fh79332 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79330));
    vlTOPp->mkMac__DOT__x___05Fh36311 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36313) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36314));
    vlTOPp->mkMac__DOT__y___05Fh135715 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x11U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135527));
    vlTOPp->mkMac__DOT__x___05Fh79329 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                                >> 0xbU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh79332)));
    vlTOPp->mkMac__DOT__y___05Fh36254 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36311) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36312));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2957 
        = ((0x40000U & ((0xfffc0000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135715) 
                           << 0x12U))) | ((0x20000U 
                                           & ((0xfffe0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh135527) 
                                                 << 0x11U))) 
                                          | ((0x10000U 
                                              & ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh135339) 
                                                  << 0x10U))) 
                                             | ((0x8000U 
                                                 & ((0xffff8000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh135151) 
                                                     << 0xfU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2955)))));
    vlTOPp->mkMac__DOT__y___05Fh135903 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x12U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135715));
    vlTOPp->mkMac__DOT__y___05Fh79272 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh79329) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh79330));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d464 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36253) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36254)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36062) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36063)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d463)));
    vlTOPp->mkMac__DOT__y___05Fh36503 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36254));
    vlTOPp->mkMac__DOT__y___05Fh36505 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36254));
    vlTOPp->mkMac__DOT__y___05Fh136091 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x13U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh135903));
    vlTOPp->mkMac__DOT__y___05Fh79523 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79272));
    vlTOPp->mkMac__DOT__x___05Fh36502 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36504) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36505));
    vlTOPp->mkMac__DOT__y___05Fh136279 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x14U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136091));
    vlTOPp->mkMac__DOT__y___05Fh79714 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79523));
    vlTOPp->mkMac__DOT__y___05Fh36445 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36502) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36503));
    vlTOPp->mkMac__DOT__y___05Fh136467 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x15U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136279));
    vlTOPp->mkMac__DOT__y___05Fh79845 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh79714));
    vlTOPp->mkMac__DOT__y___05Fh36694 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36445));
    vlTOPp->mkMac__DOT__y___05Fh36696 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36445));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2959 
        = ((0x400000U & ((0xffc00000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh136467) 
                            << 0x16U))) | ((0x200000U 
                                            & ((0xffe00000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh136279) 
                                                  << 0x15U))) 
                                           | ((0x100000U 
                                               & ((0xfff00000U 
                                                   & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh136091) 
                                                   << 0x14U))) 
                                              | ((0x80000U 
                                                  & ((0xfff80000U 
                                                      & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh135903) 
                                                      << 0x13U))) 
                                                 | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2957))));
    vlTOPp->mkMac__DOT__y___05Fh136655 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x16U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136467));
    vlTOPp->mkMac__DOT__mant_mult___05Fh63295 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1214) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh79845) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh79714) 
                                                            << 0xeU))) 
                                                       | ((0x2000U 
                                                           & ((0xffffe000U 
                                                               & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                              ^ 
                                                              ((IData)(vlTOPp->mkMac__DOT__y___05Fh79523) 
                                                               << 0xdU))) 
                                                          | ((0x1000U 
                                                              & ((0xfffff000U 
                                                                  & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212) 
                                                                 ^ 
                                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh79272) 
                                                                  << 0xcU))) 
                                                             | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1290))))));
    vlTOPp->mkMac__DOT__x___05Fh36693 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36695) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36696));
    vlTOPp->mkMac__DOT__y___05Fh136843 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x17U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136655));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
        = ((0x10U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh63295
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1212);
    vlTOPp->mkMac__DOT__y___05Fh36636 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36693) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36694));
    vlTOPp->mkMac__DOT__y___05Fh137031 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x18U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh136843));
    vlTOPp->mkMac__DOT__x___05Fh82188 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                  >> 0xcU)));
    vlTOPp->mkMac__DOT__x___05Fh81806 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh81997 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh81424 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh81615 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh81042 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 6U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh81233 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh82248 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh82057 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh81866 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh81675 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh81484 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh81293 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 6U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh81043 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 5U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d465 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36635) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36636)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36444) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36445)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d464)));
    vlTOPp->mkMac__DOT__y___05Fh36885 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36636));
    vlTOPp->mkMac__DOT__y___05Fh36887 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36636));
    vlTOPp->mkMac__DOT__y___05Fh137219 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x19U) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137031));
    vlTOPp->mkMac__DOT__y___05Fh81292 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81043));
    vlTOPp->mkMac__DOT__y___05Fh81294 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81043));
    vlTOPp->mkMac__DOT__x___05Fh36884 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36886) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36887));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2961 
        = ((0x4000000U & ((0xfc000000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137219) 
                             << 0x1aU))) | ((0x2000000U 
                                             & ((0xfe000000U 
                                                 & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137031) 
                                                   << 0x19U))) 
                                            | ((0x1000000U 
                                                & ((0xff000000U 
                                                    & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh136843) 
                                                    << 0x18U))) 
                                               | ((0x800000U 
                                                   & ((0xff800000U 
                                                       & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh136655) 
                                                       << 0x17U))) 
                                                  | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2959))));
    vlTOPp->mkMac__DOT__y___05Fh137407 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x1aU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137219));
    vlTOPp->mkMac__DOT__x___05Fh81291 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81293) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81294));
    vlTOPp->mkMac__DOT__y___05Fh36827 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh36884) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh36885));
    vlTOPp->mkMac__DOT__y___05Fh137595 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x1bU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137407));
    vlTOPp->mkMac__DOT__y___05Fh81234 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81291) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81292));
    vlTOPp->mkMac__DOT__y___05Fh37076 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh36827));
    vlTOPp->mkMac__DOT__y___05Fh37078 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh36827));
    vlTOPp->mkMac__DOT__y___05Fh137783 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x1cU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137595));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1365 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81233) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81234)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81042) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81043)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                           ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295)))));
    vlTOPp->mkMac__DOT__y___05Fh81483 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81234));
    vlTOPp->mkMac__DOT__y___05Fh81485 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81234));
    vlTOPp->mkMac__DOT__x___05Fh37075 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37077) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37078));
    vlTOPp->mkMac__DOT__y___05Fh137971 = ((vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875 
                                           >> 0x1dU) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh137783));
    vlTOPp->mkMac__DOT__x___05Fh81482 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81484) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81485));
    vlTOPp->mkMac__DOT__y___05Fh37018 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37075) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37076));
    vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2963 
        = ((0x40000000U & ((0xc0000000U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh137971) 
                              << 0x1eU))) | ((0x20000000U 
                                              & ((0xe0000000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh137783) 
                                                  << 0x1dU))) 
                                             | ((0x10000000U 
                                                 & ((0xf0000000U 
                                                     & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh137595) 
                                                     << 0x1cU))) 
                                                | ((0x8000000U 
                                                    & ((0xf8000000U 
                                                        & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh137407) 
                                                        << 0x1bU))) 
                                                   | vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2961))));
    vlTOPp->mkMac__DOT__y___05Fh81425 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81482) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81483));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d466 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37017) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37018)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh36826) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh36827)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d465)));
    vlTOPp->mkMac__DOT__y___05Fh37267 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37018));
    vlTOPp->mkMac__DOT__y___05Fh37269 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37018));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707___05FETC___05Fq20 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875)
            ? vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2963
            : vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05F_d2875);
    vlTOPp->mkMac__DOT__y___05Fh81674 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81425));
    vlTOPp->mkMac__DOT__y___05Fh81676 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81425));
    vlTOPp->mkMac__DOT__x___05Fh37266 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37268) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37269));
    vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2966 
        = (((IData)(vlTOPp->mkMac__DOT___theResult___05F___05F_3_fst___05Fh109271) 
            << 0x1fU) | ((0x7f800000U & (vlTOPp->mkMac__DOT__IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_ETC___05Fq19 
                                         << 0x17U)) 
                         | (0x7fffffU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_product_ofifo_rv_port0___05Fread___05F707___05FETC___05Fq20 
                                         >> 7U))));
    vlTOPp->mkMac__DOT__x___05Fh81673 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81675) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81676));
    vlTOPp->mkMac__DOT__y___05Fh37209 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37266) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37267));
    vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(((1U & (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv))
                                              ? vlTOPp->mkMac__DOT__IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_70_ETC___05F_d2017
                                              : vlTOPp->mkMac__DOT__IF_IF_product_ofifo_rv_port0___05Fread___05F707_BIT_32_ETC___05F_d2966))));
    vlTOPp->mkMac__DOT__y___05Fh81616 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81673) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81674));
    vlTOPp->mkMac__DOT__y___05Fh37458 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37209));
    vlTOPp->mkMac__DOT__y___05Fh37460 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh37209));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1366 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81615) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81616)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81424) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81425)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1365)));
    vlTOPp->mkMac__DOT__y___05Fh81865 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81616));
    vlTOPp->mkMac__DOT__y___05Fh81867 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81616));
    vlTOPp->mkMac__DOT__x___05Fh37457 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37459) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37460));
    vlTOPp->mkMac__DOT__x___05Fh81864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81866) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81867));
    vlTOPp->mkMac__DOT__y___05Fh37400 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh37457) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh37458));
    vlTOPp->mkMac__DOT__y___05Fh81807 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh81864) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh81865));
    vlTOPp->mkMac__DOT__product___05Fh12665 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d363) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37399) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37400)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh37208) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh37209)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d466))));
    vlTOPp->mkMac__DOT__y___05Fh82056 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81807));
    vlTOPp->mkMac__DOT__y___05Fh82058 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh81807));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
        = ((8U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh12665
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d361);
    vlTOPp->mkMac__DOT__x___05Fh82055 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82057) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82058));
    vlTOPp->mkMac__DOT__x___05Fh41765 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh41956 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xbU)));
    vlTOPp->mkMac__DOT__x___05Fh41383 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41574 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41001 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41192 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh42016 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh40619 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh40810 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh40237 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40428 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40046 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 5U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh41825 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh41634 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh41443 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh41252 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh41061 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh40870 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh40679 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh40488 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh40297 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 5U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh40047 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                                >> 4U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh81998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82055) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82056));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d561 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40046) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40047)) 
            << 5U) | ((0x10U & ((0xfffffff0U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468) 
                                ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                   << 4U))) | ((0xeU 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470))));
    vlTOPp->mkMac__DOT__y___05Fh40296 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40047));
    vlTOPp->mkMac__DOT__y___05Fh40298 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40047));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1367 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81997) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81998)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh81806) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh81807)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1366)));
    vlTOPp->mkMac__DOT__y___05Fh82247 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh81998));
    vlTOPp->mkMac__DOT__y___05Fh82249 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh81998));
    vlTOPp->mkMac__DOT__x___05Fh40295 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40297) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40298));
    vlTOPp->mkMac__DOT__x___05Fh82246 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82248) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82249));
    vlTOPp->mkMac__DOT__y___05Fh40238 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40295) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40296));
    vlTOPp->mkMac__DOT__y___05Fh82438 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82246) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82247));
    vlTOPp->mkMac__DOT__y___05Fh40487 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40238));
    vlTOPp->mkMac__DOT__y___05Fh40489 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40238));
    vlTOPp->mkMac__DOT__y___05Fh82440 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82438));
    vlTOPp->mkMac__DOT__x___05Fh40486 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40488) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40489));
    vlTOPp->mkMac__DOT__x___05Fh82437 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                                >> 0xcU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh82440)));
    vlTOPp->mkMac__DOT__y___05Fh40429 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40486) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40487));
    vlTOPp->mkMac__DOT__y___05Fh82380 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh82437) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh82438));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d562 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40428) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40429)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40237) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40238)) 
                       << 6U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d561)));
    vlTOPp->mkMac__DOT__y___05Fh40678 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40429));
    vlTOPp->mkMac__DOT__y___05Fh40680 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40429));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1368 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh82380) 
                          << 0xdU))) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh82188) 
                                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh82438)) 
                                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1367)));
    vlTOPp->mkMac__DOT__y___05Fh82631 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82380));
    vlTOPp->mkMac__DOT__x___05Fh40677 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40679) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40680));
    vlTOPp->mkMac__DOT__y___05Fh82762 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh82631));
    vlTOPp->mkMac__DOT__y___05Fh40620 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40677) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40678));
    vlTOPp->mkMac__DOT__mant_mult___05Fh62851 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1295) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh82762) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh82631) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1368))));
    vlTOPp->mkMac__DOT__y___05Fh40869 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40620));
    vlTOPp->mkMac__DOT__y___05Fh40871 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40620));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
        = ((0x20U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh62851
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1293);
    vlTOPp->mkMac__DOT__x___05Fh40868 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40870) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40871));
    vlTOPp->mkMac__DOT__x___05Fh85296 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                  >> 0xdU)));
    vlTOPp->mkMac__DOT__x___05Fh85105 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh84723 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh84914 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh84341 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh84532 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh84150 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 7U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh85356 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh85165 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh84974 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh84783 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh84592 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh84401 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 7U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh84151 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 6U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__y___05Fh40811 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh40868) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh40869));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1439 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84150) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84151)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372))));
    vlTOPp->mkMac__DOT__y___05Fh84400 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84151));
    vlTOPp->mkMac__DOT__y___05Fh84402 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84151));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d563 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40810) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40811)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh40619) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh40620)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d562)));
    vlTOPp->mkMac__DOT__y___05Fh41060 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40811));
    vlTOPp->mkMac__DOT__y___05Fh41062 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh40811));
    vlTOPp->mkMac__DOT__x___05Fh84399 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84401) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84402));
    vlTOPp->mkMac__DOT__x___05Fh41059 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41061) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41062));
    vlTOPp->mkMac__DOT__y___05Fh84342 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84399) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84400));
    vlTOPp->mkMac__DOT__y___05Fh41002 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41059) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41060));
    vlTOPp->mkMac__DOT__y___05Fh84591 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84342));
    vlTOPp->mkMac__DOT__y___05Fh84593 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84342));
    vlTOPp->mkMac__DOT__y___05Fh41251 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41002));
    vlTOPp->mkMac__DOT__y___05Fh41253 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41002));
    vlTOPp->mkMac__DOT__x___05Fh84590 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84592) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84593));
    vlTOPp->mkMac__DOT__x___05Fh41250 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41252) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41253));
    vlTOPp->mkMac__DOT__y___05Fh84533 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84590) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84591));
    vlTOPp->mkMac__DOT__y___05Fh41193 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41250) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41251));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1440 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84532) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84533)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84341) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84342)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1439)));
    vlTOPp->mkMac__DOT__y___05Fh84782 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84533));
    vlTOPp->mkMac__DOT__y___05Fh84784 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84533));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d564 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41192) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41193)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41001) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41002)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d563)));
    vlTOPp->mkMac__DOT__y___05Fh41442 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41193));
    vlTOPp->mkMac__DOT__y___05Fh41444 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41193));
    vlTOPp->mkMac__DOT__x___05Fh84781 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84783) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84784));
    vlTOPp->mkMac__DOT__x___05Fh41441 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41443) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41444));
    vlTOPp->mkMac__DOT__y___05Fh84724 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84781) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84782));
    vlTOPp->mkMac__DOT__y___05Fh41384 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41441) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41442));
    vlTOPp->mkMac__DOT__y___05Fh84973 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84724));
    vlTOPp->mkMac__DOT__y___05Fh84975 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh84724));
    vlTOPp->mkMac__DOT__y___05Fh41633 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41384));
    vlTOPp->mkMac__DOT__y___05Fh41635 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41384));
    vlTOPp->mkMac__DOT__x___05Fh84972 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84974) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84975));
    vlTOPp->mkMac__DOT__x___05Fh41632 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41634) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41635));
    vlTOPp->mkMac__DOT__y___05Fh84915 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh84972) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh84973));
    vlTOPp->mkMac__DOT__y___05Fh41575 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41632) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41633));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1441 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84914) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84915)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh84723) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh84724)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1440)));
    vlTOPp->mkMac__DOT__y___05Fh85164 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh84915));
    vlTOPp->mkMac__DOT__y___05Fh85166 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh84915));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d565 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41574) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41575)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41383) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41384)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d564)));
    vlTOPp->mkMac__DOT__y___05Fh41824 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh41575));
    vlTOPp->mkMac__DOT__y___05Fh41826 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41575));
    vlTOPp->mkMac__DOT__x___05Fh85163 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85165) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85166));
    vlTOPp->mkMac__DOT__x___05Fh41823 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41825) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41826));
    vlTOPp->mkMac__DOT__y___05Fh85106 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85163) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85164));
    vlTOPp->mkMac__DOT__y___05Fh41766 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh41823) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh41824));
    vlTOPp->mkMac__DOT__y___05Fh85355 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh85106));
    vlTOPp->mkMac__DOT__y___05Fh85357 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85106));
    vlTOPp->mkMac__DOT__y___05Fh42015 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41766));
    vlTOPp->mkMac__DOT__y___05Fh42017 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh41766));
    vlTOPp->mkMac__DOT__x___05Fh85354 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85356) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85357));
    vlTOPp->mkMac__DOT__x___05Fh42014 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42016) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42017));
    vlTOPp->mkMac__DOT__y___05Fh85546 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85354) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85355));
    vlTOPp->mkMac__DOT__y___05Fh41957 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh42014) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh42015));
    vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1442 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85296) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85546)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh85105) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh85106)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1441)));
    vlTOPp->mkMac__DOT__y___05Fh85548 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85546));
    vlTOPp->mkMac__DOT__product___05Fh10578 = ((0xffff0000U 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d470) 
                                               | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41956) 
                                                    ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41957)) 
                                                   << 0xfU) 
                                                  | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh41765) 
                                                       ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh41766)) 
                                                      << 0xeU) 
                                                     | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d565))));
    vlTOPp->mkMac__DOT__x___05Fh85545 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                                >> 0xdU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh85548)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
        = ((0x10U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh10578
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d468);
    vlTOPp->mkMac__DOT__y___05Fh85488 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh85545) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh85546));
    vlTOPp->mkMac__DOT__x___05Fh46322 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh46513 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 0xaU)));
    vlTOPp->mkMac__DOT__x___05Fh45940 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46131 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh45558 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh45749 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh46573 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh45176 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45367 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh44794 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 6U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh44985 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh46382 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh46191 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh46000 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh45809 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh45618 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh45427 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh45236 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh45045 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 6U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh44795 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                                >> 5U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh85679 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh85488));
    vlTOPp->mkMac__DOT__y___05Fh45044 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44795));
    vlTOPp->mkMac__DOT__y___05Fh45046 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44795));
    vlTOPp->mkMac__DOT__mant_mult___05Fh62407 = ((0xffff0000U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1372) 
                                                 | ((0x8000U 
                                                     & ((0xffff8000U 
                                                         & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                                        ^ 
                                                        ((IData)(vlTOPp->mkMac__DOT__y___05Fh85679) 
                                                         << 0xfU))) 
                                                    | ((0x4000U 
                                                        & ((0xffffc000U 
                                                            & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370) 
                                                           ^ 
                                                           ((IData)(vlTOPp->mkMac__DOT__y___05Fh85488) 
                                                            << 0xeU))) 
                                                       | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ETC___05F_d1442))));
    vlTOPp->mkMac__DOT__x___05Fh45043 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45045) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45046));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
        = ((0x40U & (IData)(vlTOPp->mkMac__DOT__b_ififo_rv_BITS_15_TO_0___05Fq2))
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh62407
            : vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1370);
    vlTOPp->mkMac__DOT__y___05Fh44986 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45043) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45044));
    vlTOPp->mkMac__DOT__x___05Fh88404 = (1U & (~ (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                  >> 0xeU)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh88213 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xdU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh88022 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xcU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh87831 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xbU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh87640 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xaU) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh88464 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xdU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__y___05Fh95484 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 7U) 
                                               ^ (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__x___05Fh87449 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 9U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh87258 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 8U) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh88273 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xcU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh88082 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xbU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh87891 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xaU) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh87700 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 9U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh87509 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 8U) 
                                               & ((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh87259 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 7U) 
                                               & (IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d652 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh44985) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh44986)) 
            << 7U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh44794) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh44795)) 
                       << 6U) | ((0x20U & ((0xffffffe0U 
                                            & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567) 
                                           ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                              << 5U))) 
                                 | ((0x1eU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569)))));
    vlTOPp->mkMac__DOT__y___05Fh45235 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44986));
    vlTOPp->mkMac__DOT__y___05Fh45237 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh44986));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1498 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685 
        = (1U & (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                   >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
                  ? (~ (IData)(vlTOPp->mkMac__DOT__y___05Fh95484))
                  : (IData)(vlTOPp->mkMac__DOT__y___05Fh95484)));
    vlTOPp->mkMac__DOT__x___05Fh95483 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87258) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__y___05Fh87508 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__y___05Fh87510 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87259));
    vlTOPp->mkMac__DOT__x___05Fh45234 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45236) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45237));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1692 
        = (1U & (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                   >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
                  ? vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1498
                  : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1664 
        = (1U & (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
                  & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                            | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
                  ? (~ (IData)(vlTOPp->mkMac__DOT__x___05Fh95483))
                  : (IData)(vlTOPp->mkMac__DOT__x___05Fh95483)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95483) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95484))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95483));
    vlTOPp->mkMac__DOT__y___05Fh95672 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95483) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95484));
    vlTOPp->mkMac__DOT__x___05Fh87507 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87509) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87510));
    vlTOPp->mkMac__DOT__y___05Fh45177 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45234) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45235));
    vlTOPp->mkMac__DOT__y___05Fh87450 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87507) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87508));
    vlTOPp->mkMac__DOT__y___05Fh45426 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45177));
    vlTOPp->mkMac__DOT__y___05Fh45428 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45177));
    vlTOPp->mkMac__DOT__x___05Fh95671 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87449) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__y___05Fh87699 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__y___05Fh87701 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87450));
    vlTOPp->mkMac__DOT__x___05Fh45425 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45427) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45428));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1662 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
               ^ (IData)(vlTOPp->mkMac__DOT__x___05Fh95483))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95671));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95672))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95671));
    vlTOPp->mkMac__DOT__y___05Fh100842 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
                                          & (IData)(vlTOPp->mkMac__DOT__x___05Fh95483));
    vlTOPp->mkMac__DOT__y___05Fh95860 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95671) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95672));
    vlTOPp->mkMac__DOT__x___05Fh87698 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87700) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87701));
    vlTOPp->mkMac__DOT__y___05Fh45368 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45425) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45426));
    vlTOPp->mkMac__DOT__y___05Fh87641 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87698) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87699));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d653 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45367) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45368)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45176) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45177)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d652)));
    vlTOPp->mkMac__DOT__y___05Fh45617 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45368));
    vlTOPp->mkMac__DOT__y___05Fh45619 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45368));
    vlTOPp->mkMac__DOT__x___05Fh95859 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87640) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__y___05Fh87890 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__y___05Fh87892 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh87641));
    vlTOPp->mkMac__DOT__x___05Fh45616 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45618) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45619));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1660 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh100842))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95859));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh95860))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh95859));
    vlTOPp->mkMac__DOT__y___05Fh101030 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh100842));
    vlTOPp->mkMac__DOT__y___05Fh96048 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh95859) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh95860));
    vlTOPp->mkMac__DOT__x___05Fh87889 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87891) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87892));
    vlTOPp->mkMac__DOT__y___05Fh45559 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45616) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45617));
    vlTOPp->mkMac__DOT__y___05Fh87832 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87889) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh87890));
    vlTOPp->mkMac__DOT__y___05Fh45808 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45559));
    vlTOPp->mkMac__DOT__y___05Fh45810 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45559));
    vlTOPp->mkMac__DOT__x___05Fh96047 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh87831) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__y___05Fh88081 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__y___05Fh88083 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh87832));
    vlTOPp->mkMac__DOT__x___05Fh45807 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45809) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45810));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1658 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh101030))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96047));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96048))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96047));
    vlTOPp->mkMac__DOT__y___05Fh101218 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh101030));
    vlTOPp->mkMac__DOT__y___05Fh96236 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96047) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96048));
    vlTOPp->mkMac__DOT__x___05Fh88080 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88082) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88083));
    vlTOPp->mkMac__DOT__y___05Fh45750 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45807) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45808));
    vlTOPp->mkMac__DOT__y___05Fh88023 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88080) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88081));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d654 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45749) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45750)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45558) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45559)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d653)));
    vlTOPp->mkMac__DOT__y___05Fh45999 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45750));
    vlTOPp->mkMac__DOT__y___05Fh46001 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45750));
    vlTOPp->mkMac__DOT__x___05Fh96235 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88022) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__y___05Fh88272 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__y___05Fh88274 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88023));
    vlTOPp->mkMac__DOT__x___05Fh45998 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46000) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46001));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1656 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh101218))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96235));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1675 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96236))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96235));
    vlTOPp->mkMac__DOT__y___05Fh101406 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh101218));
    vlTOPp->mkMac__DOT__y___05Fh96424 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96235) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96236));
    vlTOPp->mkMac__DOT__x___05Fh88271 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88273) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88274));
    vlTOPp->mkMac__DOT__y___05Fh45941 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh45998) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh45999));
    vlTOPp->mkMac__DOT__y___05Fh88214 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88271) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88272));
    vlTOPp->mkMac__DOT__y___05Fh46190 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh45941));
    vlTOPp->mkMac__DOT__y___05Fh46192 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh45941));
    vlTOPp->mkMac__DOT__x___05Fh96423 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88213) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__y___05Fh88463 = (((IData)(vlTOPp->mkMac__DOT__a_ififo_rv_BITS_15_TO_0___05Fq1) 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__y___05Fh88465 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88214));
    vlTOPp->mkMac__DOT__x___05Fh46189 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46191) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46192));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1654 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh101406))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96423));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1673 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96424))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96423));
    vlTOPp->mkMac__DOT__y___05Fh101594 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh101406));
    vlTOPp->mkMac__DOT__y___05Fh96612 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96423) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96424));
    vlTOPp->mkMac__DOT__x___05Fh88462 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88464) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88465));
    vlTOPp->mkMac__DOT__y___05Fh46132 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46189) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46190));
    vlTOPp->mkMac__DOT__y___05Fh88654 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88462) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88463));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d655 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46131) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46132)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh45940) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh45941)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d654)));
    vlTOPp->mkMac__DOT__y___05Fh46381 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46132));
    vlTOPp->mkMac__DOT__y___05Fh46383 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46132));
    vlTOPp->mkMac__DOT__x___05Fh96611 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88404) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__y___05Fh88656 = ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__x___05Fh46380 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46382) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46383));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1652 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh101594))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96611));
    vlTOPp->mkMac__DOT__y___05Fh101782 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
                                          & (IData)(vlTOPp->mkMac__DOT__y___05Fh101594));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1671 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
               ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96612))
            : (IData)(vlTOPp->mkMac__DOT__x___05Fh96611));
    vlTOPp->mkMac__DOT__y___05Fh96800 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh96611) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh96612));
    vlTOPp->mkMac__DOT__x___05Fh88653 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                >> 0xeU) 
                                               | (IData)(vlTOPp->mkMac__DOT__y___05Fh88656)));
    vlTOPp->mkMac__DOT__y___05Fh46323 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46380) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46381));
    vlTOPp->mkMac__DOT__y___05Fh88596 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh88653) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh88654));
    vlTOPp->mkMac__DOT__y___05Fh46572 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh46323));
    vlTOPp->mkMac__DOT__y___05Fh46574 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh46323));
    vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488 
        = (1U & ((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                  >> 0xfU) ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh88596)));
    vlTOPp->mkMac__DOT__x___05Fh46571 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46573) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46574));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1650 
        = (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
            & (0U != ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                      | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1498 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh101782)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1526 
        = (((vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
             >> 6U) & (0U != ((0x3eU & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                              | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492))))
            ? ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d1498 
                            >> 0xfU)) | ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh96800)))
            : ((0x1fffeU & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1492 
                            >> 0xfU)) | (IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)));
    vlTOPp->mkMac__DOT__y___05Fh46514 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh46571) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh46572));
    vlTOPp->mkMac__DOT__mant_mult___05Fh88782 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1650 
                                                  << 0xeU) 
                                                 | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1652) 
                                                     << 0xdU) 
                                                    | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1654) 
                                                        << 0xcU) 
                                                       | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1656) 
                                                           << 0xbU) 
                                                          | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1658) 
                                                              << 0xaU) 
                                                             | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1660) 
                                                                 << 9U) 
                                                                | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1662) 
                                                                    << 8U) 
                                                                   | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1664) 
                                                                       << 7U) 
                                                                      | (((IData)(vlTOPp->mkMac__DOT__y___05Fh95484) 
                                                                          << 6U) 
                                                                         | (0x3fU 
                                                                            & (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                                               >> 1U)))))))))));
    if ((1U & ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488) 
               | vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1526))) {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1620 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_ETC___05F_d1535 
                              >> 7U)) | ((IData)(vlTOPp->mkMac__DOT__x___05Fh93446) 
                                         ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh93447)));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1635 
            = vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d1631;
    } else {
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1620 
            = ((0x1fffffeU & (vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532 
                              >> 7U)) | (IData)(vlTOPp->mkMac__DOT__x___05Fh93446));
        vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1635 
            = (((IData)(vlTOPp->mkMac__DOT__x___05Fh93258) 
                << 6U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh93070) 
                           << 5U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92882) 
                                      << 4U) | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92694) 
                                                 << 3U) 
                                                | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92506) 
                                                    << 2U) 
                                                   | (((IData)(vlTOPp->mkMac__DOT__x___05Fh92318) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlTOPp->mkMac__DOT__IF_INV_IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d1532)))))));
    }
    vlTOPp->mkMac__DOT__mant_mult___05Fh96984 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1526 
                                                  << 0xeU) 
                                                 | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1671) 
                                                     << 0xdU) 
                                                    | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1673) 
                                                        << 0xcU) 
                                                       | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1675) 
                                                           << 0xbU) 
                                                          | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677) 
                                                              << 0xaU) 
                                                             | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679) 
                                                                 << 9U) 
                                                                | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681) 
                                                                    << 8U) 
                                                                   | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683) 
                                                                       << 7U) 
                                                                      | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685) 
                                                                          << 6U) 
                                                                         | (0x3fU 
                                                                            & (vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444 
                                                                               >> 1U)))))))))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh93622 
        = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1526 
            << 0xfU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1671) 
                         << 0xeU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1673) 
                                      << 0xdU) | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1675) 
                                                   << 0xcU) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1677) 
                                                      << 0xbU) 
                                                     | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1679) 
                                                         << 0xaU) 
                                                        | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1681) 
                                                            << 9U) 
                                                           | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1683) 
                                                               << 8U) 
                                                              | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1685) 
                                                                  << 7U) 
                                                                 | ((0x7eU 
                                                                     & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1444) 
                                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1692)))))))))));
    vlTOPp->mkMac__DOT__product___05Fh8491 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d569) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46513) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46514)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh46322) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh46323)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d655))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh93624 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1526)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh96984
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2___05Fh93622);
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
        = ((0x20U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh8491
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d567);
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05Fq12 
        = ((IData)(vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d1488)
            ? vlTOPp->mkMac__DOT__mant_mult___05Fh88782
            : vlTOPp->mkMac__DOT___theResult___05F___05F_2_fst___05Fh93624);
    vlTOPp->mkMac__DOT__x___05Fh50879 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh51070 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 9U)));
    vlTOPp->mkMac__DOT__x___05Fh50497 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh50688 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh50115 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50306 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh51130 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh49733 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh49924 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh49542 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 7U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh50939 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh50748 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh50557 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh50366 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh50175 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh49984 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh49793 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 7U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh49543 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                                >> 6U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__product___05Fh61772 = (((IData)(vlTOPp->mkMac__DOT__result_sign___05Fh61773) 
                                                << 0x1fU) 
                                               | ((0x40000000U 
                                                   & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1620 
                                                      << 0x1eU)) 
                                                  | (((IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d1635) 
                                                      << 0x17U) 
                                                     | (0x7f0000U 
                                                        & (vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05Fq12 
                                                           << 9U)))));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d734 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49542) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49543)) 
            << 7U) | ((0x40U & ((0xffffffc0U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657) 
                                ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                   << 6U))) | ((0x3eU 
                                                & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657) 
                                               | (1U 
                                                  & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659))));
    vlTOPp->mkMac__DOT__y___05Fh49792 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49543));
    vlTOPp->mkMac__DOT__y___05Fh49794 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49543));
    vlTOPp->mkMac__DOT__x___05Fh49791 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49793) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49794));
    vlTOPp->mkMac__DOT__y___05Fh49734 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49791) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49792));
    vlTOPp->mkMac__DOT__y___05Fh49983 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49734));
    vlTOPp->mkMac__DOT__y___05Fh49985 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49734));
    vlTOPp->mkMac__DOT__x___05Fh49982 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49984) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49985));
    vlTOPp->mkMac__DOT__y___05Fh49925 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh49982) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh49983));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d735 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49924) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49925)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh49733) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh49734)) 
                       << 8U) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d734)));
    vlTOPp->mkMac__DOT__y___05Fh50174 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49925));
    vlTOPp->mkMac__DOT__y___05Fh50176 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh49925));
    vlTOPp->mkMac__DOT__x___05Fh50173 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50175) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50176));
    vlTOPp->mkMac__DOT__y___05Fh50116 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50173) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50174));
    vlTOPp->mkMac__DOT__y___05Fh50365 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50116));
    vlTOPp->mkMac__DOT__y___05Fh50367 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50116));
    vlTOPp->mkMac__DOT__x___05Fh50364 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50366) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50367));
    vlTOPp->mkMac__DOT__y___05Fh50307 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50364) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50365));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d736 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50306) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50307)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50115) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50116)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d735)));
    vlTOPp->mkMac__DOT__y___05Fh50556 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50307));
    vlTOPp->mkMac__DOT__y___05Fh50558 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50307));
    vlTOPp->mkMac__DOT__x___05Fh50555 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50557) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50558));
    vlTOPp->mkMac__DOT__y___05Fh50498 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50555) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50556));
    vlTOPp->mkMac__DOT__y___05Fh50747 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50498));
    vlTOPp->mkMac__DOT__y___05Fh50749 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50498));
    vlTOPp->mkMac__DOT__x___05Fh50746 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50748) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50749));
    vlTOPp->mkMac__DOT__y___05Fh50689 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50746) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50747));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d737 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50688) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50689)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50497) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50498)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d736)));
    vlTOPp->mkMac__DOT__y___05Fh50938 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50689));
    vlTOPp->mkMac__DOT__y___05Fh50940 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50689));
    vlTOPp->mkMac__DOT__x___05Fh50937 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50939) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50940));
    vlTOPp->mkMac__DOT__y___05Fh50880 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh50937) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh50938));
    vlTOPp->mkMac__DOT__y___05Fh51129 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh50880));
    vlTOPp->mkMac__DOT__y___05Fh51131 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh50880));
    vlTOPp->mkMac__DOT__x___05Fh51128 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51130) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51131));
    vlTOPp->mkMac__DOT__y___05Fh51071 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh51128) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh51129));
    vlTOPp->mkMac__DOT__product___05Fh6404 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d659) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh51070) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh51071)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh50879) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh50880)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d737))));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
        = ((0x40U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh6404
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d657);
    vlTOPp->mkMac__DOT__x___05Fh55436 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xeU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh55627 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xfU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 8U)));
    vlTOPp->mkMac__DOT__x___05Fh55054 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xcU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55245 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xdU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55687 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xeU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 7U)));
    vlTOPp->mkMac__DOT__x___05Fh54672 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xaU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh54863 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xbU) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh54290 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 8U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__x___05Fh54481 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 9U) 
                                               ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741 
        = ((1U & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739)
            ? 1U : 0U);
    vlTOPp->mkMac__DOT__x___05Fh55496 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xdU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 6U)));
    vlTOPp->mkMac__DOT__x___05Fh55305 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xcU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 5U)));
    vlTOPp->mkMac__DOT__x___05Fh55114 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xbU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 4U)));
    vlTOPp->mkMac__DOT__x___05Fh54923 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 0xaU) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 3U)));
    vlTOPp->mkMac__DOT__x___05Fh54732 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 9U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 2U)));
    vlTOPp->mkMac__DOT__x___05Fh54541 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 8U) 
                                               & (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                                  >> 1U)));
    vlTOPp->mkMac__DOT__y___05Fh54291 = (1U & ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                                >> 7U) 
                                               & vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100));
    vlTOPp->mkMac__DOT__y___05Fh54540 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 1U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54291));
    vlTOPp->mkMac__DOT__y___05Fh54542 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54291));
    vlTOPp->mkMac__DOT__x___05Fh54539 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54541) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54542));
    vlTOPp->mkMac__DOT__y___05Fh54482 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54539) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54540));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d808 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54481) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54482)) 
            << 9U) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54290) 
                        ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54291)) 
                       << 8U) | ((0x80U & ((0xffffff80U 
                                            & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739) 
                                           ^ (vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                              << 7U))) 
                                 | ((0x7eU & vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739) 
                                    | (1U & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741)))));
    vlTOPp->mkMac__DOT__y___05Fh54731 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54482));
    vlTOPp->mkMac__DOT__y___05Fh54733 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54482));
    vlTOPp->mkMac__DOT__x___05Fh54730 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54732) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54733));
    vlTOPp->mkMac__DOT__y___05Fh54673 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54730) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54731));
    vlTOPp->mkMac__DOT__y___05Fh54922 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54673));
    vlTOPp->mkMac__DOT__y___05Fh54924 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh54673));
    vlTOPp->mkMac__DOT__x___05Fh54921 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54923) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54924));
    vlTOPp->mkMac__DOT__y___05Fh54864 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh54921) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh54922));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d809 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54863) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54864)) 
            << 0xbU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh54672) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh54673)) 
                         << 0xaU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d808)));
    vlTOPp->mkMac__DOT__y___05Fh55113 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh54864));
    vlTOPp->mkMac__DOT__y___05Fh55115 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh54864));
    vlTOPp->mkMac__DOT__x___05Fh55112 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55114) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55115));
    vlTOPp->mkMac__DOT__y___05Fh55055 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55112) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55113));
    vlTOPp->mkMac__DOT__y___05Fh55304 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55055));
    vlTOPp->mkMac__DOT__y___05Fh55306 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55055));
    vlTOPp->mkMac__DOT__x___05Fh55303 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55305) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55306));
    vlTOPp->mkMac__DOT__y___05Fh55246 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55303) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55304));
    vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d810 
        = ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55245) 
             ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55246)) 
            << 0xdU) | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55054) 
                          ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55055)) 
                         << 0xcU) | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d809)));
    vlTOPp->mkMac__DOT__y___05Fh55495 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55246));
    vlTOPp->mkMac__DOT__y___05Fh55497 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55246));
    vlTOPp->mkMac__DOT__x___05Fh55494 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55496) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55497));
    vlTOPp->mkMac__DOT__y___05Fh55437 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55494) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55495));
    vlTOPp->mkMac__DOT__y___05Fh55686 = ((vlTOPp->mkMac__DOT__IF_IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ifi_ETC___05F_d100 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh55437));
    vlTOPp->mkMac__DOT__y___05Fh55688 = ((vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh55437));
    vlTOPp->mkMac__DOT__x___05Fh55685 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55687) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55688));
    vlTOPp->mkMac__DOT__y___05Fh55628 = ((IData)(vlTOPp->mkMac__DOT__x___05Fh55685) 
                                         | (IData)(vlTOPp->mkMac__DOT__y___05Fh55686));
    vlTOPp->mkMac__DOT__product___05Fh4317 = ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__IF_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_ETC___05F_d741) 
                                              | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55627) 
                                                   ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55628)) 
                                                  << 0xfU) 
                                                 | ((((IData)(vlTOPp->mkMac__DOT__x___05Fh55436) 
                                                      ^ (IData)(vlTOPp->mkMac__DOT__y___05Fh55437)) 
                                                     << 0xeU) 
                                                    | (IData)(vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d810))));
    vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688 
        = ((0x80U & vlTOPp->mkMac__DOT__IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b_ifi_ETC___05F_d59)
            ? vlTOPp->mkMac__DOT__product___05Fh4317
            : vlTOPp->mkMac__DOT__IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THEN_b___05FETC___05F_d739);
    vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
        = (~ vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688);
    vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1688_BIT_0_THEN_1_ELSE_0___05Fq11 
        = ((1U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9)
            ? 0U : 1U);
    vlTOPp->mkMac__DOT__y___05Fh56056 = (1U & ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                                >> 1U) 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9));
    vlTOPp->mkMac__DOT__y___05Fh56247 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 2U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56056));
    vlTOPp->mkMac__DOT__y___05Fh56438 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 3U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56247));
    vlTOPp->mkMac__DOT__y___05Fh56629 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 4U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56438));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d912 
        = ((0x20U & ((0xffffffe0U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                     ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56629) 
                        << 5U))) | ((0x10U & ((0xfffffff0U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56438) 
                                                 << 4U))) 
                                    | ((8U & ((0xfffffff8U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56247) 
                                                 << 3U))) 
                                       | ((4U & ((0xfffffffcU 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh56056) 
                                                  << 2U))) 
                                          | ((2U & 
                                              ((0xfffffffeU 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ (vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                                  << 1U))) 
                                             | (1U 
                                                & vlTOPp->mkMac__DOT__IF_INV_INV_theResult___05F___05F_1688_BIT_0_THEN_1_ELSE_0___05Fq11))))));
    vlTOPp->mkMac__DOT__y___05Fh56820 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 5U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56629));
    vlTOPp->mkMac__DOT__y___05Fh57011 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 6U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh56820));
    vlTOPp->mkMac__DOT__y___05Fh57202 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 7U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57011));
    vlTOPp->mkMac__DOT__y___05Fh57393 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 8U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57202));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d914 
        = ((0x200U & ((0xfffffe00U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                      ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57393) 
                         << 9U))) | ((0x100U & ((0xffffff00U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57202) 
                                                   << 8U))) 
                                     | ((0x80U & ((0xffffff80U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57011) 
                                                   << 7U))) 
                                        | ((0x40U & 
                                            ((0xffffffc0U 
                                              & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                             ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh56820) 
                                                << 6U))) 
                                           | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d912)))));
    vlTOPp->mkMac__DOT__y___05Fh57584 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 9U) & (IData)(vlTOPp->mkMac__DOT__y___05Fh57393));
    vlTOPp->mkMac__DOT__y___05Fh57775 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xaU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57584));
    vlTOPp->mkMac__DOT__y___05Fh57966 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xbU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57775));
    vlTOPp->mkMac__DOT__y___05Fh58157 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xcU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh57966));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d916 
        = ((0x2000U & ((0xffffe000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                       ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58157) 
                          << 0xdU))) | ((0x1000U & 
                                         ((0xfffff000U 
                                           & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57966) 
                                             << 0xcU))) 
                                        | ((0x800U 
                                            & ((0xfffff800U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh57775) 
                                                  << 0xbU))) 
                                           | ((0x400U 
                                               & ((0xfffffc00U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh57584) 
                                                   << 0xaU))) 
                                              | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d914)))));
    vlTOPp->mkMac__DOT__y___05Fh58348 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xdU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58157));
    vlTOPp->mkMac__DOT__y___05Fh58539 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xeU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58348));
    vlTOPp->mkMac__DOT__y___05Fh58730 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0xfU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58539));
    vlTOPp->mkMac__DOT__y___05Fh58921 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x10U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58730));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d918 
        = ((0x20000U & ((0xfffe0000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                        ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58921) 
                           << 0x11U))) | ((0x10000U 
                                           & ((0xffff0000U 
                                               & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                              ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh58730) 
                                                 << 0x10U))) 
                                          | ((0x8000U 
                                              & ((0xffff8000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh58539) 
                                                  << 0xfU))) 
                                             | ((0x4000U 
                                                 & ((0xffffc000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh58348) 
                                                     << 0xeU))) 
                                                | (IData)(vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d916)))));
    vlTOPp->mkMac__DOT__y___05Fh59112 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x11U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh58921));
    vlTOPp->mkMac__DOT__y___05Fh59303 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x12U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59112));
    vlTOPp->mkMac__DOT__y___05Fh59494 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x13U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59303));
    vlTOPp->mkMac__DOT__y___05Fh59685 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x14U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59494));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d920 
        = ((0x200000U & ((0xffe00000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                         ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59685) 
                            << 0x15U))) | ((0x100000U 
                                            & ((0xfff00000U 
                                                & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                               ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh59494) 
                                                  << 0x14U))) 
                                           | ((0x80000U 
                                               & ((0xfff80000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh59303) 
                                                   << 0x13U))) 
                                              | ((0x40000U 
                                                  & ((0xfffc0000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh59112) 
                                                      << 0x12U))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d918))));
    vlTOPp->mkMac__DOT__y___05Fh59876 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x15U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59685));
    vlTOPp->mkMac__DOT__y___05Fh60067 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x16U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh59876));
    vlTOPp->mkMac__DOT__y___05Fh60258 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x17U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60067));
    vlTOPp->mkMac__DOT__y___05Fh60449 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x18U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60258));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d922 
        = ((0x2000000U & ((0xfe000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                          ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60449) 
                             << 0x19U))) | ((0x1000000U 
                                             & ((0xff000000U 
                                                 & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh60258) 
                                                   << 0x18U))) 
                                            | ((0x800000U 
                                                & ((0xff800000U 
                                                    & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                   ^ 
                                                   ((IData)(vlTOPp->mkMac__DOT__y___05Fh60067) 
                                                    << 0x17U))) 
                                               | ((0x400000U 
                                                   & ((0xffc00000U 
                                                       & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                      ^ 
                                                      ((IData)(vlTOPp->mkMac__DOT__y___05Fh59876) 
                                                       << 0x16U))) 
                                                  | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d920))));
    vlTOPp->mkMac__DOT__y___05Fh60640 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x19U) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60449));
    vlTOPp->mkMac__DOT__y___05Fh60831 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1aU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60640));
    vlTOPp->mkMac__DOT__y___05Fh61022 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1bU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh60831));
    vlTOPp->mkMac__DOT__y___05Fh61213 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1cU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61022));
    vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d924 
        = ((0x20000000U & ((0xe0000000U & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                           ^ ((IData)(vlTOPp->mkMac__DOT__y___05Fh61213) 
                              << 0x1dU))) | ((0x10000000U 
                                              & ((0xf0000000U 
                                                  & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                 ^ 
                                                 ((IData)(vlTOPp->mkMac__DOT__y___05Fh61022) 
                                                  << 0x1cU))) 
                                             | ((0x8000000U 
                                                 & ((0xf8000000U 
                                                     & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                    ^ 
                                                    ((IData)(vlTOPp->mkMac__DOT__y___05Fh60831) 
                                                     << 0x1bU))) 
                                                | ((0x4000000U 
                                                    & ((0xfc000000U 
                                                        & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                       ^ 
                                                       ((IData)(vlTOPp->mkMac__DOT__y___05Fh60640) 
                                                        << 0x1aU))) 
                                                   | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d922))));
    vlTOPp->mkMac__DOT__y___05Fh61404 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1dU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61213));
    vlTOPp->mkMac__DOT__y___05Fh61595 = ((vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9 
                                          >> 0x1eU) 
                                         & (IData)(vlTOPp->mkMac__DOT__y___05Fh61404));
    vlTOPp->mkMac__DOT__product___05Fh1806 = ((0x80000000U 
                                               & ((0x80000000U 
                                                   & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                  ^ 
                                                  ((IData)(vlTOPp->mkMac__DOT__y___05Fh61595) 
                                                   << 0x1fU))) 
                                              | ((0x40000000U 
                                                  & ((0xc0000000U 
                                                      & vlTOPp->mkMac__DOT__INV_theResult___05F___05F_1688___05Fq9) 
                                                     ^ 
                                                     ((IData)(vlTOPp->mkMac__DOT__y___05Fh61404) 
                                                      << 0x1eU))) 
                                                 | vlTOPp->mkMac__DOT__INV_IF_IF_IF_b_ififo_rv_port0___05Fread_BIT_16_THE_ETC___05F_d924));
    vlTOPp->mkMac__DOT__product___05Fh1681 = ((IData)(vlTOPp->mkMac__DOT__IF_a_ififo_rv_port0___05Fread_BIT_16_THEN_a_ififo___05FETC___05F_d26)
                                               ? vlTOPp->mkMac__DOT__product___05Fh1806
                                               : vlTOPp->mkMac__DOT___theResult___05F___05F_1___05Fh1688);
    vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fwrite_1 
        = (0x100000000ULL | (QData)((IData)(((1U & (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv))
                                              ? vlTOPp->mkMac__DOT__product___05Fh1681
                                              : vlTOPp->mkMac__DOT__product___05Fh61772))));
}

VL_INLINE_OPT void Vtop::_combo__TOP__5(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_combo__TOP__5\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->mkMac__DOT__cdummy_EN = vlTOPp->EN_get_C;
    vlTOPp->mkMac__DOT__cdummy_D_IN = vlTOPp->get_C_z;
    vlTOPp->mkMac__DOT__tcs_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_s1_or_s2) ? (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv_port1___05Fwrite_1)
            : (IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv));
    vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread 
        = ((IData)(vlTOPp->EN_out_result) ? vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1
            : vlTOPp->mkMac__DOT__result_ofifo_rv);
    vlTOPp->mkMac__DOT__tcs_ififo_rv_D_IN = vlTOPp->mkMac__DOT__tcs_ififo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage 
        = (1U & (((((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                    >> 1U) & (IData)((vlTOPp->mkMac__DOT__product_ofifo_rv 
                                      >> 0x20U))) & (IData)(
                                                            (vlTOPp->mkMac__DOT__c_ififo_rv 
                                                             >> 0x20U))) 
                 & (~ (IData)((vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread 
                               >> 0x20U)))));
    vlTOPp->mkMac__DOT__WILL_FIRE_RL_rl_adder_stage 
        = vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage;
    if (vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_adder_stage) {
        vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fwrite_1;
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv;
        vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__result_ofifo_rv_port1___05Fread;
    }
    vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage = 
        (1U & (((((vlTOPp->mkMac__DOT__a_ififo_rv & vlTOPp->mkMac__DOT__b_ififo_rv) 
                  >> 0x10U) & ((IData)(vlTOPp->mkMac__DOT__tcs_ififo_rv) 
                               >> 1U)) & (~ (IData)(
                                                    (vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread 
                                                     >> 0x20U)))) 
               & (~ (IData)((vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread 
                             >> 0x20U)))));
    vlTOPp->mkMac__DOT__result_ofifo_rv_D_IN = vlTOPp->mkMac__DOT__result_ofifo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__WILL_FIRE_RL_rl_mult_stage 
        = vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage;
    if (vlTOPp->mkMac__DOT__CAN_FIRE_RL_rl_mult_stage) {
        vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fwrite_1;
        vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv_port0___05Fwrite_1;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fwrite_1;
    } else {
        vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__c_ififo_rv_port1___05Fread;
        vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__a_ififo_rv;
        vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
            = vlTOPp->mkMac__DOT__b_ififo_rv;
        vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread 
            = vlTOPp->mkMac__DOT__product_ofifo_rv_port1___05Fread;
    }
    vlTOPp->mkMac__DOT__c_ififo_rv_D_IN = vlTOPp->mkMac__DOT__c_ififo_rv_port2___05Fread;
    vlTOPp->mkMac__DOT__CAN_FIRE_get_A = (1U & (~ (vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
                                                   >> 0x10U)));
    vlTOPp->mkMac__DOT__RDY_get_A = (1U & (~ (vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread 
                                              >> 0x10U)));
    vlTOPp->mkMac__DOT__a_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_get_A) ? vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fwrite_1
            : vlTOPp->mkMac__DOT__a_ififo_rv_port1___05Fread);
    vlTOPp->mkMac__DOT__CAN_FIRE_get_B = (1U & (~ (vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
                                                   >> 0x10U)));
    vlTOPp->mkMac__DOT__RDY_get_B = (1U & (~ (vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread 
                                              >> 0x10U)));
    vlTOPp->mkMac__DOT__b_ififo_rv_port2___05Fread 
        = ((IData)(vlTOPp->EN_get_B) ? vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fwrite_1
            : vlTOPp->mkMac__DOT__b_ififo_rv_port1___05Fread);
    vlTOPp->mkMac__DOT__product_ofifo_rv_D_IN = vlTOPp->mkMac__DOT__product_ofifo_rv_port2___05Fread;
    vlTOPp->RDY_get_A = vlTOPp->mkMac__DOT__RDY_get_A;
    vlTOPp->mkMac__DOT__a_ififo_rv_D_IN = vlTOPp->mkMac__DOT__a_ififo_rv_port2___05Fread;
    vlTOPp->RDY_get_B = vlTOPp->mkMac__DOT__RDY_get_B;
    vlTOPp->mkMac__DOT__b_ififo_rv_D_IN = vlTOPp->mkMac__DOT__b_ififo_rv_port2___05Fread;
}

void Vtop::_eval(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_combo__TOP__2(vlSymsp);
    if (((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK)))) {
        vlTOPp->_sequent__TOP__4(vlSymsp);
    }
    vlTOPp->_combo__TOP__5(vlSymsp);
    // Final
    vlTOPp->__Vclklast__TOP__CLK = vlTOPp->CLK;
}

VL_INLINE_OPT QData Vtop::_change_request(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vtop::_change_request_1(Vtop__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_change_request_1\n"); );
    Vtop* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vtop::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((CLK & 0xfeU))) {
        Verilated::overWidthError("CLK");}
    if (VL_UNLIKELY((RST_N & 0xfeU))) {
        Verilated::overWidthError("RST_N");}
    if (VL_UNLIKELY((EN_get_A & 0xfeU))) {
        Verilated::overWidthError("EN_get_A");}
    if (VL_UNLIKELY((EN_get_B & 0xfeU))) {
        Verilated::overWidthError("EN_get_B");}
    if (VL_UNLIKELY((EN_get_C & 0xfeU))) {
        Verilated::overWidthError("EN_get_C");}
    if (VL_UNLIKELY((s1_or_s2_tcs & 0xfeU))) {
        Verilated::overWidthError("s1_or_s2_tcs");}
    if (VL_UNLIKELY((EN_s1_or_s2 & 0xfeU))) {
        Verilated::overWidthError("EN_s1_or_s2");}
    if (VL_UNLIKELY((EN_out_result & 0xfeU))) {
        Verilated::overWidthError("EN_out_result");}
}
#endif  // VL_DEBUG
